# Google OAuth 2.0 Authentication Setup Guide

## Overview

This guide walks you through setting up Google OAuth 2.0 authentication for EventGo, allowing users to sign up and log in using their Gmail/Google accounts.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Google Cloud Console Setup](#google-cloud-console-setup)
3. [Supabase Configuration](#supabase-configuration)
4. [Implementation Details](#implementation-details)
5. [Security Considerations](#security-considerations)
6. [Testing Guide](#testing-guide)
7. [Troubleshooting](#troubleshooting)

---

## Architecture Overview

### Authentication Flow

```
User clicks "Continue with Google"
         ↓
Browser redirects to Google OAuth consent screen
         ↓
User grants permissions
         ↓
Google redirects back with authorization code
         ↓
Supabase exchanges code for access token
         ↓
User authenticated & session created
         ↓
Analytics tracked & user redirected to app
```

### Technology Stack

- **Frontend**: React + TypeScript
- **Authentication Provider**: Supabase Auth
- **OAuth Provider**: Google OAuth 2.0
- **Session Management**: Supabase (JWT-based)
- **Analytics**: Custom cookie-based system

---

## Google Cloud Console Setup

### Step 1: Create a Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Click "Select a project" → "New Project"
3. Enter project name: `EventGo` (or your preferred name)
4. Click "Create"
5. Wait for project creation to complete

### Step 2: Enable Google+ API

1. In the left sidebar, go to "APIs & Services" → "Library"
2. Search for "Google+ API"
3. Click on "Google+ API"
4. Click "Enable"
5. Wait for activation

### Step 3: Configure OAuth Consent Screen

1. Go to "APIs & Services" → "OAuth consent screen"
2. Select "External" (for public apps)
3. Click "Create"

**Fill in the form:**

- **App name**: EventGo
- **User support email**: your-email@example.com
- **App logo**: (Optional) Upload your app logo
- **App domain**:
  - Application home page: `https://your-domain.com`
  - Privacy policy: `https://your-domain.com/privacy`
  - Terms of service: `https://your-domain.com/terms`
- **Authorized domains**:
  - Add your domain: `your-domain.com`
  - Add Supabase domain: `supabase.co`
- **Developer contact**: your-email@example.com

4. Click "Save and Continue"

**Scopes:**
5. Click "Add or Remove Scopes"
6. Select these scopes:
   - `openid`
   - `https://www.googleapis.com/auth/userinfo.email`
   - `https://www.googleapis.com/auth/userinfo.profile`
7. Click "Update"
8. Click "Save and Continue"

**Test Users (for development):**
9. Click "Add Users"
10. Add your Gmail address
11. Click "Save and Continue"

**Summary:**
12. Review and click "Back to Dashboard"

### Step 4: Create OAuth 2.0 Credentials

1. Go to "APIs & Services" → "Credentials"
2. Click "Create Credentials" → "OAuth client ID"
3. Select "Web application"

**Configure the OAuth client:**

- **Name**: EventGo Web Client
- **Authorized JavaScript origins**:
  ```
  https://your-domain.com
  http://localhost:5173
  https://your-supabase-project.supabase.co
  ```

- **Authorized redirect URIs**:
  ```
  https://your-supabase-project.supabase.co/auth/v1/callback
  http://localhost:54321/auth/v1/callback
  https://your-domain.com/auth/callback
  ```

4. Click "Create"
5. **IMPORTANT**: Copy your credentials:
   - Client ID: `xxxx.apps.googleusercontent.com`
   - Client Secret: `xxxx`
6. Click "OK"

### Step 5: Download Credentials (Optional)

1. Click the download icon next to your OAuth client
2. Save the JSON file securely
3. **Never commit this file to version control**

---

## Supabase Configuration

### Step 1: Access Supabase Dashboard

1. Go to [Supabase Dashboard](https://app.supabase.com/)
2. Select your EventGo project
3. Navigate to "Authentication" → "Providers"

### Step 2: Configure Google Provider

1. Find "Google" in the providers list
2. Click to expand
3. Toggle "Enable Sign in with Google" to **ON**

**Enter your credentials:**

- **Client ID**: Paste from Google Cloud Console
- **Client Secret**: Paste from Google Cloud Console

**Additional settings:**

- **Redirect URL**: (Auto-filled by Supabase)
  ```
  https://your-project.supabase.co/auth/v1/callback
  ```
- **Skip nonce check**: Leave unchecked (recommended)

4. Click "Save"

### Step 3: Configure Redirect URLs

1. Still in Authentication settings
2. Go to "URL Configuration"
3. Add these redirect URLs:

**Site URL:**
```
https://your-domain.com
```

**Redirect URLs:**
```
https://your-domain.com/**
http://localhost:5173/**
```

4. Click "Save"

---

## Implementation Details

### Code Structure

```
src/
├── context/
│   └── AuthContext.tsx         # Google OAuth integration
├── components/
│   └── AuthModal.tsx           # Google Sign-In button
└── utils/
    └── analytics.ts            # OAuth analytics tracking
```

### AuthContext Implementation

```typescript
// src/context/AuthContext.tsx

const signInWithGoogle = async () => {
  try {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: window.location.origin,
        queryParams: {
          access_type: 'offline',
          prompt: 'consent',
        },
      },
    });
    if (!error) {
      analytics.trackUserLogin('google');
    }
    return { error };
  } catch (error) {
    return { error: error as AuthError };
  }
};
```

**Key Parameters:**

- `access_type: 'offline'`: Requests refresh token for long-term access
- `prompt: 'consent'`: Forces consent screen (ensures refresh token)
- `redirectTo`: Where to redirect after successful auth

### AuthModal Integration

```typescript
// Google Sign-In Button
<button onClick={handleGoogleLogin}>
  <GoogleIcon />
  Continue with Google
</button>
```

**Button Features:**
- Official Google colors and branding
- Loading state with spinner
- Disabled state during auth process
- Hover effects for better UX

### Session Management

**Automatic Session Creation:**
```typescript
// Supabase automatically handles:
- User creation (first-time OAuth users)
- Session token generation
- JWT creation
- Cookie management
```

**Session Storage:**
- Access token stored securely in Supabase session
- Refresh token stored securely (if offline access granted)
- Session persists across page refreshes
- Auto-refresh before expiration

### OAuth State Management

```typescript
useEffect(() => {
  // Listen for auth state changes
  const { data: { subscription } } = supabase.auth.onAuthStateChange(
    (_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
    }
  );

  return () => subscription.unsubscribe();
}, []);
```

### Analytics Integration

**Track OAuth Events:**
```typescript
// Login
analytics.trackUserLogin('google');

// Signup (first-time user)
analytics.trackUserSignup('google');
```

**Analytics Data Captured:**
- User ID (after authentication)
- Session ID (from cookie)
- Action type: `user_login` or `user_signup`
- Metadata: `{ login_method: 'google' }`
- Timestamp

---

## Security Considerations

### 1. OAuth Token Security

**Supabase handles:**
- Secure token storage
- Token encryption
- Auto token refresh
- PKCE (Proof Key for Code Exchange) flow

**Best practices:**
- Never expose tokens in client-side code
- Use secure HTTPS connections only
- Implement proper CORS policies

### 2. CSRF Protection

**Built-in protection:**
```typescript
// Supabase automatically includes:
- State parameter validation
- Nonce verification (if enabled)
- Origin validation
```

### 3. User Data Privacy

**Google OAuth scopes requested:**
```
openid                                     // Basic auth
userinfo.email                             // Email address
userinfo.profile                           // Name, photo
```

**Data stored in Supabase:**
```typescript
{
  id: 'uuid',
  email: 'user@gmail.com',
  user_metadata: {
    full_name: 'John Doe',
    avatar_url: 'https://...',
    provider: 'google',
    email_verified: true
  }
}
```

### 4. Consent Screen Transparency

**Users are informed:**
- What data is being accessed
- Why it's needed
- How it will be used
- Option to deny access

### 5. Production Checklist

- [ ] Enable HTTPS everywhere
- [ ] Verify redirect URLs are correct
- [ ] Test OAuth flow end-to-end
- [ ] Review Google API quotas
- [ ] Set up proper error logging
- [ ] Implement rate limiting
- [ ] Add user data deletion flow (GDPR)
- [ ] Configure proper CORS headers
- [ ] Enable security features in Supabase
- [ ] Move app from "Testing" to "Production" in Google Console

---

## Testing Guide

### Development Testing

**1. Test Local Environment:**
```bash
# Start development server
npm run dev

# Open browser
http://localhost:5173

# Click "Continue with Google"
# Should redirect to Google consent screen
```

**2. Test OAuth Flow:**

✓ Click "Continue with Google"
✓ Select Google account
✓ Grant permissions
✓ Redirected back to app
✓ User is logged in
✓ Session persists on refresh
✓ User data appears in profile
✓ Analytics event recorded

**3. Test Error Scenarios:**

- User denies permission → Error handled gracefully
- Network failure → Error message shown
- Invalid credentials → Proper error feedback
- Expired session → Auto-refresh or re-login

### Production Testing

**Before going live:**

1. **Move app to Production:**
   - Google Console → OAuth consent screen
   - Click "Publish App"
   - Submit for verification (if needed)

2. **Test with multiple accounts:**
   - New user signup
   - Existing user login
   - Different Google accounts
   - Mobile devices

3. **Monitor analytics:**
   - Check login success rate
   - Monitor error logs
   - Verify user data integrity

---

## Troubleshooting

### Common Issues

#### 1. "Redirect URI Mismatch" Error

**Problem:** Redirect URL doesn't match configured URLs

**Solution:**
```
1. Check Google Console → Credentials
2. Verify all redirect URIs are added:
   - https://your-project.supabase.co/auth/v1/callback
   - http://localhost:54321/auth/v1/callback
3. Ensure no trailing slashes
4. Wait 5 minutes for changes to propagate
```

#### 2. "Access Denied" or "Unauthorized Client"

**Problem:** OAuth consent screen not published

**Solution:**
```
1. Go to OAuth consent screen
2. Change from "Testing" to "Production"
3. Or add your email to test users
```

#### 3. "Invalid Client" Error

**Problem:** Incorrect Client ID or Secret

**Solution:**
```
1. Verify credentials in Google Console
2. Copy Client ID and Secret again
3. Update in Supabase Dashboard
4. Clear browser cache and try again
```

#### 4. User Gets Stuck After Redirect

**Problem:** Redirect URL configuration issue

**Solution:**
```
1. Check Supabase URL Configuration
2. Verify Site URL is correct
3. Add wildcard redirects: https://your-domain.com/**
4. Test with exact URL patterns
```

#### 5. Token Expired Errors

**Problem:** Refresh token not working

**Solution:**
```
1. Ensure access_type: 'offline' is set
2. Use prompt: 'consent' to force token
3. Check Supabase session settings
4. Implement proper token refresh logic
```

### Debug Mode

**Enable detailed logging:**

```typescript
// In AuthContext.tsx
const signInWithGoogle = async () => {
  console.log('Starting Google OAuth flow...');
  try {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: window.location.origin,
        queryParams: {
          access_type: 'offline',
          prompt: 'consent',
        },
      },
    });
    console.log('OAuth response:', { data, error });
    return { error };
  } catch (error) {
    console.error('OAuth error:', error);
    return { error: error as AuthError };
  }
};
```

### Check OAuth Status

**Verify setup:**

1. **Google Console:**
   - Credentials created ✓
   - OAuth consent configured ✓
   - APIs enabled ✓

2. **Supabase:**
   - Google provider enabled ✓
   - Credentials entered ✓
   - Redirect URLs configured ✓

3. **Application:**
   - signInWithGoogle function exists ✓
   - Button triggers function ✓
   - Analytics tracking works ✓

---

## User Experience Flow

### First-Time User (Signup)

```
1. User clicks "Continue with Google"
2. Redirected to Google consent screen
3. User sees:
   - EventGo wants to access your Google Account
   - View your email address
   - View your basic profile info
4. User clicks "Allow"
5. Redirected back to EventGo
6. Account created automatically
7. User is logged in
8. Assigned 'user' role by default
9. Analytics: user_signup tracked
```

### Returning User (Login)

```
1. User clicks "Continue with Google"
2. Redirected to Google
3. Google recognizes user
4. Auto-granted (no consent needed)
5. Redirected back to EventGo
6. User is logged in
7. Session restored
8. Analytics: user_login tracked
```

### Profile Linking (Future Feature)

```
1. User with email/password account
2. Clicks "Link Google Account"
3. OAuth flow completes
4. Accounts merged
5. User can login with either method
```

---

## API Rate Limits

### Google OAuth API

- **Quota:** 10,000 requests/day (default)
- **Per-user limit:** 10 requests/second
- **Cost:** Free for standard usage

**Monitor usage:**
1. Google Console → APIs & Services → Dashboard
2. View OAuth API usage
3. Set up alerts for quota limits

---

## Compliance & Legal

### GDPR Compliance

**Required implementations:**

1. **Privacy Policy:**
   - Explain Google data usage
   - List scopes accessed
   - Data retention policy

2. **User Rights:**
   - Access their data
   - Delete their data
   - Export their data
   - Opt-out of analytics

3. **Consent:**
   - Clear consent before OAuth
   - Option to decline
   - Withdraw consent anytime

### Google OAuth Policies

**Must comply with:**
- [Google API Services User Data Policy](https://developers.google.com/terms/api-services-user-data-policy)
- Limited Use Requirements
- No data selling or sharing
- Secure data storage
- Proper data deletion

---

## Maintenance

### Regular Checks

**Monthly:**
- [ ] Review OAuth quotas
- [ ] Check error logs
- [ ] Monitor success rates
- [ ] Update dependencies

**Quarterly:**
- [ ] Review security settings
- [ ] Update OAuth scopes (if needed)
- [ ] Verify credentials are valid
- [ ] Test OAuth flow

**Annually:**
- [ ] Renew Google OAuth verification (if applicable)
- [ ] Review privacy policy
- [ ] Update terms of service
- [ ] Security audit

---

## Support Resources

### Official Documentation

- [Google OAuth 2.0](https://developers.google.com/identity/protocols/oauth2)
- [Supabase Auth](https://supabase.com/docs/guides/auth)
- [Supabase OAuth](https://supabase.com/docs/guides/auth/social-login/auth-google)

### Community

- [Supabase Discord](https://discord.supabase.com/)
- [Stack Overflow](https://stackoverflow.com/questions/tagged/supabase)

---

*Last Updated: October 2025*
