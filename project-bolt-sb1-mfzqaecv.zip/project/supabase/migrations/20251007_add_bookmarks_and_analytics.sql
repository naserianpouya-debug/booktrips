/*
  # Add Bookmarks and Analytics System

  1. New Tables
    - `bookmarked_events`
      - `id` (uuid, primary key)
      - `user_id` (uuid) - references auth.users
      - `event_id` (uuid) - references events
      - `created_at` (timestamptz)
      - Unique constraint on (user_id, event_id)

    - `user_analytics`
      - `id` (uuid, primary key)
      - `user_id` (uuid) - references auth.users (nullable for anonymous)
      - `session_id` (text) - cookie-based session identifier
      - `event_id` (uuid) - references events (nullable)
      - `action_type` (text) - 'view', 'bookmark', 'share', 'search', etc.
      - `page_url` (text)
      - `user_agent` (text)
      - `ip_address` (inet)
      - `metadata` (jsonb) - flexible field for additional data
      - `created_at` (timestamptz)

    - `user_preferences`
      - `id` (uuid, primary key)
      - `user_id` (uuid) - references auth.users
      - `preferred_categories` (text[]) - array of favorite categories
      - `preferred_locations` (text[]) - array of favorite locations
      - `email_notifications` (boolean)
      - `theme` (text) - 'light' or 'dark'
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Users can manage their own bookmarks
    - Users can view their own preferences
    - Analytics can be inserted by anyone (for anonymous tracking)
    - Users can only view their own analytics

  3. Indexes
    - Index on bookmarked_events (user_id, created_at)
    - Index on user_analytics (session_id, created_at)
    - Index on user_analytics (user_id, action_type)
*/

-- Create bookmarked_events table
CREATE TABLE IF NOT EXISTS bookmarked_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  event_id uuid REFERENCES events(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, event_id)
);

-- Create user_analytics table
CREATE TABLE IF NOT EXISTS user_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  session_id text NOT NULL,
  event_id uuid REFERENCES events(id) ON DELETE SET NULL,
  action_type text NOT NULL,
  page_url text,
  user_agent text,
  ip_address inet,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Create user_preferences table
CREATE TABLE IF NOT EXISTS user_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  preferred_categories text[] DEFAULT ARRAY[]::text[],
  preferred_locations text[] DEFAULT ARRAY[]::text[],
  email_notifications boolean DEFAULT true,
  theme text DEFAULT 'light',
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS bookmarked_events_user_id_idx ON bookmarked_events(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS bookmarked_events_event_id_idx ON bookmarked_events(event_id);
CREATE INDEX IF NOT EXISTS user_analytics_session_id_idx ON user_analytics(session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS user_analytics_user_id_idx ON user_analytics(user_id, action_type);
CREATE INDEX IF NOT EXISTS user_analytics_event_id_idx ON user_analytics(event_id);
CREATE INDEX IF NOT EXISTS user_preferences_user_id_idx ON user_preferences(user_id);

-- Enable RLS
ALTER TABLE bookmarked_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;

-- Bookmarked events policies
CREATE POLICY "Users can view own bookmarks"
  ON bookmarked_events FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own bookmarks"
  ON bookmarked_events FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own bookmarks"
  ON bookmarked_events FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- User analytics policies
CREATE POLICY "Anyone can insert analytics"
  ON user_analytics FOR INSERT
  TO authenticated, anon
  WITH CHECK (true);

CREATE POLICY "Users can view own analytics"
  ON user_analytics FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all analytics"
  ON user_analytics FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- User preferences policies
CREATE POLICY "Users can view own preferences"
  ON user_preferences FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own preferences"
  ON user_preferences FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own preferences"
  ON user_preferences FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Trigger for user_preferences updated_at
CREATE OR REPLACE FUNCTION update_preferences_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS update_user_preferences_updated_at ON user_preferences;
CREATE TRIGGER update_user_preferences_updated_at
  BEFORE UPDATE ON user_preferences
  FOR EACH ROW
  EXECUTE FUNCTION update_preferences_updated_at();

-- Function to get event bookmark count
CREATE OR REPLACE FUNCTION get_event_bookmark_count(event_uuid uuid)
RETURNS integer AS $$
  SELECT COUNT(*)::integer
  FROM bookmarked_events
  WHERE event_id = event_uuid;
$$ LANGUAGE sql STABLE;

-- Function to check if user has bookmarked an event
CREATE OR REPLACE FUNCTION user_has_bookmarked(event_uuid uuid, user_uuid uuid)
RETURNS boolean AS $$
  SELECT EXISTS(
    SELECT 1
    FROM bookmarked_events
    WHERE event_id = event_uuid AND user_id = user_uuid
  );
$$ LANGUAGE sql STABLE;
