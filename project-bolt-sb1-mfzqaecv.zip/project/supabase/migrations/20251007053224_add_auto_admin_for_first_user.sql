/*
  # Auto-Grant Admin Role to First User

  1. Purpose
    - Automatically assign admin role to the first user who signs up
    - Subsequent users are created as regular users by default
    - Eliminates manual database configuration for initial admin setup

  2. Implementation
    - Creates a function to check if any admins exist
    - Creates a trigger that runs after user signup
    - If no admins exist, grants admin role to the new user
    - Otherwise, creates regular user role

  3. Security
    - Only the first user receives admin privileges automatically
    - All subsequent users must be manually promoted by an admin
    - Maintains secure role-based access control
*/

-- Function to automatically assign role to new users
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  admin_count INT;
BEGIN
  -- Check if any admin users exist
  SELECT COUNT(*) INTO admin_count
  FROM user_roles
  WHERE role = 'admin';

  -- If no admins exist, make this user an admin
  IF admin_count = 0 THEN
    INSERT INTO user_roles (user_id, role)
    VALUES (NEW.id, 'admin');
  ELSE
    -- Otherwise, create as regular user
    INSERT INTO user_roles (user_id, role)
    VALUES (NEW.id, 'user');
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to run after user signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();
