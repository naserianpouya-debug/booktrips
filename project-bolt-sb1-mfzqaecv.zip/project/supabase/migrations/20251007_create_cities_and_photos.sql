/*
  # City Pages Schema

  1. New Tables
    - `cities`
      - `id` (text, primary key) - URL-friendly city identifier (e.g., 'paris', 'new-york')
      - `name` (text) - Display name (e.g., 'Paris', 'New York')
      - `country` (text) - Country name
      - `description` (text) - City overview (2-3 paragraphs)
      - `hero_image` (text) - Main city image URL
      - `latitude` (numeric) - Geographic coordinates
      - `longitude` (numeric) - Geographic coordinates
      - `event_count` (integer) - Cached event count
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `city_photos`
      - `id` (uuid, primary key)
      - `city_id` (text, foreign key) - References cities.id
      - `image_url` (text) - Photo URL
      - `caption` (text, optional) - Photo description
      - `photographer` (text, optional) - Photo credit
      - `display_order` (integer) - Sort order in gallery
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Public read access for cities and photos
    - Admin-only write access

  3. Indexes
    - Index on city_id for faster photo lookups
    - Index on country for filtering
*/

-- Create cities table
CREATE TABLE IF NOT EXISTS cities (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  country TEXT NOT NULL,
  description TEXT NOT NULL,
  hero_image TEXT NOT NULL,
  latitude NUMERIC(10, 6),
  longitude NUMERIC(10, 6),
  event_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create city_photos table
CREATE TABLE IF NOT EXISTS city_photos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  city_id TEXT NOT NULL REFERENCES cities(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  caption TEXT,
  photographer TEXT,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_cities_country ON cities(country);
CREATE INDEX IF NOT EXISTS idx_city_photos_city_id ON city_photos(city_id);
CREATE INDEX IF NOT EXISTS idx_city_photos_order ON city_photos(city_id, display_order);

-- Enable Row Level Security
ALTER TABLE cities ENABLE ROW LEVEL SECURITY;
ALTER TABLE city_photos ENABLE ROW LEVEL SECURITY;

-- RLS Policies for cities
CREATE POLICY "Anyone can view cities"
  ON cities FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert cities"
  ON cities FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update cities"
  ON cities FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete cities"
  ON cities FOR DELETE
  TO authenticated
  USING (true);

-- RLS Policies for city_photos
CREATE POLICY "Anyone can view city photos"
  ON city_photos FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert city photos"
  ON city_photos FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update city photos"
  ON city_photos FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete city photos"
  ON city_photos FOR DELETE
  TO authenticated
  USING (true);

-- Insert sample city data
INSERT INTO cities (id, name, country, description, hero_image, latitude, longitude, event_count)
VALUES
(
  'paris',
  'Paris',
  'France',
  'Paris, the City of Light, is one of the world''s most romantic and culturally rich destinations. From the iconic Eiffel Tower to the charming cafes of Montmartre, every corner tells a story of art, history, and joie de vivre. The city boasts world-class museums like the Louvre, stunning architecture including Notre-Dame Cathedral, and the elegant Champs-Élysées.

Experience the magic of Paris through its vibrant events scene, featuring everything from intimate jazz concerts in historic cellars to grand exhibitions at the Grand Palais. The city''s calendar is packed with fashion shows, art exhibitions, music festivals, and cultural celebrations that capture the essence of French culture. Whether you''re attending a classical performance at the Opéra Garnier or enjoying a contemporary art opening in Le Marais, Paris offers unforgettable experiences year-round.

Beyond its famous landmarks, Paris thrives with neighborhood festivals, open-air markets, and seasonal events that bring locals and visitors together. From summer concerts along the Seine to Christmas markets illuminating the winter streets, the city''s event culture ensures there''s always something extraordinary happening.',
  'https://images.unsplash.com/photo-1502602898657-3e91760cbb34',
  48.8566,
  2.3522,
  328
),
(
  'london',
  'London',
  'United Kingdom',
  'London stands as one of the world''s most dynamic cities, where centuries of history blend seamlessly with cutting-edge innovation. From the majestic Tower of London to the modern skyline of Canary Wharf, this global metropolis offers an unparalleled mix of tradition and contemporary culture. The city''s diverse neighborhoods each have their own distinct character, from the elegant streets of Kensington to the vibrant markets of Camden.

The events scene in London is truly world-class, featuring everything from West End theatre productions to underground music venues, prestigious sporting events to intimate gallery openings. The city hosts major festivals throughout the year, including Notting Hill Carnival, the London Film Festival, and New Year''s Eve fireworks over the Thames. With venues ranging from the historic Royal Albert Hall to trendy pop-up spaces in Shoreditch, there''s an event for every interest.

London''s cultural calendar never sleeps, offering year-round entertainment across music, art, food, and sports. Experience everything from Shakespeare at the Globe Theatre to electronic music festivals, from traditional ceremonies at Buckingham Palace to innovative tech conferences. The city''s multicultural fabric ensures a rich tapestry of events celebrating communities from around the world.',
  'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad',
  51.5074,
  -0.1278,
  412
),
(
  'new-york',
  'New York',
  'United States',
  'New York City, the city that never sleeps, pulses with an energy unlike anywhere else on Earth. From the towering skyscrapers of Manhattan to the artistic enclaves of Brooklyn, NYC is a melting pot of cultures, cuisines, and creativity. The iconic skyline, Central Park, Times Square, and the Statue of Liberty are just the beginning of what makes this city extraordinary.

The Big Apple hosts some of the world''s most spectacular events, from Broadway premieres to rooftop concerts, fashion week extravaganzas to underground comedy shows. The city''s event calendar is legendary, featuring everything from the Macy''s Thanksgiving Day Parade to the US Open, from SummerStage concerts to art exhibitions at MoMA. With venues in every borough hosting events 24/7, NYC truly offers something for everyone at any time.

Experience the diversity of New York through its countless festivals, performances, and gatherings. From jazz clubs in Harlem to art galleries in Chelsea, from food festivals in Queens to beach concerts at Coney Island, the city''s event scene reflects its incredible cultural richness. Whether you''re attending a Yankees game, catching a show at Carnegie Hall, or exploring a street fair, NYC delivers unforgettable experiences.',
  'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9',
  40.7128,
  -74.0060,
  567
)
ON CONFLICT (id) DO NOTHING;

-- Insert sample photos for Paris
INSERT INTO city_photos (city_id, image_url, caption, display_order)
VALUES
  ('paris', 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34', 'Eiffel Tower at sunset', 1),
  ('paris', 'https://images.unsplash.com/photo-1511739001486-6bfe10ce785f', 'Arc de Triomphe', 2),
  ('paris', 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a', 'Paris cityscape', 3),
  ('paris', 'https://images.unsplash.com/photo-1549144511-f099e773c147', 'Notre-Dame Cathedral', 4),
  ('paris', 'https://images.unsplash.com/photo-1522582324369-2dfc36bd9275', 'Parisian cafe', 5),
  ('paris', 'https://images.unsplash.com/photo-1431274172761-fca41d930114', 'Louvre Museum', 6),
  ('paris', 'https://images.unsplash.com/photo-1508050919630-b135583b29ab', 'Seine River', 7),
  ('paris', 'https://images.unsplash.com/photo-1550340499-a6c60fc8287c', 'Montmartre', 8)
ON CONFLICT DO NOTHING;

-- Insert sample photos for London
INSERT INTO city_photos (city_id, image_url, caption, display_order)
VALUES
  ('london', 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad', 'Big Ben and Parliament', 1),
  ('london', 'https://images.unsplash.com/photo-1529655683826-aba9b3e77383', 'Tower Bridge', 2),
  ('london', 'https://images.unsplash.com/photo-1505761671935-60b3a7427bad', 'London Eye', 3),
  ('london', 'https://images.unsplash.com/photo-1543832923-44667a44c804', 'Red telephone box', 4),
  ('london', 'https://images.unsplash.com/photo-1526129318478-62ed807ebdf9', 'London cityscape', 5),
  ('london', 'https://images.unsplash.com/photo-1533929736458-ca588d08c8be', 'Buckingham Palace', 6),
  ('london', 'https://images.unsplash.com/photo-1560969184-10fe8719e047', 'Piccadilly Circus', 7),
  ('london', 'https://images.unsplash.com/photo-1520986606214-8b456906c813', 'Thames River', 8)
ON CONFLICT DO NOTHING;

-- Insert sample photos for New York
INSERT INTO city_photos (city_id, image_url, caption, display_order)
VALUES
  ('new-york', 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9', 'Manhattan skyline', 1),
  ('new-york', 'https://images.unsplash.com/photo-1522083165195-3424ed129620', 'Brooklyn Bridge', 2),
  ('new-york', 'https://images.unsplash.com/photo-1543716091-a840c05249ec', 'Times Square', 3),
  ('new-york', 'https://images.unsplash.com/photo-1485738422979-f5c462d49f74', 'Central Park', 4),
  ('new-york', 'https://images.unsplash.com/photo-1518391846015-55a9cc003b25', 'Statue of Liberty', 5),
  ('new-york', 'https://images.unsplash.com/photo-1534430480872-3498386e7856', 'Empire State Building', 6),
  ('new-york', 'https://images.unsplash.com/photo-1533106418989-88406c7cc8ca', 'NYC streets', 7),
  ('new-york', 'https://images.unsplash.com/photo-1542051841857-5f90071e7989', 'Broadway', 8)
ON CONFLICT DO NOTHING;

-- Function to update event count (call this when events are added/removed)
CREATE OR REPLACE FUNCTION update_city_event_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    UPDATE cities
    SET event_count = (
      SELECT COUNT(*)
      FROM events
      WHERE location = NEW.location
        AND status = 'published'
    )
    WHERE name = NEW.location;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE cities
    SET event_count = (
      SELECT COUNT(*)
      FROM events
      WHERE location = OLD.location
        AND status = 'published'
    )
    WHERE name = OLD.location;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for event count updates
DROP TRIGGER IF EXISTS update_city_event_count_trigger ON events;
CREATE TRIGGER update_city_event_count_trigger
  AFTER INSERT OR UPDATE OR DELETE ON events
  FOR EACH ROW
  EXECUTE FUNCTION update_city_event_count();
