# City Template - HTML Reference Documentation

## Overview

This document explains the standalone HTML template (`city-template-reference.html`) that demonstrates the structure and design of your BookTrips city pages. This template serves as a reference for the already-implemented React components.

---

## Purpose

The HTML template provides:
1. **Visual reference** for designers and stakeholders
2. **Structure guide** for implementing new cities
3. **Style documentation** for consistent design
4. **Accessibility examples** for WCAG compliance
5. **Responsive design patterns** for all devices

---

## Template Structure

### 1. Hero Section

**Purpose:** Eye-catching introduction to the city

**HTML Structure:**
```html
<section class="hero-section">
  <button class="back-button">Back</button>
  <div class="hero-content">
    <div class="hero-location">📍 Country</div>
    <h1 class="hero-title">City Name</h1>
    <div class="event-badge">📅 X Events Available</div>
  </div>
</section>
```

**Key Features:**
- Full-height background image with overlay
- Responsive text sizing (clamp function)
- Back navigation button
- Country and event count display
- Semi-transparent badge with blur effect

**CSS Highlights:**
```css
height: 60vh;
min-height: 500px;
background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url(...);
font-size: clamp(48px, 8vw, 80px);
```

---

### 2. Description Section

**Purpose:** Informative text about the city

**HTML Structure:**
```html
<section class="description-section">
  <div class="description-text">
    <p>First paragraph...</p>
    <p>Second paragraph...</p>
    <p>Third paragraph...</p>
  </div>
</section>
```

**Content Guidelines:**
- **Length:** 200-300 words total
- **Paragraphs:** 2-3 paragraphs
- **Focus:** History, culture, attractions, unique characteristics
- **Tone:** Engaging and informative for travelers

**Typography:**
```css
font-size: 18px;
line-height: 1.8;
max-width: 900px;
```

---

### 3. Photo Gallery Section

**Purpose:** Visual showcase of city attractions

**HTML Structure:**
```html
<section class="gallery-section">
  <div class="section-header">
    <svg class="section-icon">📷</svg>
    <h2 class="section-title">Explore City</h2>
  </div>

  <div class="gallery-grid">
    <article class="gallery-item">
      <img src="..." alt="..." loading="lazy">
      <div class="gallery-caption">Caption</div>
    </article>
    <!-- Repeat 6-12 times -->
  </div>
</section>
```

**Grid Behavior:**
```css
/* Desktop: 3+ columns */
grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));

/* Tablet: 2 columns */
@media (max-width: 768px) {
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
}

/* Mobile: 1 column */
@media (max-width: 480px) {
  grid-template-columns: 1fr;
}
```

**Image Requirements:**
- **Aspect Ratio:** 4:3
- **Resolution:** 800px width minimum
- **Format:** WebP or JPEG
- **Alt Text:** Descriptive, includes landmark name
- **Loading:** Lazy loading enabled

**Hover Effects:**
```css
transform: scale(1.02);
box-shadow: 0 12px 32px rgba(0, 0, 0, 0.15);
caption opacity: 0 → 1;
```

---

### 4. Events Section

**Purpose:** Display city events with filtering

**HTML Structure:**
```html
<section class="events-section">
  <div class="events-header">
    <h2 class="section-title">Events in City</h2>
    <div class="events-filters">
      <button class="filter-button active">All</button>
      <button class="filter-button">Upcoming</button>
      <button class="filter-button">This Week</button>
    </div>
  </div>

  <div class="events-grid">
    <!-- Event cards -->
  </div>
</section>
```

**Grid Behavior:**
```css
grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
gap: 24px;
```

---

### 5. Event Card Structure

**Anatomy of an Event Card:**

```html
<article class="event-card">
  <!-- Image Section -->
  <div class="event-image">
    <img src="..." alt="...">
    <span class="event-category">CATEGORY</span>
  </div>

  <!-- Content Section -->
  <div class="event-content">
    <div class="event-date">📅 March 15, 2025 • 8:00 PM</div>
    <h3 class="event-title">Event Name</h3>
    <div class="event-location">📍 Venue Name</div>
    <p class="event-description">Brief description...</p>

    <!-- Footer -->
    <div class="event-footer">
      <div>
        <div class="event-price-label">From</div>
        <div class="event-price">€45</div>
      </div>
      <button class="event-button">Get Tickets</button>
    </div>
  </div>
</article>
```

**Card Components:**

1. **Image Section**
   - Height: 220px
   - Category badge (top-right)
   - Hover zoom effect

2. **Date Display**
   - Icon + formatted date
   - Color: #FF5D73 (brand color)

3. **Title**
   - Font size: 22px
   - Weight: 800 (bold)
   - Line clamp for overflow

4. **Location**
   - Icon + venue name
   - Gray color (#7C7A7A)

5. **Description**
   - 2-line clamp
   - Line height: 1.6

6. **Footer**
   - Price on left
   - CTA button on right
   - Border-top separator

**Categories:**
- Music
- Art
- Food & Drink
- Theatre
- Fashion
- Festival
- Sports
- Culture

---

## Styling System

### Color Palette

```css
/* Primary Colors */
--primary: #FF5D73;        /* Coral - Buttons, badges, accents */
--primary-dark: #E54D63;   /* Hover states */

/* Text Colors */
--text-primary: #000000;   /* Headings */
--text-body: #3A3A3A;      /* Body text */
--text-secondary: #7C7A7A; /* Secondary info */

/* Background Colors */
--bg-white: #FFFFFF;       /* Main background */
--bg-light: #F8F9FA;       /* Section background */
--bg-overlay: rgba(0, 0, 0, 0.4); /* Hero overlay */

/* UI Colors */
--shadow-sm: rgba(0, 0, 0, 0.08);
--shadow-md: rgba(0, 0, 0, 0.15);
--border: rgba(0, 0, 0, 0.1);
```

### Typography Scale

```css
/* Headings */
H1: clamp(48px, 8vw, 80px) - weight 900
H2: 36px - weight 800
H3: 22-28px - weight 700-800

/* Body Text */
Large: 18px - weight 500
Regular: 16px - weight 500
Small: 14-15px - weight 500-600
Tiny: 12px - weight 600-700
```

### Spacing System

```css
/* Base Unit: 8px */
--spacing-1: 8px;
--spacing-2: 12px;
--spacing-3: 16px;
--spacing-4: 20px;
--spacing-5: 24px;
--spacing-6: 32px;
--spacing-7: 40px;
--spacing-8: 60px;
--spacing-9: 80px;
```

### Border Radius Scale

```css
--radius-sm: 8px;      /* Small elements */
--radius-md: 12px;     /* Buttons */
--radius-lg: 16px;     /* Cards */
--radius-xl: 20px;     /* Large cards */
--radius-2xl: 24px;    /* Hero cards */
--radius-full: 25px;   /* Pills/badges */
```

---

## Responsive Breakpoints

### Mobile (≤ 480px)
```css
@media (max-width: 480px) {
  /* Single column layout */
  .gallery-grid,
  .events-grid {
    grid-template-columns: 1fr;
  }

  /* Smaller text */
  .event-title {
    font-size: 20px;
  }
}
```

### Tablet (≤ 768px)
```css
@media (max-width: 768px) {
  /* Adjust hero */
  .hero-section {
    height: 50vh;
    min-height: 400px;
  }

  /* Stack filters */
  .events-header {
    flex-direction: column;
    align-items: flex-start;
  }

  /* 2-column or single column galleries */
  .gallery-grid {
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  }
}
```

### Desktop (≥ 769px)
```css
/* Default styles apply */
/* 3+ column layouts */
/* Full-size typography */
```

---

## Accessibility Features

### Semantic HTML
```html
<section role="banner">        <!-- Hero -->
<section role="main">          <!-- Description -->
<article>                      <!-- Event cards -->
<button aria-label="...">      <!-- Buttons -->
```

### ARIA Labels
```html
<button aria-label="Back to home">
<div role="group" aria-label="Event filters">
<img alt="Descriptive text including landmark name">
```

### Keyboard Navigation
- **Tab:** Move through interactive elements
- **Enter/Space:** Activate buttons
- **Arrow Keys:** Navigate galleries (in React version)
- **Escape:** Close modals (in React version)

### Color Contrast
- **Text on white:** 7:1 (AAA)
- **Buttons:** 4.5:1 (AA)
- **Secondary text:** 4.5:1 (AA)

### Focus Indicators
```css
button:focus {
  outline: 2px solid #FF5D73;
  outline-offset: 2px;
}
```

---

## Performance Optimization

### Image Loading
```html
<!-- Lazy loading -->
<img loading="lazy" src="..." alt="...">

<!-- Responsive images (future) -->
<img srcset="image-300.jpg 300w,
             image-600.jpg 600w,
             image-900.jpg 900w"
     sizes="(max-width: 480px) 100vw,
            (max-width: 768px) 50vw,
            33vw"
     src="image-600.jpg" alt="...">
```

### CSS Optimization
- Inline critical CSS
- Use CSS Grid over complex Flexbox
- Minimize animations
- Use transform for movement (GPU accelerated)

### JavaScript
- Event delegation for click handlers
- Debounce scroll/resize events
- Lazy load off-screen content

---

## Content Guidelines

### Hero Section
- **City Name:** Title case
- **Country:** Full country name
- **Event Count:** Exact number from database

### Description Section
**Paragraph 1 (Overview):**
- Nickname or famous description
- Key landmarks (2-3)
- Architectural or cultural highlights

**Paragraph 2 (Events & Culture):**
- Types of events available
- Cultural scene description
- Example venues or attractions

**Paragraph 3 (Local Experience):**
- Neighborhood festivals
- Seasonal events
- What makes events special here

### Photo Gallery
**Photo Selection:**
- Mix of iconic landmarks and local scenes
- Day and night shots
- Different perspectives
- People and architecture
- Cultural elements

**Captions:**
- Landmark name
- Brief context if needed
- Keep under 50 characters

### Event Cards
**Title:** Clear and descriptive (3-6 words)
**Description:** 15-25 words, highlight unique aspects
**Date Format:** "Month DD, YYYY • HH:MM AM/PM"
**Location:** Venue name (not full address)
**Price:** "From €XX" format

---

## Customization Guide

### Changing Colors
```css
/* Find and replace */
#FF5D73 → #YOUR_PRIMARY_COLOR
#E54D63 → #YOUR_PRIMARY_DARK
```

### Adjusting Layout
```css
/* Wider content */
max-width: 900px → max-width: 1200px;

/* Larger cards */
minmax(300px, 1fr) → minmax(400px, 1fr);

/* More spacing */
gap: 24px → gap: 32px;
```

### Adding New Sections
```html
<section class="custom-section">
  <div class="section-header">
    <svg class="section-icon">...</svg>
    <h2 class="section-title">Section Title</h2>
  </div>
  <!-- Content -->
</section>
```

---

## Browser Support

### Fully Supported
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

### Partially Supported
- IE 11 (with polyfills)
- Older mobile browsers

### Required Features
- CSS Grid
- CSS Variables
- Flexbox
- SVG support
- ES6 JavaScript

---

## Integration with React

The HTML template demonstrates the structure that's implemented in:

1. **CityPage.tsx** - Main page component
2. **CityPhotoGallery.tsx** - Gallery with lightbox
3. **EventCard.tsx** - Event card component

**Differences:**
- React uses components and props
- State management for filtering
- Client-side routing
- Database integration via Supabase
- Interactive lightbox modal

---

## Testing Checklist

### Visual Testing
- [ ] Hero displays correctly
- [ ] Description is readable
- [ ] Gallery grid aligns properly
- [ ] Event cards have consistent height
- [ ] Hover effects work smoothly

### Responsive Testing
- [ ] Mobile (375px)
- [ ] Tablet (768px)
- [ ] Desktop (1920px)
- [ ] Ultra-wide (2560px)

### Accessibility Testing
- [ ] Tab navigation works
- [ ] Screen reader compatible
- [ ] Color contrast passes
- [ ] Alt text present
- [ ] Semantic HTML used

### Performance Testing
- [ ] Images lazy load
- [ ] Page loads in < 2s
- [ ] No layout shift
- [ ] Smooth animations
- [ ] No console errors

---

## File Information

**Filename:** `city-template-reference.html`
**Size:** ~30 KB
**Lines:** ~1000
**Dependencies:** None (standalone)
**Browser:** Open directly in browser
**Purpose:** Reference and demonstration

---

## Usage Examples

### View the Template
```bash
# Open in browser
open city-template-reference.html

# Or use a local server
python -m http.server 8000
# Then visit: http://localhost:8000/city-template-reference.html
```

### Extract Styles
```javascript
// Copy specific styles to your CSS
const heroStyles = document.querySelector('.hero-section').style;
```

### Use as Design Reference
- Show to designers for approval
- Share with stakeholders for feedback
- Use in presentations
- Reference for new developers

---

## Comparison: HTML vs React

| Feature | HTML Template | React Implementation |
|---------|--------------|---------------------|
| **Routing** | Static | Dynamic (/city/:id) |
| **Data** | Hardcoded | Supabase database |
| **Gallery** | Static grid | Interactive lightbox |
| **Filtering** | Basic JS | Real-time state |
| **Performance** | Fast initial | Optimized with lazy loading |
| **Reusability** | Copy/paste | Component-based |
| **Maintenance** | Update each file | Update once |

---

## Best Practices

### DO:
✅ Use semantic HTML
✅ Include alt text on images
✅ Follow heading hierarchy
✅ Test on real devices
✅ Optimize images before uploading
✅ Use consistent spacing
✅ Write descriptive content

### DON'T:
❌ Skip accessibility features
❌ Use inline styles (except demo)
❌ Forget mobile testing
❌ Use generic alt text
❌ Exceed recommended text length
❌ Mix design patterns
❌ Ignore performance

---

## Future Enhancements

### Planned Features
1. **Structured Data** - JSON-LD schema
2. **Social Sharing** - Open Graph tags
3. **Reviews Section** - User ratings
4. **Weather Widget** - Current conditions
5. **Map Integration** - Interactive map
6. **Related Cities** - Recommendations
7. **Save to Favorites** - User bookmarks

### Potential Additions
- Video backgrounds in hero
- 360° photo viewer
- Virtual tours
- Live event calendar
- Booking integration
- User-generated content

---

## Support Resources

### Documentation
- Complete guide: `CITY_TEMPLATE_GUIDE.md`
- Quick start: `CITY_TEMPLATE_QUICK_START.md`
- This reference: `HTML_TEMPLATE_DOCUMENTATION.md`

### Code References
- React components: `src/components/` and `src/pages/`
- Database schema: `supabase/migrations/`
- Styles: Inline in components

---

## Credits

**Design:** BookTrips design system
**Images:** Unsplash (https://unsplash.com)
**Icons:** SVG inline
**Fonts:** System fonts (-apple-system, etc.)
**Framework:** Vanilla HTML/CSS/JS

---

## License

Part of BookTrips event discovery platform
© 2025 All rights reserved

---

**Version:** 1.0.0
**Last Updated:** January 6, 2025
**Status:** Reference Document ✅
