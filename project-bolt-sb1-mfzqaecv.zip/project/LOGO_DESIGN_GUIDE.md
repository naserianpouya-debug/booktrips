# BookTrips Logo Design Guide

## Logo Concept

The BookTrips logo is a minimalistic design that perfectly captures the dual nature of the platform: **events** (booking) and **experiences** (trips).

---

## Visual Elements

### **Primary Mark**
```
┌─────────────────────┐
│                     │
│   ╔═════════════╗   │
│   ║   ┊   ┊    ║   │  ← Ticket shape with perforations
│   ║   ┊   ┊    ║   │
│   ║   ┊   ●    ║   │  ← Location pin dot (centered)
│   ║   ┊   ┊    ║   │
│   ║   ┊   ┊    ║   │
│   ╚═════════════╝   │
│                     │
└─────────────────────┘
```

### **Logo Components**
1. **Outer Ticket Frame**: Rounded rectangle with cutout circles (representing ticket stub)
2. **Vertical Dashed Line**: Suggests perforation/tear line on a ticket
3. **Central Pin Dot**: Solid circle representing a location marker

---

## Design Specifications

### **Colors**

**Primary Brand Color**
- Hex: `#FF5D73`
- RGB: `255, 93, 115`
- Name: Coral Pink
- Usage: Logo, primary CTAs, accents

**Secondary Colors**
- White (#FFFFFF) - For light backgrounds
- Black (#000000) - For text and dark elements
- Gray (#7C7A7A) - For secondary text

### **Typography**
- Font Weight: 800 (Extra Bold)
- Letter Spacing: -0.5px
- Font Family: System UI stack (platform native)

### **Sizing Guide**

| Use Case | Size | Text Visible |
|----------|------|--------------|
| Favicon | 16px | No |
| Mobile Nav | 24px | No |
| Desktop Nav | 32px | Yes |
| Footer | 36px | Yes |
| Hero | 48px | Yes |
| Marketing | 64px+ | Yes |

---

## Logo Variations

### **1. Full Logo (Horizontal)**
```
[LOGO ICON] BookTrips
```
**Usage**: Navigation bars, headers, email signatures
**Minimum width**: 120px

### **2. Icon Only**
```
[LOGO ICON]
```
**Usage**: Favicons, app icons, social media avatars
**Minimum size**: 16px × 16px

### **3. Stacked Logo**
```
[LOGO ICON]
BookTrips
```
**Usage**: Square spaces, mobile apps
**Minimum size**: 80px × 80px

---

## Clear Space

Maintain minimum clear space around the logo equal to **0.5x** the height of the logo mark.

```
    ←─ 0.5x ─→

    [LOGO]  ↑
            0.5x
            ↓
```

---

## Color Variations

### **Light Background**
- Icon: #FF5D73
- Text: #FF5D73 or #000000

### **Dark Background**
- Icon: #FF5D73 or #FFFFFF
- Text: #FFFFFF

### **Monochrome**
- Black: For print materials
- White: For dark backgrounds
- Gray: For subtle applications

---

## Usage Guidelines

### **✅ Do's**
- Use official logo files only
- Maintain proper spacing
- Use approved color variations
- Scale proportionally
- Ensure good contrast with background
- Use on clean, uncluttered backgrounds

### **❌ Don'ts**
- Don't distort or stretch the logo
- Don't rotate the logo
- Don't add effects (shadows, glows, etc.)
- Don't change the colors arbitrarily
- Don't place on busy backgrounds
- Don't recreate or modify the logo

---

## File Formats

### **Digital/Web**
- **SVG**: Vector, infinitely scalable (primary format)
- **PNG**: Raster with transparency
  - @1x (72 DPI)
  - @2x (144 DPI - Retina)
  - @3x (216 DPI - High DPI)

### **Print**
- **PDF**: Vector for professional printing
- **EPS**: Vector for legacy applications
- **PNG**: High-res (300 DPI) for digital printing

---

## Social Media Specifications

### **Profile Pictures**
- **Twitter**: 400 × 400px (icon only)
- **Facebook**: 180 × 180px (icon only)
- **LinkedIn**: 400 × 400px (icon only)
- **Instagram**: 320 × 320px (icon only)

### **Cover Images**
- **Twitter Header**: 1500 × 500px (logo + tagline)
- **Facebook Cover**: 820 × 312px (logo + tagline)
- **LinkedIn Banner**: 1584 × 396px (logo + tagline)

---

## Implementation Code

### **React Component**
```tsx
import Logo from './components/Logo';

// Standard navbar usage
<Logo size={32} color="#FF5D73" showText={true} />

// Icon only for favicon
<Logo size={16} color="#FF5D73" showText={false} />

// Large hero usage
<Logo size={48} color="#FF5D73" showText={true} />

// Dark background
<Logo size={32} color="#FFFFFF" showText={true} />
```

### **HTML/CSS**
```html
<div class="logo-container">
  <img src="/logo.svg" alt="BookTrips" />
</div>
```

---

## Accessibility

### **Alt Text**
- Full logo: "BookTrips logo"
- Icon only: "BookTrips icon"
- Linked logo: "BookTrips home" or "Return to BookTrips homepage"

### **Contrast Ratios**
- Logo on white: 4.5:1 ✅ (WCAG AA compliant)
- Logo on black: 8.2:1 ✅ (WCAG AAA compliant)

---

## Design Philosophy

### **Minimalism**
Every element serves a purpose. No decorative flourishes, just clear communication.

### **Recognition**
The ticket shape is universally understood as representing events, while the pin dot suggests travel and destinations.

### **Versatility**
Works equally well at favicon size (16px) and billboard size, in color or monochrome.

### **Timelessness**
Avoids trendy design elements that will look dated. Classic geometry ensures longevity.

### **Friendliness**
Rounded corners and warm color create an approachable, welcoming feel.

---

## Brand Alignment

The logo visually reinforces BookTrips' core value proposition:
- **Ticket** = Events that need promotion
- **Pin** = Destinations and experiences
- **Connection** = Bringing organizers and attendees together

The perforation line subtly suggests the connection/separation between two parties (organizer and attendee) that BookTrips bridges.

---

## Export Guide

### **For Web Development**
```bash
# SVG (inline in React components)
<Logo size={32} color="#FF5D73" showText={true} />

# As image reference
<img src="/logo.svg" alt="BookTrips" width="120" height="40" />
```

### **For Design Tools**
1. Open `/src/components/Logo.tsx`
2. Copy SVG code from component
3. Import into Figma/Sketch/Adobe XD
4. Export in desired format

### **For Print Materials**
1. Export component as SVG
2. Open in Illustrator
3. Save as PDF or EPS
4. Ensure CMYK color mode for printing

---

## Version Control

**Current Version**: 1.0
**Last Updated**: January 2025
**Designer**: BookTrips Design Team
**Status**: Approved for all uses

---

## Questions?

For logo usage questions or to request custom variations:
- Email: hello@booktrips.com
- Check: `/src/components/Logo.tsx` for implementation
- Reference: This guide for specifications

---

**Remember**: A consistent brand presence builds trust. Always use the official logo files and follow these guidelines to maintain BookTrips' professional image across all touchpoints.
