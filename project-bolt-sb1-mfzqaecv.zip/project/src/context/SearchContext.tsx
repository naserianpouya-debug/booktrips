import { createContext, useContext, useState, ReactNode } from 'react';
import { Event } from '../types/event';

interface SearchFilters {
  country: string;
  city: string;
  date: Date | null;
  category: string;
  searchTerm: string;
}

interface SearchContextType {
  filters: SearchFilters;
  setCountry: (country: string) => void;
  setCity: (city: string) => void;
  setDate: (date: Date | null) => void;
  setCategory: (category: string) => void;
  setSearchTerm: (term: string) => void;
  getFilteredEvents: (eventList: Event[]) => Event[];
  resetFilters: () => void;
}

const defaultFilters: SearchFilters = {
  country: '',
  city: '',
  date: null,
  category: '',
  searchTerm: ''
};

const SearchContext = createContext<SearchContextType | undefined>(undefined);

export function SearchProvider({ children }: { children: ReactNode }) {
  const [filters, setFilters] = useState<SearchFilters>(defaultFilters);

  const setCountry = (country: string) => {
    setFilters(prev => ({ ...prev, country, city: '' }));
  };

  const setCity = (city: string) => {
    setFilters(prev => ({ ...prev, city }));
  };

  const setDate = (date: Date | null) => {
    setFilters(prev => ({ ...prev, date }));
  };

  const setCategory = (category: string) => {
    setFilters(prev => ({ ...prev, category }));
  };

  const setSearchTerm = (term: string) => {
    setFilters(prev => ({ ...prev, searchTerm: term }));
  };

  const resetFilters = () => {
    setFilters(defaultFilters);
  };

  const getFilteredEvents = (eventList: Event[]): Event[] => {
    return eventList.filter(event => {
      const matchesSearchTerm = !filters.searchTerm ||
        event.title.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
        event.location.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
        event.description.toLowerCase().includes(filters.searchTerm.toLowerCase());

      const matchesCategory = !filters.category ||
        event.category.toLowerCase() === filters.category.toLowerCase();

      const matchesLocation = !filters.city ||
        event.location.toLowerCase().includes(filters.city.toLowerCase());

      const matchesDate = !filters.date || event.date === formatDate(filters.date);

      return matchesSearchTerm && matchesCategory && matchesLocation && matchesDate;
    });
  };

  return (
    <SearchContext.Provider value={{
      filters,
      setCountry,
      setCity,
      setDate,
      setCategory,
      setSearchTerm,
      getFilteredEvents,
      resetFilters
    }}>
      {children}
    </SearchContext.Provider>
  );
}

export function useSearch() {
  const context = useContext(SearchContext);
  if (!context) {
    throw new Error('useSearch must be used within SearchProvider');
  }
  return context;
}

function formatDate(date: Date): string {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${months[date.getMonth()]} ${date.getDate()}, ${date.getFullYear()}`;
}
