import { useState, useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Calendar } from 'lucide-react';

interface DatePickerProps {
  selectedDate: Date | null;
  onDateSelect: (date: Date | null) => void;
}

type DateRangeOption = '1day' | '2days' | '3days' | '7days' | 'exact';

export default function DatePicker({ selectedDate, onDateSelect }: DatePickerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [dateRange, setDateRange] = useState<DateRangeOption>('exact');
  const pickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (pickerRef.current && !pickerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const daysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const firstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const dayNames = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];

  const previousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1));
  };

  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
  };

  const selectDate = (day: number, monthOffset: number = 0) => {
    const selected = new Date(
      currentMonth.getFullYear(),
      currentMonth.getMonth() + monthOffset,
      day
    );
    onDateSelect(selected);
    setIsOpen(false);
  };

  const clearDate = () => {
    onDateSelect(null);
    setIsOpen(false);
  };

  const formatDate = (date: Date | null) => {
    if (!date) return 'Select Date';
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const isToday = (day: number, monthOffset: number = 0) => {
    const today = new Date();
    const checkDate = new Date(
      currentMonth.getFullYear(),
      currentMonth.getMonth() + monthOffset,
      day
    );
    return (
      checkDate.getDate() === today.getDate() &&
      checkDate.getMonth() === today.getMonth() &&
      checkDate.getFullYear() === today.getFullYear()
    );
  };

  const isSelected = (day: number, monthOffset: number = 0) => {
    if (!selectedDate) return false;
    const checkDate = new Date(
      currentMonth.getFullYear(),
      currentMonth.getMonth() + monthOffset,
      day
    );
    return (
      checkDate.getDate() === selectedDate.getDate() &&
      checkDate.getMonth() === selectedDate.getMonth() &&
      checkDate.getFullYear() === selectedDate.getFullYear()
    );
  };

  const renderCalendar = (monthOffset: number = 0) => {
    const days = [];
    const targetMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + monthOffset);
    const totalDays = daysInMonth(targetMonth);
    const firstDay = firstDayOfMonth(targetMonth);

    const adjustedFirstDay = firstDay === 0 ? 6 : firstDay - 1;

    for (let i = 0; i < adjustedFirstDay; i++) {
      days.push(<div key={`empty-${i}`} style={{ padding: '8px' }} />);
    }

    for (let day = 1; day <= totalDays; day++) {
      const today = isToday(day, monthOffset);
      const selected = isSelected(day, monthOffset);
      days.push(
        <button
          key={day}
          onClick={() => selectDate(day, monthOffset)}
          style={{
            padding: '8px',
            border: 'none',
            background: selected ? '#FF5D73' : today ? 'rgba(255, 93, 115, 0.1)' : 'transparent',
            color: selected ? '#FFFFFF' : today ? '#FF5D73' : '#000000',
            borderRadius: '8px',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: selected || today ? '700' : '500',
            transition: 'all 0.2s ease'
          }}
          onMouseEnter={(e) => {
            if (!selected) {
              e.currentTarget.style.background = 'rgba(255, 93, 115, 0.15)';
            }
          }}
          onMouseLeave={(e) => {
            if (!selected) {
              e.currentTarget.style.background = today ? 'rgba(255, 93, 115, 0.1)' : 'transparent';
            }
          }}
        >
          {day}
        </button>
      );
    }

    return days;
  };

  const getNextMonth = () => {
    return new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1);
  };

  return (
    <div ref={pickerRef} style={{ position: 'relative', flex: 1, minWidth: '200px', zIndex: isOpen ? 2000 : 1 }}>
      <div
        onClick={() => setIsOpen(!isOpen)}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          padding: '12px 20px',
          background: 'rgba(255, 255, 255, 0.8)',
          borderRadius: '40px',
          border: '1px solid rgba(0, 0, 0, 0.05)',
          cursor: 'pointer',
          transition: 'all 0.2s ease'
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = 'rgba(255, 255, 255, 0.95)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = 'rgba(255, 255, 255, 0.8)';
        }}
      >
        <Calendar size={20} color="#7C7A7A" />
        <span style={{
          fontSize: '15px',
          fontWeight: '600',
          color: selectedDate ? '#494949' : '#7C7A7A',
          flex: 1
        }}>
          {formatDate(selectedDate)}
        </span>
      </div>

      {isOpen && (
        <div style={{
          position: 'absolute',
          top: '100%',
          left: 0,
          marginTop: '8px',
          background: 'rgba(255, 255, 255, 0.98)',
          backdropFilter: 'blur(20px)',
          borderRadius: '24px',
          padding: '20px',
          boxShadow: '0 12px 48px rgba(0, 0, 0, 0.15)',
          border: '1px solid rgba(0, 0, 0, 0.08)',
          zIndex: 2001,
          minWidth: '700px'
        }}>
          <div style={{
            display: 'flex',
            gap: '12px',
            marginBottom: '20px',
            paddingBottom: '16px',
            borderBottom: '1px solid rgba(0, 0, 0, 0.06)'
          }}>
            <button
              onClick={() => setDateRange('exact')}
              style={{
                padding: '8px 16px',
                background: dateRange === 'exact' ? '#FF5D73' : 'transparent',
                color: dateRange === 'exact' ? '#FFFFFF' : '#000000',
                border: dateRange === 'exact' ? 'none' : '1px solid #E0E0E0',
                borderRadius: '20px',
                fontSize: '14px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
            >
              Exact dates
            </button>
            <button
              onClick={() => setDateRange('1day')}
              style={{
                padding: '8px 16px',
                background: dateRange === '1day' ? '#F0F0F0' : 'transparent',
                color: '#000000',
                border: '1px solid #E0E0E0',
                borderRadius: '20px',
                fontSize: '14px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
            >
              ± 1 day
            </button>
            <button
              onClick={() => setDateRange('2days')}
              style={{
                padding: '8px 16px',
                background: dateRange === '2days' ? '#F0F0F0' : 'transparent',
                color: '#000000',
                border: '1px solid #E0E0E0',
                borderRadius: '20px',
                fontSize: '14px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
            >
              ± 2 days
            </button>
            <button
              onClick={() => setDateRange('3days')}
              style={{
                padding: '8px 16px',
                background: dateRange === '3days' ? '#F0F0F0' : 'transparent',
                color: '#000000',
                border: '1px solid #E0E0E0',
                borderRadius: '20px',
                fontSize: '14px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
            >
              ± 3 days
            </button>
            <button
              onClick={() => setDateRange('7days')}
              style={{
                padding: '8px 16px',
                background: dateRange === '7days' ? '#F0F0F0' : 'transparent',
                color: '#000000',
                border: '1px solid #E0E0E0',
                borderRadius: '20px',
                fontSize: '14px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
            >
              ± 7 days
            </button>
          </div>

          <div style={{
            display: 'flex',
            gap: '24px'
          }}>
            <div style={{ flex: 1 }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '16px'
              }}>
                <button
                  onClick={previousMonth}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    padding: '8px',
                    borderRadius: '8px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'all 0.2s ease'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 93, 115, 0.1)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <ChevronLeft size={20} color="#494949" />
                </button>

                <span style={{
                  fontSize: '16px',
                  fontWeight: '700',
                  color: '#000000'
                }}>
                  {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
                </span>

                <div style={{ width: '36px' }} />
              </div>

              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(7, 1fr)',
                gap: '4px',
                marginBottom: '8px'
              }}>
                {dayNames.map(day => (
                  <div
                    key={day}
                    style={{
                      textAlign: 'center',
                      fontSize: '12px',
                      fontWeight: '700',
                      color: '#7C7A7A',
                      padding: '8px'
                    }}
                  >
                    {day}
                  </div>
                ))}
              </div>

              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(7, 1fr)',
                gap: '4px'
              }}>
                {renderCalendar(0)}
              </div>
            </div>

            <div style={{ flex: 1 }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '16px'
              }}>
                <div style={{ width: '36px' }} />

                <span style={{
                  fontSize: '16px',
                  fontWeight: '700',
                  color: '#000000'
                }}>
                  {monthNames[getNextMonth().getMonth()]} {getNextMonth().getFullYear()}
                </span>

                <button
                  onClick={nextMonth}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    padding: '8px',
                    borderRadius: '8px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'all 0.2s ease'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 93, 115, 0.1)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <ChevronRight size={20} color="#494949" />
                </button>
              </div>

              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(7, 1fr)',
                gap: '4px',
                marginBottom: '8px'
              }}>
                {dayNames.map(day => (
                  <div
                    key={day}
                    style={{
                      textAlign: 'center',
                      fontSize: '12px',
                      fontWeight: '700',
                      color: '#7C7A7A',
                      padding: '8px'
                    }}
                  >
                    {day}
                  </div>
                ))}
              </div>

              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(7, 1fr)',
                gap: '4px'
              }}>
                {renderCalendar(1)}
              </div>
            </div>
          </div>

          <div style={{
            display: 'flex',
            gap: '8px',
            paddingTop: '16px',
            marginTop: '16px',
            borderTop: '1px solid rgba(0, 0, 0, 0.06)'
          }}>
            <button
              onClick={() => {
                onDateSelect(new Date());
                setIsOpen(false);
              }}
              style={{
                flex: 1,
                background: 'rgba(255, 93, 115, 0.1)',
                color: '#FF5D73',
                border: 'none',
                borderRadius: '12px',
                padding: '10px',
                fontSize: '14px',
                fontWeight: '700',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(255, 93, 115, 0.2)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'rgba(255, 93, 115, 0.1)';
              }}
            >
              Today
            </button>
            <button
              onClick={clearDate}
              style={{
                flex: 1,
                background: 'rgba(0, 0, 0, 0.05)',
                color: '#494949',
                border: 'none',
                borderRadius: '12px',
                padding: '10px',
                fontSize: '14px',
                fontWeight: '700',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(0, 0, 0, 0.1)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'rgba(0, 0, 0, 0.05)';
              }}
            >
              Clear
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
