import { useState, useEffect, FormEvent } from 'react';
import { X, Loader as Loader2, Upload } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { Event } from '../../types/event';

interface EventFormModalProps {
  event: Event | null;
  onClose: () => void;
  onSave: () => void;
}

export default function EventFormModal({ event, onClose, onSave }: EventFormModalProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const [formData, setFormData] = useState({
    title: '',
    date: '',
    location: '',
    category: 'Music',
    image: '',
    description: '',
    featured: false,
    trending: false,
    sponsored: false
  });

  useEffect(() => {
    if (event) {
      setFormData({
        title: event.title,
        date: event.date,
        location: event.location,
        category: event.category,
        image: event.image,
        description: event.description,
        featured: event.featured || false,
        trending: event.trending || false,
        sponsored: event.sponsored || false
      });
    }
  }, [event]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      if (event) {
        const { error: updateError } = await supabase
          .from('events')
          .update(formData)
          .eq('id', event.id);

        if (updateError) throw updateError;
        setSuccess('Event updated successfully!');
      } else {
        const { error: insertError } = await supabase
          .from('events')
          .insert([{ ...formData, created_by: user?.id }]);

        if (insertError) throw insertError;
        setSuccess('Event created successfully!');
      }

      setTimeout(() => {
        onSave();
      }, 1000);
    } catch (err: any) {
      setError(err.message || 'An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const categories = ['Music', 'Food', 'Art', 'Tech', 'Sports', 'Business', 'Entertainment', 'Health', 'Education', 'General'];

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0, 0, 0, 0.6)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999,
        padding: '20px',
        backdropFilter: 'blur(4px)'
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: '#FFFFFF',
          borderRadius: '24px',
          width: '100%',
          maxWidth: '700px',
          maxHeight: '90vh',
          overflow: 'auto',
          position: 'relative',
          boxShadow: '0 24px 64px rgba(0, 0, 0, 0.2)'
        }}
      >
        <div style={{
          position: 'sticky',
          top: 0,
          background: '#FFFFFF',
          borderBottom: '1px solid rgba(0, 0, 0, 0.08)',
          padding: '24px 32px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          zIndex: 1
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: '800',
            color: '#000000'
          }}>
            {event ? 'Edit Event' : 'Create New Event'}
          </h2>
          <button
            onClick={onClose}
            style={{
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              padding: '8px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              borderRadius: '8px',
              transition: 'background 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(0, 0, 0, 0.05)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'transparent';
            }}
          >
            <X size={24} color="#000000" />
          </button>
        </div>

        <form onSubmit={handleSubmit} style={{ padding: '32px' }}>
          {error && (
            <div style={{
              background: 'rgba(239, 68, 68, 0.1)',
              border: '2px solid #EF4444',
              borderRadius: '12px',
              padding: '16px',
              marginBottom: '24px',
              color: '#EF4444',
              fontSize: '14px',
              fontWeight: '600'
            }}>
              {error}
            </div>
          )}

          {success && (
            <div style={{
              background: 'rgba(76, 175, 80, 0.1)',
              border: '2px solid #4CAF50',
              borderRadius: '12px',
              padding: '16px',
              marginBottom: '24px',
              color: '#4CAF50',
              fontSize: '14px',
              fontWeight: '600'
            }}>
              {success}
            </div>
          )}

          <div style={{ marginBottom: '24px' }}>
            <label style={{
              display: 'block',
              fontSize: '14px',
              fontWeight: '700',
              color: '#000000',
              marginBottom: '8px'
            }}>
              Event Title *
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
              style={{
                width: '100%',
                padding: '14px 16px',
                border: '2px solid rgba(0, 0, 0, 0.1)',
                borderRadius: '12px',
                fontSize: '15px',
                fontWeight: '500',
                color: '#000000',
                outline: 'none',
                transition: 'border 0.2s ease'
              }}
              onFocus={(e) => {
                e.currentTarget.style.border = '2px solid #FF5D73';
              }}
              onBlur={(e) => {
                e.currentTarget.style.border = '2px solid rgba(0, 0, 0, 0.1)';
              }}
              placeholder="Enter event title"
              disabled={loading}
            />
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '20px',
            marginBottom: '24px'
          }}>
            <div>
              <label style={{
                display: 'block',
                fontSize: '14px',
                fontWeight: '700',
                color: '#000000',
                marginBottom: '8px'
              }}>
                Date *
              </label>
              <input
                type="text"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                required
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  border: '2px solid rgba(0, 0, 0, 0.1)',
                  borderRadius: '12px',
                  fontSize: '15px',
                  fontWeight: '500',
                  color: '#000000',
                  outline: 'none',
                  transition: 'border 0.2s ease'
                }}
                onFocus={(e) => {
                  e.currentTarget.style.border = '2px solid #FF5D73';
                }}
                onBlur={(e) => {
                  e.currentTarget.style.border = '2px solid rgba(0, 0, 0, 0.1)';
                }}
                placeholder="e.g., Oct 15, 2025"
                disabled={loading}
              />
            </div>

            <div>
              <label style={{
                display: 'block',
                fontSize: '14px',
                fontWeight: '700',
                color: '#000000',
                marginBottom: '8px'
              }}>
                Category *
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                required
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  border: '2px solid rgba(0, 0, 0, 0.1)',
                  borderRadius: '12px',
                  fontSize: '15px',
                  fontWeight: '500',
                  color: '#000000',
                  outline: 'none',
                  transition: 'border 0.2s ease',
                  cursor: 'pointer'
                }}
                onFocus={(e) => {
                  e.currentTarget.style.border = '2px solid #FF5D73';
                }}
                onBlur={(e) => {
                  e.currentTarget.style.border = '2px solid rgba(0, 0, 0, 0.1)';
                }}
                disabled={loading}
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          <div style={{ marginBottom: '24px' }}>
            <label style={{
              display: 'block',
              fontSize: '14px',
              fontWeight: '700',
              color: '#000000',
              marginBottom: '8px'
            }}>
              Location *
            </label>
            <input
              type="text"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              required
              style={{
                width: '100%',
                padding: '14px 16px',
                border: '2px solid rgba(0, 0, 0, 0.1)',
                borderRadius: '12px',
                fontSize: '15px',
                fontWeight: '500',
                color: '#000000',
                outline: 'none',
                transition: 'border 0.2s ease'
              }}
              onFocus={(e) => {
                e.currentTarget.style.border = '2px solid #FF5D73';
              }}
              onBlur={(e) => {
                e.currentTarget.style.border = '2px solid rgba(0, 0, 0, 0.1)';
              }}
              placeholder="Enter event location"
              disabled={loading}
            />
          </div>

          <div style={{ marginBottom: '24px' }}>
            <label style={{
              display: 'block',
              fontSize: '14px',
              fontWeight: '700',
              color: '#000000',
              marginBottom: '8px'
            }}>
              Image URL *
            </label>
            <input
              type="url"
              value={formData.image}
              onChange={(e) => setFormData({ ...formData, image: e.target.value })}
              required
              style={{
                width: '100%',
                padding: '14px 16px',
                border: '2px solid rgba(0, 0, 0, 0.1)',
                borderRadius: '12px',
                fontSize: '15px',
                fontWeight: '500',
                color: '#000000',
                outline: 'none',
                transition: 'border 0.2s ease'
              }}
              onFocus={(e) => {
                e.currentTarget.style.border = '2px solid #FF5D73';
              }}
              onBlur={(e) => {
                e.currentTarget.style.border = '2px solid rgba(0, 0, 0, 0.1)';
              }}
              placeholder="https://example.com/image.jpg"
              disabled={loading}
            />
            {formData.image && (
              <div style={{
                marginTop: '12px',
                borderRadius: '12px',
                overflow: 'hidden',
                border: '2px solid rgba(0, 0, 0, 0.1)'
              }}>
                <img
                  src={formData.image}
                  alt="Preview"
                  style={{
                    width: '100%',
                    height: '200px',
                    objectFit: 'cover'
                  }}
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>
            )}
          </div>

          <div style={{ marginBottom: '24px' }}>
            <label style={{
              display: 'block',
              fontSize: '14px',
              fontWeight: '700',
              color: '#000000',
              marginBottom: '8px'
            }}>
              Description *
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              required
              rows={4}
              style={{
                width: '100%',
                padding: '14px 16px',
                border: '2px solid rgba(0, 0, 0, 0.1)',
                borderRadius: '12px',
                fontSize: '15px',
                fontWeight: '500',
                color: '#000000',
                outline: 'none',
                transition: 'border 0.2s ease',
                resize: 'vertical',
                fontFamily: 'inherit'
              }}
              onFocus={(e) => {
                e.currentTarget.style.border = '2px solid #FF5D73';
              }}
              onBlur={(e) => {
                e.currentTarget.style.border = '2px solid rgba(0, 0, 0, 0.1)';
              }}
              placeholder="Enter event description"
              disabled={loading}
            />
          </div>

          <div style={{
            display: 'flex',
            gap: '20px',
            marginBottom: '32px',
            padding: '20px',
            background: 'rgba(0, 0, 0, 0.02)',
            borderRadius: '12px'
          }}>
            <label style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              cursor: 'pointer',
              userSelect: 'none'
            }}>
              <input
                type="checkbox"
                checked={formData.featured}
                onChange={(e) => setFormData({ ...formData, featured: e.target.checked })}
                style={{
                  width: '20px',
                  height: '20px',
                  cursor: 'pointer',
                  accentColor: '#FF5D73'
                }}
                disabled={loading}
              />
              <span style={{
                fontSize: '14px',
                fontWeight: '600',
                color: '#000000'
              }}>
                Featured
              </span>
            </label>

            <label style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              cursor: 'pointer',
              userSelect: 'none'
            }}>
              <input
                type="checkbox"
                checked={formData.trending}
                onChange={(e) => setFormData({ ...formData, trending: e.target.checked })}
                style={{
                  width: '20px',
                  height: '20px',
                  cursor: 'pointer',
                  accentColor: '#FF5D73'
                }}
                disabled={loading}
              />
              <span style={{
                fontSize: '14px',
                fontWeight: '600',
                color: '#000000'
              }}>
                Trending
              </span>
            </label>

            <label style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              cursor: 'pointer',
              userSelect: 'none'
            }}>
              <input
                type="checkbox"
                checked={formData.sponsored}
                onChange={(e) => setFormData({ ...formData, sponsored: e.target.checked })}
                style={{
                  width: '20px',
                  height: '20px',
                  cursor: 'pointer',
                  accentColor: '#FF5D73'
                }}
                disabled={loading}
              />
              <span style={{
                fontSize: '14px',
                fontWeight: '600',
                color: '#000000'
              }}>
                Sponsored
              </span>
            </label>
          </div>

          <div style={{
            display: 'flex',
            gap: '12px'
          }}>
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              style={{
                flex: 1,
                padding: '16px',
                background: 'rgba(0, 0, 0, 0.05)',
                color: '#000000',
                border: 'none',
                borderRadius: '12px',
                fontSize: '16px',
                fontWeight: '700',
                cursor: loading ? 'not-allowed' : 'pointer',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => {
                if (!loading) {
                  e.currentTarget.style.background = 'rgba(0, 0, 0, 0.1)';
                }
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'rgba(0, 0, 0, 0.05)';
              }}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              style={{
                flex: 1,
                padding: '16px',
                background: loading ? '#FFB3BF' : '#FF5D73',
                color: '#FFFFFF',
                border: 'none',
                borderRadius: '12px',
                fontSize: '16px',
                fontWeight: '700',
                cursor: loading ? 'not-allowed' : 'pointer',
                transition: 'all 0.2s ease',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px'
              }}
              onMouseEnter={(e) => {
                if (!loading) {
                  e.currentTarget.style.background = '#ff4560';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.boxShadow = '0 8px 20px rgba(255, 93, 115, 0.3)';
                }
              }}
              onMouseLeave={(e) => {
                if (!loading) {
                  e.currentTarget.style.background = '#FF5D73';
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }
              }}
            >
              {loading && <Loader2 size={20} className="animate-spin" />}
              {event ? 'Update Event' : 'Create Event'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
