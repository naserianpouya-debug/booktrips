import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';
import Logo from './Logo';

type PageType = 'home' | 'admin' | 'profile' | 'about' | 'how-it-works' | 'help-center' | 'terms' | 'privacy' | 'contact' | 'faq';

interface FooterProps {
  onNavigate?: (page: PageType) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer style={{
      background: 'rgba(0, 0, 0, 0.95)',
      backdropFilter: 'blur(20px)',
      marginTop: '80px',
      padding: '60px 20px 32px',
      position: 'relative',
      overflow: 'hidden'
    }}>
      <div style={{
        maxWidth: '1400px',
        margin: '0 auto',
        position: 'relative',
        zIndex: 2
      }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '48px',
          marginBottom: '48px'
        }}>
          <div>
            <div style={{ marginBottom: '16px' }}>
              <Logo size={36} color="#FF5D73" showText={true} />
            </div>
            <p style={{
              fontSize: '15px',
              color: 'rgba(255, 255, 255, 0.7)',
              lineHeight: '1.6',
              marginBottom: '24px',
              fontWeight: '500'
            }}>
              Connect event organizers with attendees. Discover and advertise amazing experiences worldwide.
            </p>
            <div style={{
              display: 'flex',
              gap: '12px'
            }}>
              {[Facebook, Twitter, Instagram, Linkedin].map((Icon, index) => (
                <button
                  key={index}
                  style={{
                    width: '44px',
                    height: '44px',
                    borderRadius: '50%',
                    background: 'rgba(255, 255, 255, 0.1)',
                    border: 'none',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    transition: 'all 0.3s ease'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#FF5D73';
                    e.currentTarget.style.transform = 'translateY(-4px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.1)';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}
                >
                  <Icon size={20} color="#FFFFFF" />
                </button>
              ))}
            </div>
          </div>

          <div>
            <h4 style={{
              fontSize: '18px',
              fontWeight: '700',
              color: '#FFFFFF',
              marginBottom: '20px'
            }}>
              Quick Links
            </h4>
            <ul style={{
              listStyle: 'none',
              padding: 0,
              margin: 0
            }}>
              {[
                { label: 'About Us', page: 'about' as const },
                { label: 'How It Works', page: 'how-it-works' as const },
                { label: 'Categories', page: null }
              ].map((link) => (
                <li key={link.label} style={{ marginBottom: '12px' }}>
                  <a
                    href={link.page ? `/${link.page}` : '/#categories'}
                    onClick={(e) => {
                      if (link.page && onNavigate) {
                        e.preventDefault();
                        onNavigate(link.page);
                      } else if (!link.page) {
                        e.preventDefault();

                        // Check if already on home page
                        const currentPath = window.location.pathname;
                        const isOnHomePage = currentPath === '/' || currentPath === '/index.html';

                        if (isOnHomePage) {
                          // Already on home page - just scroll to section
                          const section = document.getElementById('categories');
                          if (section) {
                            section.scrollIntoView({
                              behavior: 'smooth',
                              block: 'start'
                            });
                          }
                        } else {
                          // On different page - navigate to home first, then scroll
                          if (onNavigate) {
                            onNavigate('home');
                            // Wait for navigation to complete, then scroll
                            setTimeout(() => {
                              const section = document.getElementById('categories');
                              if (section) {
                                section.scrollIntoView({
                                  behavior: 'smooth',
                                  block: 'start'
                                });
                              }
                            }, 100);
                          }
                        }
                      }
                    }}
                    aria-label={link.label === 'Categories' ? 'Navigate to event categories section' : link.label}
                    style={{
                      color: 'rgba(255, 255, 255, 0.7)',
                      fontSize: '15px',
                      fontWeight: '500',
                      transition: 'color 0.2s ease',
                      textDecoration: 'none',
                      cursor: 'pointer'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.color = '#FF5D73'}
                    onMouseLeave={(e) => e.currentTarget.style.color = 'rgba(255, 255, 255, 0.7)'}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 style={{
              fontSize: '18px',
              fontWeight: '700',
              color: '#FFFFFF',
              marginBottom: '20px'
            }}>
              Support
            </h4>
            <ul style={{
              listStyle: 'none',
              padding: 0,
              margin: 0
            }}>
              {[
                { label: 'Help Center', page: 'help-center' as const },
                { label: 'Terms of Service', page: 'terms' as const },
                { label: 'Privacy Policy', page: 'privacy' as const },
                { label: 'Contact Us', page: 'contact' as const },
                { label: 'FAQ', page: 'faq' as const }
              ].map((link) => (
                <li key={link.label} style={{ marginBottom: '12px' }}>
                  <a
                    href={`/${link.page}`}
                    onClick={(e) => {
                      e.preventDefault();
                      if (onNavigate) {
                        onNavigate(link.page);
                      }
                    }}
                    style={{
                      color: 'rgba(255, 255, 255, 0.7)',
                      fontSize: '15px',
                      fontWeight: '500',
                      transition: 'color 0.2s ease',
                      textDecoration: 'none',
                      cursor: 'pointer'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.color = '#FF5D73'}
                    onMouseLeave={(e) => e.currentTarget.style.color = 'rgba(255, 255, 255, 0.7)'}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 style={{
              fontSize: '18px',
              fontWeight: '700',
              color: '#FFFFFF',
              marginBottom: '20px'
            }}>
              Contact
            </h4>
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '16px'
            }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                color: 'rgba(255, 255, 255, 0.7)',
                fontSize: '15px'
              }}>
                <Mail size={18} />
                <span>hello@booktrips.com</span>
              </div>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                color: 'rgba(255, 255, 255, 0.7)',
                fontSize: '15px'
              }}>
                <Phone size={18} />
                <span>+1 (555) 123-4567</span>
              </div>
              <div style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: '12px',
                color: 'rgba(255, 255, 255, 0.7)',
                fontSize: '15px'
              }}>
                <MapPin size={18} style={{ marginTop: '2px' }} />
                <span>123 Event Street,<br />New York, NY 10001</span>
              </div>
            </div>
          </div>
        </div>

        <div style={{
          borderTop: '1px solid rgba(255, 255, 255, 0.1)',
          paddingTop: '32px',
          textAlign: 'center',
          color: 'rgba(255, 255, 255, 0.5)',
          fontSize: '14px',
          fontWeight: '500'
        }}>
          © 2025 BookTrips. All rights reserved.
        </div>
      </div>

      <div style={{
        position: 'absolute',
        top: '-50%',
        right: '-10%',
        width: '600px',
        height: '600px',
        background: 'radial-gradient(circle, rgba(255, 93, 115, 0.15), transparent)',
        filter: 'blur(100px)',
        zIndex: 1
      }} />

      <style>{`
        @media (max-width: 768px) {
          div[style*="grid-template-columns"] {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </footer>
  );
}
