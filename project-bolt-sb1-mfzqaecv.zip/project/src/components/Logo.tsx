interface LogoProps {
  size?: number;
  color?: string;
  showText?: boolean;
}

export default function Logo({ size = 32, color = '#FF5D73', showText = true }: LogoProps) {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: '12px'
    }}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Minimalistic design: Ticket/Bookmark with location pin dot */}
        {/* Outer ticket shape */}
        <path
          d="M8 12C8 10.3431 9.34315 9 11 9H37C38.6569 9 40 10.3431 40 12V20C38.3431 20 37 21.3431 37 23C37 24.6569 38.3431 26 40 26V36C40 37.6569 38.6569 39 37 39H11C9.34315 39 8 37.6569 8 36V26C9.65685 26 11 24.6569 11 23C11 21.3431 9.65685 20 8 20V12Z"
          stroke={color}
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Vertical dashed line in middle */}
        <line x1="24" y1="13" x2="24" y2="19" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeDasharray="2 3" />
        <line x1="24" y1="27" x2="24" y2="35" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeDasharray="2 3" />

        {/* Location pin dot (centered, representing travel/destination) */}
        <circle cx="24" cy="23" r="3.5" fill={color} />
      </svg>

      {showText && (
        <span style={{
          fontSize: size * 0.75,
          fontWeight: '800',
          color: color,
          letterSpacing: '-0.5px',
          fontFamily: 'system-ui, -apple-system, sans-serif'
        }}>
          BookTrips
        </span>
      )}
    </div>
  );
}
