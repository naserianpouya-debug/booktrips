import EventCard from './EventCard';
import { Event } from '../types/event';
import { useSearch } from '../context/SearchContext';
import { useEvents } from '../hooks/useEvents';

interface EventsForYouProps {
  onEventClick: (event: Event) => void;
}

export default function EventsForYou({ onEventClick }: EventsForYouProps) {
  const { getFilteredEvents, filters } = useSearch();
  const { events: eventsForYou } = useEvents('all');
  const filteredEvents = getFilteredEvents(eventsForYou);
  const hasActiveFilters = filters.country || filters.city || filters.date || filters.category;

  if (hasActiveFilters && filteredEvents.length === 0) {
    return (
      <section style={{
        padding: '80px 20px',
        maxWidth: '1400px',
        margin: '0 auto',
        textAlign: 'center'
      }}>
        <h2 style={{
          fontSize: '42px',
          fontWeight: '800',
          color: '#000000',
          marginBottom: '16px',
          letterSpacing: '-1px'
        }}>
          Events For You
        </h2>
        <p style={{
          fontSize: '18px',
          color: '#7C7A7A',
          fontWeight: '500'
        }}>
          No events found matching your search criteria. Try adjusting your filters.
        </p>
      </section>
    );
  }

  return (
    <section style={{
      padding: '80px 20px',
      maxWidth: '1400px',
      margin: '0 auto',
      position: 'relative'
    }}>
      <h2 style={{
        fontSize: '42px',
        fontWeight: '800',
        color: '#000000',
        marginBottom: '40px',
        letterSpacing: '-1px'
      }}>
        Events For You
      </h2>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
        gap: '32px'
      }}>
        {filteredEvents.map((event) => (
          <EventCard key={event.id} event={event} onClick={() => onEventClick(event)} />
        ))}
      </div>

      <div style={{
        position: 'absolute',
        top: '20%',
        left: '10%',
        width: '200px',
        height: '200px',
        background: 'linear-gradient(135deg, rgba(255, 93, 115, 0.08), rgba(255, 93, 115, 0.02))',
        borderRadius: '50%',
        filter: 'blur(50px)',
        zIndex: -1,
        animation: 'float 7s ease-in-out infinite'
      }} />

      <style>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0px) translateX(0px);
          }
          50% {
            transform: translateY(-15px) translateX(10px);
          }
        }

        @media (max-width: 768px) {
          div[style*="grid-template-columns"] {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </section>
  );
}
