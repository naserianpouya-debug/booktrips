import { Menu, User, LogOut, Settings, Sun, CircleHelp as HelpCircle, Smartphone, Shield, Bookmark } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import AuthModal from './AuthModal';
import Logo from './Logo';

type PageType = 'home' | 'admin' | 'profile' | 'about' | 'how-it-works' | 'help-center' | 'terms' | 'privacy' | 'contact' | 'faq';

interface NavbarProps {
  onNavigate?: (page: PageType) => void;
  currentPage?: PageType;
}

export default function Navbar({ onNavigate, currentPage = 'home' }: NavbarProps) {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const { user, signOut } = useAuth();

  useEffect(() => {
    checkAdminStatus();
  }, [user]);

  const checkAdminStatus = async () => {
    if (!user) {
      setIsAdmin(false);
      return;
    }

    const { data } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .maybeSingle();

    setIsAdmin(data?.role === 'admin');
  };

  const handleSignOut = async () => {
    await signOut();
    setShowUserMenu(false);
    if (onNavigate) {
      onNavigate('home');
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false);
      }
    };

    if (showUserMenu) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showUserMenu]);

  return (
    <>
    <nav style={{
      position: 'fixed',
      top: '20px',
      left: '50%',
      transform: 'translateX(-50%)',
      width: '95%',
      maxWidth: '1400px',
      background: 'rgba(255, 255, 255, 0.7)',
      backdropFilter: 'blur(20px)',
      borderRadius: '60px',
      padding: '16px 32px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08)',
      border: '1px solid rgba(255, 255, 255, 0.3)',
      zIndex: 1000,
      transition: 'all 0.3s ease'
    }}>
      <div
        onClick={() => {
          if (onNavigate) {
            onNavigate('home');
          }
        }}
        style={{
          cursor: 'pointer',
          transition: 'opacity 0.2s ease'
        }}
        onMouseEnter={(e) => e.currentTarget.style.opacity = '0.7'}
        onMouseLeave={(e) => e.currentTarget.style.opacity = '1'}
      >
        <Logo size={32} color="#FF5D73" showText={true} />
      </div>

      <div style={{
        display: 'flex',
        gap: '40px',
        alignItems: 'center'
      }}>
        <div style={{
          display: 'flex',
          gap: '40px'
        }} className="nav-links">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              if (onNavigate) {
                onNavigate('home');
              }
            }}
            style={{
              color: currentPage === 'home' ? '#FF5D73' : '#000000',
              fontWeight: '600',
              fontSize: '15px',
              transition: 'color 0.2s ease',
              textDecoration: 'none',
              cursor: 'pointer'
            }}
            onMouseEnter={(e) => e.currentTarget.style.color = '#FF5D73'}
            onMouseLeave={(e) => e.currentTarget.style.color = currentPage === 'home' ? '#FF5D73' : '#000000'}>
            Home
          </a>
          <a
            href="/#categories"
            onClick={(e) => {
              e.preventDefault();

              // Check if already on home page
              const currentPath = window.location.pathname;
              const isOnHomePage = currentPath === '/' || currentPath === '/index.html';

              if (isOnHomePage) {
                // Already on home page - just scroll to section
                const element = document.getElementById('categories');
                if (element) {
                  element.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                  });
                }
              } else {
                // On different page - navigate to home first, then scroll
                if (onNavigate) {
                  onNavigate('home');
                  // Wait for navigation to complete, then scroll
                  setTimeout(() => {
                    const element = document.getElementById('categories');
                    if (element) {
                      element.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                      });
                    }
                  }, 100);
                }
              }
            }}
            aria-label="Navigate to event categories section"
            style={{
              color: '#7C7A7A',
              fontWeight: '600',
              fontSize: '15px',
              transition: 'color 0.2s ease',
              textDecoration: 'none',
              cursor: 'pointer'
            }}
            onMouseEnter={(e) => e.currentTarget.style.color = '#FF5D73'}
            onMouseLeave={(e) => e.currentTarget.style.color = '#7C7A7A'}>
            Categories
          </a>
          <a href="#" style={{
            color: '#7C7A7A',
            fontWeight: '600',
            fontSize: '15px',
            transition: 'color 0.2s ease'
          }} onMouseEnter={(e) => e.currentTarget.style.color = '#FF5D73'}
             onMouseLeave={(e) => e.currentTarget.style.color = '#7C7A7A'}>
            Saved
          </a>
          <a href="#" style={{
            color: '#7C7A7A',
            fontWeight: '600',
            fontSize: '15px',
            transition: 'color 0.2s ease'
          }} onMouseEnter={(e) => e.currentTarget.style.color = '#FF5D73'}
             onMouseLeave={(e) => e.currentTarget.style.color = '#7C7A7A'}>
            Profile
          </a>
        </div>

        {user ? (
          <div style={{ position: 'relative' }} ref={menuRef}>
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              style={{
                background: '#FF5D73',
                color: '#FFFFFF',
                border: 'none',
                borderRadius: '50%',
                width: '44px',
                height: '44px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                boxShadow: '0 4px 16px rgba(255, 93, 115, 0.3)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 6px 20px rgba(255, 93, 115, 0.4)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 4px 16px rgba(255, 93, 115, 0.3)';
              }}
            >
              <User size={20} />
            </button>

            {showUserMenu && (
              <div
                style={{
                  position: 'absolute',
                  top: '54px',
                  right: '0',
                  background: '#FFFFFF',
                  borderRadius: '16px',
                  boxShadow: '0 8px 32px rgba(0, 0, 0, 0.15)',
                  padding: '8px',
                  minWidth: '240px',
                  zIndex: 1001
                }}
              >
                <div style={{
                  padding: '12px 16px',
                  borderBottom: '1px solid rgba(0, 0, 0, 0.08)',
                  marginBottom: '4px'
                }}>
                  <div style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    color: '#000000',
                    marginBottom: '4px'
                  }}>
                    {user.email}
                  </div>
                  <div style={{
                    fontSize: '12px',
                    color: '#7C7A7A',
                    fontWeight: '500'
                  }}>
                    My Account
                  </div>
                </div>

                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    if (onNavigate) {
                      onNavigate('profile');
                    }
                  }}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '12px 16px',
                    background: currentPage === 'profile' ? 'rgba(255, 93, 115, 0.1)' : 'transparent',
                    border: 'none',
                    borderRadius: '12px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: currentPage === 'profile' ? '#FF5D73' : '#000000',
                    transition: 'background 0.2s ease',
                    textAlign: 'left'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 93, 115, 0.15)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = currentPage === 'profile' ? 'rgba(255, 93, 115, 0.1)' : 'transparent';
                  }}
                >
                  <Bookmark size={18} color={currentPage === 'profile' ? '#FF5D73' : '#000000'} />
                  Saved Events
                </button>

                {isAdmin && (
                  <>
                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        if (onNavigate) {
                          onNavigate(currentPage === 'admin' ? 'home' : 'admin');
                        }
                      }}
                      style={{
                        width: '100%',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px',
                        padding: '12px 16px',
                        background: currentPage === 'admin' ? 'rgba(255, 93, 115, 0.1)' : 'transparent',
                        border: 'none',
                        borderRadius: '12px',
                        cursor: 'pointer',
                        fontSize: '14px',
                        fontWeight: '600',
                        color: currentPage === 'admin' ? '#FF5D73' : '#000000',
                        transition: 'background 0.2s ease',
                        textAlign: 'left'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.background = 'rgba(255, 93, 115, 0.15)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.background = currentPage === 'admin' ? 'rgba(255, 93, 115, 0.1)' : 'transparent';
                      }}
                    >
                      <Shield size={18} color={currentPage === 'admin' ? '#FF5D73' : '#000000'} />
                      {currentPage === 'admin' ? 'Back to Home' : 'Admin Dashboard'}
                    </button>

                    <div style={{
                      height: '1px',
                      background: 'rgba(0, 0, 0, 0.08)',
                      margin: '4px 0'
                    }} />
                  </>
                )}

                <button
                  onClick={() => setShowUserMenu(false)}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '12px 16px',
                    background: 'transparent',
                    border: 'none',
                    borderRadius: '12px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#000000',
                    transition: 'background 0.2s ease',
                    textAlign: 'left'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 93, 115, 0.08)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <Settings size={18} color="#000000" />
                  Settings
                </button>

                <button
                  onClick={() => setShowUserMenu(false)}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '12px 16px',
                    background: 'transparent',
                    border: 'none',
                    borderRadius: '12px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#000000',
                    transition: 'background 0.2s ease',
                    textAlign: 'left'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 93, 115, 0.08)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <Sun size={18} color="#000000" />
                    Appearance
                  </div>
                  <span style={{
                    fontSize: '13px',
                    color: '#7C7A7A',
                    fontWeight: '500'
                  }}>
                    Always light
                  </span>
                </button>

                <button
                  onClick={() => setShowUserMenu(false)}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '12px 16px',
                    background: 'transparent',
                    border: 'none',
                    borderRadius: '12px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#000000',
                    transition: 'background 0.2s ease',
                    textAlign: 'left'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 93, 115, 0.08)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <HelpCircle size={18} color="#000000" />
                  Support
                </button>

                <button
                  onClick={() => setShowUserMenu(false)}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '12px 16px',
                    background: 'transparent',
                    border: 'none',
                    borderRadius: '12px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#000000',
                    transition: 'background 0.2s ease',
                    textAlign: 'left'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 93, 115, 0.08)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <Smartphone size={18} color="#000000" />
                  Download the app
                </button>

                <div style={{
                  height: '1px',
                  background: 'rgba(0, 0, 0, 0.08)',
                  margin: '4px 0'
                }} />

                <button
                  onClick={handleSignOut}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '12px 16px',
                    background: 'transparent',
                    border: 'none',
                    borderRadius: '12px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#000000',
                    transition: 'background 0.2s ease',
                    textAlign: 'left'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 93, 115, 0.08)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <LogOut size={18} color="#FF5D73" />
                  Log out
                </button>
              </div>
            )}
          </div>
        ) : (
          <button
            onClick={() => setIsAuthModalOpen(true)}
            style={{
              background: '#FF5D73',
              color: '#FFFFFF',
              border: 'none',
              borderRadius: '50px',
              padding: '12px 32px',
              fontSize: '15px',
              fontWeight: '700',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              boxShadow: '0 4px 16px rgba(255, 93, 115, 0.3)'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 6px 20px rgba(255, 93, 115, 0.4)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 4px 16px rgba(255, 93, 115, 0.3)';
            }}
          >
            Login / Signup
          </button>
        )}

        <button className="mobile-menu" style={{
          display: 'none',
          background: 'transparent',
          border: 'none',
          cursor: 'pointer',
          padding: '8px'
        }}>
          <Menu size={24} color="#000000" />
        </button>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .nav-links {
            display: none !important;
          }
          .mobile-menu {
            display: block !important;
          }
        }
      `}</style>
    </nav>

    <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
    </>
  );
}
