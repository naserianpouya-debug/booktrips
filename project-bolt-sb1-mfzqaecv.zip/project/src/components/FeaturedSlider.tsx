import { useRef, useEffect } from 'react';
import { Event } from '../types/event';
import { useSearch } from '../context/SearchContext';
import { useEvents } from '../hooks/useEvents';
import EventCardCompact from './EventCardCompact';

interface FeaturedSliderProps {
  onEventClick: (event: Event) => void;
}

export default function FeaturedSlider({ onEventClick }: FeaturedSliderProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const { getFilteredEvents } = useSearch();
  const { events: featuredEvents } = useEvents('featured');
  const filteredEvents = getFilteredEvents(featuredEvents);

  useEffect(() => {
    const scrollContainer = scrollRef.current;
    if (!scrollContainer) return;

    let scrollPosition = 0;
    const scrollSpeed = 0.5;
    let isPaused = false;

    const autoScroll = () => {
      if (scrollContainer && !isPaused) {
        scrollPosition += scrollSpeed;

        if (scrollPosition >= scrollContainer.scrollWidth / 2) {
          scrollPosition = 0;
        }

        scrollContainer.scrollLeft = scrollPosition;
      }
    };

    const intervalId = setInterval(autoScroll, 20);

    const handleMouseEnter = () => {
      isPaused = true;
    };

    const handleMouseLeave = () => {
      isPaused = false;
      scrollPosition = scrollContainer.scrollLeft;
    };

    scrollContainer.addEventListener('mouseenter', handleMouseEnter);
    scrollContainer.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      clearInterval(intervalId);
      scrollContainer.removeEventListener('mouseenter', handleMouseEnter);
      scrollContainer.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [filteredEvents]);

  return (
    <section style={{
      padding: '40px 20px 80px',
      position: 'relative',
      overflow: 'hidden'
    }}>
      <div style={{
        maxWidth: '1400px',
        margin: '0 auto'
      }}>
        <div style={{
          marginBottom: '32px'
        }}>
          <h2 style={{
            fontSize: '36px',
            fontWeight: '800',
            color: '#000000',
            letterSpacing: '-1px'
          }}>
            Featured Events
          </h2>
        </div>

        <div
          ref={scrollRef}
          style={{
            display: 'flex',
            gap: '24px',
            overflowX: 'auto',
            scrollbarWidth: 'none',
            msOverflowStyle: 'none',
            paddingBottom: '8px'
          }}
        >
          {/* IMPROVED LOOP STRUCTURE: Duplicate events for infinite scroll effect */}
          {[...filteredEvents, ...filteredEvents].map((event, index) => (
            <EventCardCompact
              key={`${event.id}-${index}`}
              event={event}
              onClick={() => onEventClick(event)}
            />
          ))}
        </div>
      </div>

      <style>{`
        div::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </section>
  );
}
