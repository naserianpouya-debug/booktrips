import { Calendar, MapPin, Bookmark, Share2, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';
import { Event } from '../types/event';
import { useBookmarks } from '../hooks/useBookmarks';
import { useAuth } from '../context/AuthContext';
import { useState } from 'react';

interface EventCardProps {
  event: Event;
  onClick?: () => void;
}

export default function EventCard({ event, onClick }: EventCardProps) {
  const { user } = useAuth();
  const { isBookmarked, toggleBookmark, loading } = useBookmarks();
  const [showShareMenu, setShowShareMenu] = useState(false);
  const bookmarked = isBookmarked(event.id);

  const handleBookmarkClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (user) {
      await toggleBookmark(event.id, event.title);
    }
  };

  const handleShareClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowShareMenu(!showShareMenu);
  };

  return (
    <>
      <style>{`
        @keyframes socialBounce {
          0%, 100% {
            transform: translateY(0) scale(1);
          }
          50% {
            transform: translateY(-4px) scale(1.15);
          }
        }

        @keyframes socialRotate {
          0% {
            transform: rotate(0deg) scale(1);
          }
          25% {
            transform: rotate(-10deg) scale(1.1);
          }
          75% {
            transform: rotate(10deg) scale(1.1);
          }
          100% {
            transform: rotate(0deg) scale(1);
          }
        }

        .social-icon:hover svg {
          animation: socialRotate 0.5s ease;
        }
      `}</style>
      <div style={{
      background: 'rgba(255, 255, 255, 0.7)',
      backdropFilter: 'blur(20px)',
      borderRadius: '24px',
      overflow: 'hidden',
      border: '1px solid rgba(255, 255, 255, 0.3)',
      boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08)',
      transition: 'all 0.3s ease',
      cursor: 'pointer',
      position: 'relative'
    }} onClick={onClick} onMouseEnter={(e) => {
      e.currentTarget.style.transform = 'translateY(-8px)';
      e.currentTarget.style.boxShadow = '0 16px 48px rgba(0, 0, 0, 0.12)';
    }} onMouseLeave={(e) => {
      e.currentTarget.style.transform = 'translateY(0)';
      e.currentTarget.style.boxShadow = '0 8px 32px rgba(0, 0, 0, 0.08)';
    }}>
      <div style={{
        height: '220px',
        background: `url(${event.image}) center/cover`,
        position: 'relative'
      }}>
        {event.sponsored && (
          <div style={{
            position: 'absolute',
            top: '16px',
            left: '16px',
            background: '#FF5D73',
            color: '#FFFFFF',
            padding: '6px 16px',
            borderRadius: '20px',
            fontSize: '12px',
            fontWeight: '700',
            letterSpacing: '0.5px'
          }}>
            SPONSORED
          </div>
        )}
        <div style={{
          position: 'absolute',
          top: '16px',
          right: '16px',
          background: '#FF5D73',
          color: '#FFFFFF',
          padding: '8px 16px',
          borderRadius: '20px',
          fontSize: '13px',
          fontWeight: '700'
        }}>
          {event.category}
        </div>
      </div>

      <div style={{ padding: '24px' }}>
        <h3 style={{
          fontSize: '20px',
          fontWeight: '800',
          color: '#000000',
          marginBottom: '12px',
          lineHeight: '1.3'
        }}>
          {event.title}
        </h3>

        <p style={{
          fontSize: '14px',
          color: '#7C7A7A',
          lineHeight: '1.6',
          marginBottom: '16px',
          fontWeight: '500'
        }}>
          {event.description}
        </p>

        <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '8px',
          marginBottom: '16px'
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            color: '#7C7A7A',
            fontSize: '14px'
          }}>
            <Calendar size={16} />
            <span style={{ fontWeight: '600' }}>{event.date}</span>
          </div>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            color: '#7C7A7A',
            fontSize: '14px'
          }}>
            <MapPin size={16} />
            <span style={{ fontWeight: '600' }}>{event.location}</span>
          </div>
        </div>

        <div style={{
          display: 'flex',
          gap: '8px',
          marginBottom: '16px',
          paddingTop: '16px',
          borderTop: '1px solid rgba(0, 0, 0, 0.06)'
        }}>
          <button className="social-icon" style={{
            background: 'transparent',
            border: 'none',
            cursor: 'pointer',
            padding: '8px',
            borderRadius: '50%',
            transition: 'all 0.2s ease',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }} onClick={(e) => e.stopPropagation()} onMouseEnter={(e) => {
            e.currentTarget.style.background = 'rgba(255, 93, 115, 0.1)';
          }} onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
          }}>
            <Facebook size={18} color="#7C7A7A" />
          </button>
          <button className="social-icon" style={{
            background: 'transparent',
            border: 'none',
            cursor: 'pointer',
            padding: '8px',
            borderRadius: '50%',
            transition: 'all 0.2s ease',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }} onClick={(e) => e.stopPropagation()} onMouseEnter={(e) => {
            e.currentTarget.style.background = 'rgba(255, 93, 115, 0.1)';
          }} onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
          }}>
            <Twitter size={18} color="#7C7A7A" />
          </button>
          <button className="social-icon" style={{
            background: 'transparent',
            border: 'none',
            cursor: 'pointer',
            padding: '8px',
            borderRadius: '50%',
            transition: 'all 0.2s ease',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }} onClick={(e) => e.stopPropagation()} onMouseEnter={(e) => {
            e.currentTarget.style.background = 'rgba(255, 93, 115, 0.1)';
          }} onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
          }}>
            <Instagram size={18} color="#7C7A7A" />
          </button>
          <button className="social-icon" style={{
            background: 'transparent',
            border: 'none',
            cursor: 'pointer',
            padding: '8px',
            borderRadius: '50%',
            transition: 'all 0.2s ease',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }} onClick={(e) => e.stopPropagation()} onMouseEnter={(e) => {
            e.currentTarget.style.background = 'rgba(255, 93, 115, 0.1)';
          }} onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
          }}>
            <Youtube size={18} color="#7C7A7A" />
          </button>
        </div>

        <div style={{
          display: 'flex',
          gap: '8px'
        }}>
          <button
            style={{
              flex: 1,
              background: bookmarked ? '#4CAF50' : '#FF5D73',
              color: '#FFFFFF',
              border: 'none',
              borderRadius: '12px',
              padding: '12px',
              fontSize: '14px',
              fontWeight: '700',
              cursor: loading || !user ? 'not-allowed' : 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '6px',
              transition: 'all 0.2s ease',
              opacity: !user ? 0.5 : 1
            }}
            onClick={handleBookmarkClick}
            disabled={loading || !user}
            title={!user ? 'Login to bookmark events' : bookmarked ? 'Remove bookmark' : 'Bookmark this event'}
            onMouseEnter={(e) => {
              if (user && !loading) {
                e.currentTarget.style.background = bookmarked ? '#45a049' : '#ff4560';
              }
            }}
            onMouseLeave={(e) => {
              if (user) {
                e.currentTarget.style.background = bookmarked ? '#4CAF50' : '#FF5D73';
              }
            }}>
            <Bookmark size={16} fill={bookmarked ? '#FFFFFF' : 'none'} />
            {bookmarked ? 'Saved' : 'Save'}
          </button>
          <button style={{
            flex: 1,
            background: 'rgba(255, 93, 115, 0.1)',
            color: '#FF5D73',
            border: 'none',
            borderRadius: '12px',
            padding: '12px',
            fontSize: '14px',
            fontWeight: '700',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '6px',
            transition: 'all 0.2s ease',
            position: 'relative'
          }} onClick={handleShareClick} onMouseEnter={(e) => {
            e.currentTarget.style.background = 'rgba(255, 93, 115, 0.2)';
          }} onMouseLeave={(e) => {
            e.currentTarget.style.background = 'rgba(255, 93, 115, 0.1)';
          }}>
            <Share2 size={16} />
            Share
          </button>
        </div>
      </div>
    </div>
    </>
  );
}
