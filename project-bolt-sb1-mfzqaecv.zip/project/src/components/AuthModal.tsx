import { useState, useEffect, FormEvent } from 'react';
import { X, Mail, Lock, Eye, EyeOff, Loader as Loader2, CircleAlert as AlertCircle, CircleCheck as CheckCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { analytics } from '../utils/analytics';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type AuthMode = 'login' | 'signup';

export default function AuthModal({ isOpen, onClose }: AuthModalProps) {
  const [mode, setMode] = useState<AuthMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [facebookLoading, setFacebookLoading] = useState(false);
  const [instagramLoading, setInstagramLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [confirmPasswordError, setConfirmPasswordError] = useState('');
  const [googleLoading, setGoogleLoading] = useState(false);

  const { signUp, signIn, signInWithGoogle, signInWithFacebook, signInWithInstagram } = useAuth();

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setMode('login');
      resetForm();
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  const resetForm = () => {
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setShowPassword(false);
    setShowConfirmPassword(false);
    setError('');
    setSuccess('');
    setEmailError('');
    setPasswordError('');
    setConfirmPasswordError('');
  };

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) {
      setEmailError('Email is required');
      return false;
    }
    if (!emailRegex.test(email)) {
      setEmailError('Please enter a valid email address');
      return false;
    }
    setEmailError('');
    return true;
  };

  const validatePassword = (password: string): boolean => {
    if (!password) {
      setPasswordError('Password is required');
      return false;
    }
    if (mode === 'signup' && password.length < 6) {
      setPasswordError('Password must be at least 6 characters');
      return false;
    }
    setPasswordError('');
    return true;
  };

  const validateConfirmPassword = (): boolean => {
    if (mode === 'signup') {
      if (!confirmPassword) {
        setConfirmPasswordError('Please confirm your password');
        return false;
      }
      if (password !== confirmPassword) {
        setConfirmPasswordError('Passwords do not match');
        return false;
      }
    }
    setConfirmPasswordError('');
    return true;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const isEmailValid = validateEmail(email);
    const isPasswordValid = validatePassword(password);
    const isConfirmPasswordValid = validateConfirmPassword();

    if (!isEmailValid || !isPasswordValid || !isConfirmPasswordValid) {
      return;
    }

    setLoading(true);

    try {
      if (mode === 'signup') {
        const { error } = await signUp(email, password);
        if (error) {
          setError(error.message || 'An error occurred during signup');
        } else {
          analytics.trackUserSignup('email');
          setSuccess('Account created successfully! You can now log in.');
          setTimeout(() => {
            setMode('login');
            setPassword('');
            setConfirmPassword('');
            setSuccess('');
          }, 2000);
        }
      } else {
        const { error } = await signIn(email, password, rememberMe);
        if (error) {
          setError(error.message || 'Invalid email or password');
        } else {
          analytics.trackUserLogin('email');
          setSuccess('Login successful!');
          setTimeout(() => {
            onClose();
            resetForm();
          }, 1000);
        }
      }
    } catch (err) {
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setError('');
    setGoogleLoading(true);
    try {
      const { error } = await signInWithGoogle();
      if (error) {
        setError(error.message || 'Google login failed');
      }
    } catch (err) {
      setError('An unexpected error occurred with Google login');
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleFacebookLogin = async () => {
    setError('');
    setFacebookLoading(true);
    try {
      const { error } = await signInWithFacebook();
      if (error) {
        setError(error.message || 'Facebook login failed');
      }
    } catch (err) {
      setError('An unexpected error occurred with Facebook login');
    } finally {
      setFacebookLoading(false);
    }
  };

  const handleInstagramLogin = async () => {
    setError('');
    setInstagramLoading(true);
    try {
      const { error } = await signInWithInstagram();
      if (error) {
        setError(error.message || 'Instagram login failed');
      }
    } catch (err) {
      setError('An unexpected error occurred with Instagram login');
    } finally {
      setInstagramLoading(false);
    }
  };

  const toggleMode = () => {
    setMode(mode === 'login' ? 'signup' : 'login');
    resetForm();
  };

  if (!isOpen) return null;

  return (
    <>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes slideUp {
          from {
            transform: translateY(30px);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
        .auth-modal-backdrop {
          animation: fadeIn 0.2s ease-out;
        }
        .auth-modal-content {
          animation: slideUp 0.3s ease-out;
        }
        .auth-input {
          transition: all 0.2s ease;
        }
        .auth-input:focus {
          outline: none;
          border-color: #FF5D73;
          box-shadow: 0 0 0 3px rgba(255, 93, 115, 0.1);
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
        .spinner {
          animation: spin 1s linear infinite;
        }
      `}</style>

      <div
        className="auth-modal-backdrop"
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0, 0, 0, 0.7)',
          backdropFilter: 'blur(8px)',
          zIndex: 2000,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '20px'
        }}
        onClick={onClose}
      >
        <div
          className="auth-modal-content"
          style={{
            background: '#FFFFFF',
            borderRadius: '24px',
            maxWidth: '480px',
            width: '100%',
            maxHeight: '90vh',
            overflow: 'auto',
            position: 'relative',
            boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)'
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={onClose}
            style={{
              position: 'absolute',
              top: '20px',
              right: '20px',
              background: 'rgba(0, 0, 0, 0.05)',
              border: 'none',
              borderRadius: '50%',
              width: '40px',
              height: '40px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              zIndex: 10,
              transition: 'all 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = '#FF5D73';
              const icon = e.currentTarget.querySelector('svg') as SVGElement;
              if (icon) icon.style.color = '#FFFFFF';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(0, 0, 0, 0.05)';
              const icon = e.currentTarget.querySelector('svg') as SVGElement;
              if (icon) icon.style.color = '#000000';
            }}
          >
            <X size={20} color="#000000" style={{ transition: 'color 0.2s ease' }} />
          </button>

          <div style={{ padding: '48px 40px' }}>
            <div style={{ textAlign: 'center', marginBottom: '32px' }}>
              <h2 style={{
                fontSize: '32px',
                fontWeight: '900',
                color: '#000000',
                marginBottom: '8px',
                letterSpacing: '-0.5px'
              }}>
                {mode === 'login' ? 'Welcome Back' : 'Create Account'}
              </h2>
              <p style={{
                fontSize: '15px',
                color: '#7C7A7A',
                fontWeight: '500'
              }}>
                {mode === 'login'
                  ? 'Log in to access your saved events'
                  : 'Sign up to start discovering events'}
              </p>
            </div>

            {error && (
              <div style={{
                background: 'rgba(239, 68, 68, 0.1)',
                border: '1px solid rgba(239, 68, 68, 0.3)',
                borderRadius: '12px',
                padding: '12px 16px',
                marginBottom: '24px',
                display: 'flex',
                alignItems: 'center',
                gap: '10px'
              }}>
                <AlertCircle size={20} color="#EF4444" />
                <span style={{ fontSize: '14px', color: '#EF4444', fontWeight: '600' }}>
                  {error}
                </span>
              </div>
            )}

            {success && (
              <div style={{
                background: 'rgba(34, 197, 94, 0.1)',
                border: '1px solid rgba(34, 197, 94, 0.3)',
                borderRadius: '12px',
                padding: '12px 16px',
                marginBottom: '24px',
                display: 'flex',
                alignItems: 'center',
                gap: '10px'
              }}>
                <CheckCircle size={20} color="#22C55E" />
                <span style={{ fontSize: '14px', color: '#22C55E', fontWeight: '600' }}>
                  {success}
                </span>
              </div>
            )}

            <form onSubmit={handleSubmit} style={{ marginBottom: '24px' }}>
              <div style={{ marginBottom: '20px' }}>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '700',
                  color: '#000000',
                  marginBottom: '8px'
                }}>
                  Email Address
                </label>
                <div style={{ position: 'relative' }}>
                  <Mail
                    size={20}
                    color="#7C7A7A"
                    style={{
                      position: 'absolute',
                      left: '16px',
                      top: '50%',
                      transform: 'translateY(-50%)',
                      pointerEvents: 'none'
                    }}
                  />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (emailError) setEmailError('');
                    }}
                    onBlur={() => validateEmail(email)}
                    className="auth-input"
                    placeholder="Enter your email"
                    style={{
                      width: '100%',
                      padding: '14px 16px 14px 48px',
                      border: emailError ? '2px solid #EF4444' : '2px solid rgba(0, 0, 0, 0.1)',
                      borderRadius: '12px',
                      fontSize: '15px',
                      fontWeight: '500',
                      color: '#000000'
                    }}
                    disabled={loading}
                  />
                </div>
                {emailError && (
                  <p style={{
                    fontSize: '13px',
                    color: '#EF4444',
                    marginTop: '6px',
                    fontWeight: '600'
                  }}>
                    {emailError}
                  </p>
                )}
              </div>

              <div style={{ marginBottom: mode === 'signup' ? '20px' : '24px' }}>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '700',
                  color: '#000000',
                  marginBottom: '8px'
                }}>
                  Password
                </label>
                <div style={{ position: 'relative' }}>
                  <Lock
                    size={20}
                    color="#7C7A7A"
                    style={{
                      position: 'absolute',
                      left: '16px',
                      top: '50%',
                      transform: 'translateY(-50%)',
                      pointerEvents: 'none'
                    }}
                  />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (passwordError) setPasswordError('');
                    }}
                    onBlur={() => validatePassword(password)}
                    className="auth-input"
                    placeholder="Enter your password"
                    style={{
                      width: '100%',
                      padding: '14px 48px 14px 48px',
                      border: passwordError ? '2px solid #EF4444' : '2px solid rgba(0, 0, 0, 0.1)',
                      borderRadius: '12px',
                      fontSize: '15px',
                      fontWeight: '500',
                      color: '#000000'
                    }}
                    disabled={loading}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    style={{
                      position: 'absolute',
                      right: '16px',
                      top: '50%',
                      transform: 'translateY(-50%)',
                      background: 'transparent',
                      border: 'none',
                      cursor: 'pointer',
                      padding: '4px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}
                  >
                    {showPassword ? (
                      <EyeOff size={20} color="#7C7A7A" />
                    ) : (
                      <Eye size={20} color="#7C7A7A" />
                    )}
                  </button>
                </div>
                {passwordError && (
                  <p style={{
                    fontSize: '13px',
                    color: '#EF4444',
                    marginTop: '6px',
                    fontWeight: '600'
                  }}>
                    {passwordError}
                  </p>
                )}
              </div>

              {mode === 'signup' && (
                <div style={{ marginBottom: '24px' }}>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '700',
                    color: '#000000',
                    marginBottom: '8px'
                  }}>
                    Confirm Password
                  </label>
                  <div style={{ position: 'relative' }}>
                    <Lock
                      size={20}
                      color="#7C7A7A"
                      style={{
                        position: 'absolute',
                        left: '16px',
                        top: '50%',
                        transform: 'translateY(-50%)',
                        pointerEvents: 'none'
                      }}
                    />
                    <input
                      type={showConfirmPassword ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={(e) => {
                        setConfirmPassword(e.target.value);
                        if (confirmPasswordError) setConfirmPasswordError('');
                      }}
                      onBlur={validateConfirmPassword}
                      className="auth-input"
                      placeholder="Confirm your password"
                      style={{
                        width: '100%',
                        padding: '14px 48px 14px 48px',
                        border: confirmPasswordError ? '2px solid #EF4444' : '2px solid rgba(0, 0, 0, 0.1)',
                        borderRadius: '12px',
                        fontSize: '15px',
                        fontWeight: '500',
                        color: '#000000'
                      }}
                      disabled={loading}
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      style={{
                        position: 'absolute',
                        right: '16px',
                        top: '50%',
                        transform: 'translateY(-50%)',
                        background: 'transparent',
                        border: 'none',
                        cursor: 'pointer',
                        padding: '4px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}
                    >
                      {showConfirmPassword ? (
                        <EyeOff size={20} color="#7C7A7A" />
                      ) : (
                        <Eye size={20} color="#7C7A7A" />
                      )}
                    </button>
                  </div>
                  {confirmPasswordError && (
                    <p style={{
                      fontSize: '13px',
                      color: '#EF4444',
                      marginTop: '6px',
                      fontWeight: '600'
                    }}>
                      {confirmPasswordError}
                    </p>
                  )}
                </div>
              )}

              {mode === 'login' && (
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginBottom: '24px'
                }}>
                  <label style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    cursor: 'pointer',
                    userSelect: 'none'
                  }}>
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      style={{
                        width: '20px',
                        height: '20px',
                        cursor: 'pointer',
                        accentColor: '#FF5D73'
                      }}
                    />
                    <span style={{
                      fontSize: '14px',
                      fontWeight: '600',
                      color: '#000000'
                    }}>
                      Keep me logged in
                    </span>
                  </label>
                  <span style={{
                    fontSize: '12px',
                    color: '#7C7A7A',
                    fontWeight: '500'
                  }}>
                    30 days
                  </span>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                style={{
                  width: '100%',
                  background: loading ? '#FFB3BF' : '#FF5D73',
                  color: '#FFFFFF',
                  border: 'none',
                  borderRadius: '12px',
                  padding: '16px',
                  fontSize: '16px',
                  fontWeight: '700',
                  cursor: loading ? 'not-allowed' : 'pointer',
                  transition: 'all 0.2s ease',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px'
                }}
                onMouseEnter={(e) => {
                  if (!loading) {
                    e.currentTarget.style.background = '#ff4560';
                    e.currentTarget.style.transform = 'translateY(-2px)';
                    e.currentTarget.style.boxShadow = '0 8px 20px rgba(255, 93, 115, 0.3)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (!loading) {
                    e.currentTarget.style.background = '#FF5D73';
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = 'none';
                  }
                }}
              >
                {loading && <Loader2 size={20} className="spinner" />}
                {loading ? 'Please wait...' : mode === 'login' ? 'Log In' : 'Sign Up'}
              </button>
            </form>

            <div style={{
              position: 'relative',
              textAlign: 'center',
              marginBottom: '24px'
            }}>
              <div style={{
                position: 'absolute',
                top: '50%',
                left: 0,
                right: 0,
                height: '1px',
                background: 'rgba(0, 0, 0, 0.1)'
              }} />
              <span style={{
                position: 'relative',
                background: '#FFFFFF',
                padding: '0 16px',
                fontSize: '14px',
                color: '#7C7A7A',
                fontWeight: '600'
              }}>
                Or continue with
              </span>
            </div>

            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={googleLoading || loading}
              style={{
                background: googleLoading ? 'rgba(255, 255, 255, 0.7)' : '#FFFFFF',
                color: '#000000',
                border: '2px solid rgba(0, 0, 0, 0.1)',
                borderRadius: '12px',
                padding: '14px',
                fontSize: '15px',
                fontWeight: '700',
                cursor: googleLoading || loading ? 'not-allowed' : 'pointer',
                transition: 'all 0.2s ease',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                marginBottom: '12px',
                width: '100%'
              }}
              onMouseEnter={(e) => {
                if (!googleLoading && !loading) {
                  e.currentTarget.style.background = '#F8F9FA';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.1)';
                }
              }}
              onMouseLeave={(e) => {
                if (!googleLoading && !loading) {
                  e.currentTarget.style.background = '#FFFFFF';
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }
              }}
            >
              {googleLoading ? (
                <Loader2 size={18} className="spinner" />
              ) : (
                <svg width="18" height="18" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
              )}
              Continue with Google
            </button>

            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '12px',
              marginBottom: '24px'
            }}>
              <button
                type="button"
                onClick={handleFacebookLogin}
                disabled={facebookLoading || loading}
                style={{
                  background: facebookLoading ? 'rgba(24, 119, 242, 0.7)' : '#1877F2',
                  color: '#FFFFFF',
                  border: 'none',
                  borderRadius: '12px',
                  padding: '14px',
                  fontSize: '15px',
                  fontWeight: '700',
                  cursor: facebookLoading || loading ? 'not-allowed' : 'pointer',
                  transition: 'all 0.2s ease',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px'
                }}
                onMouseEnter={(e) => {
                  if (!facebookLoading && !loading) {
                    e.currentTarget.style.background = '#166FE5';
                    e.currentTarget.style.transform = 'translateY(-2px)';
                    e.currentTarget.style.boxShadow = '0 4px 12px rgba(24, 119, 242, 0.3)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (!facebookLoading && !loading) {
                    e.currentTarget.style.background = '#1877F2';
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = 'none';
                  }
                }}
              >
                {facebookLoading ? (
                  <Loader2 size={18} className="spinner" />
                ) : (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                )}
                Facebook
              </button>

              <button
                type="button"
                onClick={handleInstagramLogin}
                disabled={instagramLoading || loading}
                style={{
                  background: instagramLoading ? 'rgba(225, 48, 108, 0.7)' : 'linear-gradient(45deg, #F58529, #DD2A7B, #8134AF, #515BD4)',
                  color: '#FFFFFF',
                  border: 'none',
                  borderRadius: '12px',
                  padding: '14px',
                  fontSize: '15px',
                  fontWeight: '700',
                  cursor: instagramLoading || loading ? 'not-allowed' : 'pointer',
                  transition: 'all 0.2s ease',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px'
                }}
                onMouseEnter={(e) => {
                  if (!instagramLoading && !loading) {
                    e.currentTarget.style.transform = 'translateY(-2px)';
                    e.currentTarget.style.boxShadow = '0 4px 12px rgba(225, 48, 108, 0.3)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (!instagramLoading && !loading) {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = 'none';
                  }
                }}
              >
                {instagramLoading ? (
                  <Loader2 size={18} className="spinner" />
                ) : (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                )}
                Instagram
              </button>
            </div>

            <div style={{
              textAlign: 'center',
              fontSize: '15px',
              color: '#7C7A7A',
              fontWeight: '500'
            }}>
              {mode === 'login' ? "Don't have an account? " : "Already have an account? "}
              <button
                type="button"
                onClick={toggleMode}
                disabled={loading}
                style={{
                  background: 'transparent',
                  border: 'none',
                  color: '#FF5D73',
                  fontWeight: '700',
                  cursor: loading ? 'not-allowed' : 'pointer',
                  fontSize: '15px',
                  textDecoration: 'underline'
                }}
              >
                {mode === 'login' ? 'Sign Up' : 'Log In'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
