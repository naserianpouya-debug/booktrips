import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useRef } from 'react';
import EventCard from './EventCard';
import { Event } from '../types/event';
import { useSearch } from '../context/SearchContext';
import { useEvents } from '../hooks/useEvents';

interface TrendingNowProps {
  onEventClick: (event: Event) => void;
}

export default function TrendingNow({ onEventClick }: TrendingNowProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const { getFilteredEvents } = useSearch();
  const { events: trendingEvents } = useEvents('trending');
  const filteredEvents = getFilteredEvents(trendingEvents);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 400;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section style={{
      padding: '80px 20px',
      background: 'linear-gradient(180deg, rgba(255, 93, 115, 0.03) 0%, rgba(255, 255, 255, 0) 100%)',
      position: 'relative'
    }}>
      <div style={{
        maxWidth: '1400px',
        margin: '0 auto'
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '40px'
        }}>
          <h2 style={{
            fontSize: '42px',
            fontWeight: '800',
            color: '#000000',
            letterSpacing: '-1px'
          }}>
            Trending Now
          </h2>

          <div style={{ display: 'flex', gap: '12px' }}>
            <button onClick={() => scroll('left')} style={{
              background: 'rgba(255, 255, 255, 0.8)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(0, 0, 0, 0.1)',
              borderRadius: '50%',
              width: '48px',
              height: '48px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.3s ease'
            }} onMouseEnter={(e) => {
              e.currentTarget.style.background = '#FF5D73';
              e.currentTarget.style.borderColor = '#FF5D73';
              const icon = e.currentTarget.querySelector('svg');
              if (icon) (icon as SVGElement).style.stroke = '#FFFFFF';
            }} onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.8)';
              e.currentTarget.style.borderColor = 'rgba(0, 0, 0, 0.1)';
              const icon = e.currentTarget.querySelector('svg');
              if (icon) (icon as SVGElement).style.stroke = '#000000';
            }}>
              <ChevronLeft size={24} />
            </button>
            <button onClick={() => scroll('right')} style={{
              background: 'rgba(255, 255, 255, 0.8)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(0, 0, 0, 0.1)',
              borderRadius: '50%',
              width: '48px',
              height: '48px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.3s ease'
            }} onMouseEnter={(e) => {
              e.currentTarget.style.background = '#FF5D73';
              e.currentTarget.style.borderColor = '#FF5D73';
              const icon = e.currentTarget.querySelector('svg');
              if (icon) (icon as SVGElement).style.stroke = '#FFFFFF';
            }} onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.8)';
              e.currentTarget.style.borderColor = 'rgba(0, 0, 0, 0.1)';
              const icon = e.currentTarget.querySelector('svg');
              if (icon) (icon as SVGElement).style.stroke = '#000000';
            }}>
              <ChevronRight size={24} />
            </button>
          </div>
        </div>

        <div
          ref={scrollRef}
          style={{
            display: 'flex',
            gap: '32px',
            overflowX: 'auto',
            scrollbarWidth: 'none',
            msOverflowStyle: 'none'
          }}
        >
          {filteredEvents.map((event) => (
            <div key={event.id} style={{ minWidth: '360px', maxWidth: '360px' }}>
              <EventCard event={event} onClick={() => onEventClick(event)} />
            </div>
          ))}
        </div>
      </div>

      <style>{`
        div::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </section>
  );
}
