import { useState, useEffect } from 'react';
import { Search, MapPin, Globe, Landmark, UtensilsCrossed, Mountain, Trophy, Music as MusicIcon, Palette } from 'lucide-react';
import DatePicker from './DatePicker';
import { useSearch } from '../context/SearchContext';
import { locationData, getCitiesByCountry } from '../data/locations';

const categories = [
  { id: 'culture', name: 'Culture', icon: Landmark },
  { id: 'food', name: 'Food', icon: UtensilsCrossed },
  { id: 'nature', name: 'Nature', icon: Mountain },
  { id: 'sports', name: 'Sports', icon: Trophy },
  { id: 'music', name: 'Music', icon: MusicIcon },
  { id: 'art', name: 'Art', icon: Palette }
];

export default function SearchBar() {
  const { filters, setCountry, setCity, setDate, setCategory } = useSearch();
  const [availableCities, setAvailableCities] = useState(getCitiesByCountry(''));

  return (
    <section id="categories" style={{
      padding: '40px 20px 80px',
      maxWidth: '1200px',
      margin: '0 auto',
      position: 'relative',
      zIndex: 100
    }}>
      <div style={{
        background: 'rgba(255, 255, 255, 0.6)',
        backdropFilter: 'blur(20px)',
        borderRadius: '60px',
        padding: '24px 32px',
        display: 'flex',
        alignItems: 'center',
        gap: '16px',
        border: '1px solid rgba(0, 0, 0, 0.06)',
        boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08)',
        flexWrap: 'wrap',
        marginBottom: '40px',
        position: 'relative',
        zIndex: 100
      }}>
        <div style={{
          flex: 1,
          minWidth: '200px',
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          padding: '12px 20px',
          background: 'rgba(255, 255, 255, 0.8)',
          borderRadius: '40px',
          border: '1px solid rgba(0, 0, 0, 0.05)'
        }}>
          <Globe size={20} color="#7C7A7A" />
          <select
            value={filters.country}
            onChange={(e) => {
              const countryId = e.target.value;
              setCountry(countryId);
              setAvailableCities(getCitiesByCountry(countryId));
            }}
            style={{
              border: 'none',
              background: 'transparent',
              fontSize: '15px',
              fontWeight: '600',
              color: '#494949',
              cursor: 'pointer',
              outline: 'none',
              flex: 1
            }}>
            <option value="">All Countries</option>
            {locationData.map(country => (
              <option key={country.id} value={country.id}>{country.name}</option>
            ))}
          </select>
        </div>

        <div style={{
          flex: 1,
          minWidth: '200px',
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          padding: '12px 20px',
          background: 'rgba(255, 255, 255, 0.8)',
          borderRadius: '40px',
          border: '1px solid rgba(0, 0, 0, 0.05)'
        }}>
          <MapPin size={20} color="#7C7A7A" />
          <select
            value={filters.city}
            onChange={(e) => setCity(e.target.value)}
            disabled={!filters.country}
            style={{
              border: 'none',
              background: 'transparent',
              fontSize: '15px',
              fontWeight: '600',
              color: filters.country ? '#494949' : '#BDBDBD',
              cursor: filters.country ? 'pointer' : 'not-allowed',
              outline: 'none',
              flex: 1
            }}>
            <option value="">All Cities</option>
            {availableCities.map(city => (
              <option key={city.id} value={city.name}>{city.name}</option>
            ))}
          </select>
        </div>

        <DatePicker selectedDate={filters.date} onDateSelect={setDate} />

        <button style={{
          background: '#FF5D73',
          color: '#FFFFFF',
          border: 'none',
          borderRadius: '50px',
          padding: '16px 40px',
          fontSize: '16px',
          fontWeight: '700',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          transition: 'all 0.3s ease',
          boxShadow: '0 4px 16px rgba(255, 93, 115, 0.3)'
        }} onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'scale(1.05)';
          e.currentTarget.style.boxShadow = '0 6px 20px rgba(255, 93, 115, 0.4)';
        }} onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'scale(1)';
          e.currentTarget.style.boxShadow = '0 4px 16px rgba(255, 93, 115, 0.3)';
        }}>
          <Search size={20} />
          Search
        </button>
      </div>

      <div>
        <h3 style={{
          fontSize: '24px',
          fontWeight: '700',
          color: '#000000',
          marginBottom: '24px'
        }}>
          Browse by category
        </h3>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
          gap: '16px'
        }}>
          {categories.map((category) => {
            const Icon = category.icon;
            const isSelected = filters.category === category.id;

            return (
              <div
                key={category.id}
                onClick={() => setCategory(isSelected ? '' : category.id)}
                style={{
                  background: isSelected
                    ? 'rgba(255, 93, 115, 0.15)'
                    : 'rgba(255, 255, 255, 0.6)',
                  backdropFilter: 'blur(20px)',
                  borderRadius: '16px',
                  padding: '32px 20px',
                  border: isSelected
                    ? '2px solid #FF5D73'
                    : '1px solid rgba(0, 0, 0, 0.06)',
                  boxShadow: '0 4px 16px rgba(0, 0, 0, 0.08)',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  textAlign: 'center',
                  position: 'relative',
                  overflow: 'hidden'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-4px)';
                  e.currentTarget.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.12)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.08)';
                }}
              >
                <div
                  className={isSelected ? 'category-icon-selected' : 'category-icon'}
                  style={{
                    width: '60px',
                    height: '60px',
                    margin: '0 auto 16px',
                    background: isSelected
                      ? 'linear-gradient(135deg, #FF5D73, #ff4560)'
                      : 'linear-gradient(135deg, rgba(255, 93, 115, 0.1), rgba(255, 93, 115, 0.05))',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'all 0.3s ease'
                  }}>
                  <Icon
                    size={28}
                    color={isSelected ? '#FFFFFF' : '#FF5D73'}
                    strokeWidth={2}
                  />
                </div>
                <div style={{
                  fontSize: '16px',
                  fontWeight: '700',
                  color: isSelected ? '#FF5D73' : '#000000',
                  transition: 'all 0.3s ease'
                }}>
                  {category.name}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <style>{`
        @keyframes iconBounce {
          0%, 100% {
            transform: translateY(0) rotate(0deg);
          }
          25% {
            transform: translateY(-5px) rotate(-5deg);
          }
          75% {
            transform: translateY(-3px) rotate(5deg);
          }
        }

        @keyframes iconPulse {
          0%, 100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.1);
          }
        }

        .category-icon:hover {
          animation: iconBounce 0.6s ease;
        }

        .category-icon-selected {
          animation: iconPulse 2s ease-in-out infinite;
        }

        @media (max-width: 768px) {
          div[style*="flex: 1"] {
            flex: 1 1 100% !important;
          }
        }
      `}</style>
    </section>
  );
}
