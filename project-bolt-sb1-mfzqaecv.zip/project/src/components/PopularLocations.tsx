import { MapPin } from 'lucide-react';

interface Location {
  id: string;
  name: string;
  country: string;
  image: string;
  eventsCount: number;
}

const popularLocations: Location[] = [
  {
    id: 'berlin',
    name: 'Berlin',
    country: 'Germany',
    image: 'https://images.pexels.com/photos/2570063/pexels-photo-2570063.jpeg?auto=compress&cs=tinysrgb&w=800',
    eventsCount: 245
  },
  {
    id: 'paris',
    name: 'Paris',
    country: 'France',
    image: 'https://images.pexels.com/photos/338515/pexels-photo-338515.jpeg?auto=compress&cs=tinysrgb&w=800',
    eventsCount: 328
  },
  {
    id: 'london',
    name: 'London',
    country: 'United Kingdom',
    image: 'https://images.pexels.com/photos/460672/pexels-photo-460672.jpeg?auto=compress&cs=tinysrgb&w=800',
    eventsCount: 412
  },
  {
    id: 'newyork',
    name: 'New York',
    country: 'United States',
    image: 'https://images.pexels.com/photos/466685/pexels-photo-466685.jpeg?auto=compress&cs=tinysrgb&w=800',
    eventsCount: 567
  },
  {
    id: 'rome',
    name: 'Rome',
    country: 'Italy',
    image: 'https://images.pexels.com/photos/2422259/pexels-photo-2422259.jpeg?auto=compress&cs=tinysrgb&w=800',
    eventsCount: 189
  },
  {
    id: 'tokyo',
    name: 'Tokyo',
    country: 'Japan',
    image: 'https://images.pexels.com/photos/2614818/pexels-photo-2614818.jpeg?auto=compress&cs=tinysrgb&w=800',
    eventsCount: 298
  },
  {
    id: 'barcelona',
    name: 'Barcelona',
    country: 'Spain',
    image: 'https://images.pexels.com/photos/819764/pexels-photo-819764.jpeg?auto=compress&cs=tinysrgb&w=800',
    eventsCount: 203
  },
  {
    id: 'amsterdam',
    name: 'Amsterdam',
    country: 'Netherlands',
    image: 'https://images.pexels.com/photos/2031706/pexels-photo-2031706.jpeg?auto=compress&cs=tinysrgb&w=800',
    eventsCount: 156
  }
];

interface PopularLocationsProps {
  onCityClick: (cityId: string) => void;
}

export default function PopularLocations({ onCityClick }: PopularLocationsProps) {
  return (
    <section style={{
      padding: '80px 20px',
      maxWidth: '1400px',
      margin: '0 auto',
      position: 'relative'
    }}>
      <h2 style={{
        fontSize: '42px',
        fontWeight: '800',
        color: '#000000',
        marginBottom: '16px',
        letterSpacing: '-1px'
      }}>
        Popular Locations
      </h2>

      <p style={{
        fontSize: '18px',
        color: '#7C7A7A',
        marginBottom: '40px',
        fontWeight: '500'
      }}>
        Discover exciting events in the world's most vibrant cities
      </p>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
        gap: '24px'
      }}>
        {popularLocations.map((location) => (
          <div
            key={location.id}
            onClick={() => onCityClick(location.id)}
            style={{
              position: 'relative',
              height: '320px',
              borderRadius: '24px',
              overflow: 'hidden',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08)'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-8px)';
              e.currentTarget.style.boxShadow = '0 16px 48px rgba(0, 0, 0, 0.15)';
              const img = e.currentTarget.querySelector('.location-image') as HTMLDivElement;
              if (img) img.style.transform = 'scale(1.1)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 8px 32px rgba(0, 0, 0, 0.08)';
              const img = e.currentTarget.querySelector('.location-image') as HTMLDivElement;
              if (img) img.style.transform = 'scale(1)';
            }}
          >
            <div
              className="location-image"
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                background: `url(${location.image}) center/cover`,
                transition: 'transform 0.5s ease'
              }}
            />

            <div style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              background: 'linear-gradient(180deg, rgba(0, 0, 0, 0.1) 0%, rgba(0, 0, 0, 0.7) 100%)',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'flex-end',
              padding: '24px'
            }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                marginBottom: '8px'
              }}>
                <MapPin size={18} color="#FFFFFF" />
                <span style={{
                  fontSize: '14px',
                  color: '#FFFFFF',
                  fontWeight: '600',
                  opacity: 0.9
                }}>
                  {location.country}
                </span>
              </div>

              <h3 style={{
                fontSize: '28px',
                fontWeight: '800',
                color: '#FFFFFF',
                marginBottom: '8px',
                letterSpacing: '-0.5px'
              }}>
                {location.name}
              </h3>

              <div style={{
                display: 'inline-block',
                background: 'rgba(255, 93, 115, 0.9)',
                backdropFilter: 'blur(10px)',
                padding: '8px 16px',
                borderRadius: '20px',
                fontSize: '13px',
                fontWeight: '700',
                color: '#FFFFFF',
                width: 'fit-content'
              }}>
                {location.eventsCount} Events
              </div>
            </div>
          </div>
        ))}
      </div>

      <div style={{
        position: 'absolute',
        top: '30%',
        right: '5%',
        width: '250px',
        height: '250px',
        background: 'linear-gradient(135deg, rgba(255, 93, 115, 0.08), rgba(255, 93, 115, 0.02))',
        borderRadius: '50%',
        filter: 'blur(60px)',
        zIndex: -1,
        animation: 'locationFloat 8s ease-in-out infinite'
      }} />

      <style>{`
        @keyframes locationFloat {
          0%, 100% {
            transform: translateY(0px) translateX(0px);
          }
          50% {
            transform: translateY(-20px) translateX(-15px);
          }
        }

        @media (max-width: 768px) {
          div[style*="grid-template-columns"] {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </section>
  );
}
