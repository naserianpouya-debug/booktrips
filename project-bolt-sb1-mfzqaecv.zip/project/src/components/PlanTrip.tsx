import { Plane, Hotel, Car, Map } from 'lucide-react';

export default function PlanTrip() {
  return (
    <section
      id="categories"
      aria-label="Event categories and trip planning"
      style={{
        padding: '80px 20px',
        maxWidth: '1400px',
        margin: '0 auto',
        scrollMarginTop: '100px'
      }}>
      <h2 style={{
        fontSize: '42px',
        fontWeight: '800',
        color: '#000000',
        marginBottom: '16px',
        letterSpacing: '-1px'
      }}>
        Plan Your Trip
      </h2>

      <p style={{
        fontSize: '18px',
        color: '#7C7A7A',
        marginBottom: '40px',
        fontWeight: '500'
      }}>
        Make the most of your event experience with our travel planning tools
      </p>

      <div style={{
        background: 'rgba(255, 255, 255, 0.6)',
        backdropFilter: 'blur(20px)',
        borderRadius: '32px',
        padding: '48px',
        border: '1px solid rgba(0, 0, 0, 0.06)',
        boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08)'
      }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          gap: '32px'
        }}>
          <div style={{
            textAlign: 'center',
            padding: '32px',
            background: 'rgba(255, 255, 255, 0.8)',
            borderRadius: '24px',
            transition: 'all 0.3s ease',
            cursor: 'pointer'
          }} onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-8px)';
            e.currentTarget.style.boxShadow = '0 12px 32px rgba(255, 93, 115, 0.15)';
          }} onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.boxShadow = 'none';
          }}>
            <div className="trip-icon" style={{
              width: '72px',
              height: '72px',
              background: 'linear-gradient(135deg, #FF5D73, #ff4560)',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 20px',
              boxShadow: '0 8px 24px rgba(255, 93, 115, 0.3)'
            }}>
              <Plane size={32} color="#FFFFFF" />
            </div>
            <h3 style={{
              fontSize: '20px',
              fontWeight: '700',
              color: '#000000',
              marginBottom: '8px'
            }}>
              Flights
            </h3>
            <p style={{
              fontSize: '14px',
              color: '#7C7A7A',
              fontWeight: '500'
            }}>
              Find best flight deals
            </p>
          </div>

          <div style={{
            textAlign: 'center',
            padding: '32px',
            background: 'rgba(255, 255, 255, 0.8)',
            borderRadius: '24px',
            transition: 'all 0.3s ease',
            cursor: 'pointer'
          }} onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-8px)';
            e.currentTarget.style.boxShadow = '0 12px 32px rgba(255, 93, 115, 0.15)';
          }} onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.boxShadow = 'none';
          }}>
            <div className="trip-icon" style={{
              width: '72px',
              height: '72px',
              background: 'linear-gradient(135deg, #FF5D73, #ff4560)',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 20px',
              boxShadow: '0 8px 24px rgba(255, 93, 115, 0.3)'
            }}>
              <Hotel size={32} color="#FFFFFF" />
            </div>
            <h3 style={{
              fontSize: '20px',
              fontWeight: '700',
              color: '#000000',
              marginBottom: '8px'
            }}>
              Hotels
            </h3>
            <p style={{
              fontSize: '14px',
              color: '#7C7A7A',
              fontWeight: '500'
            }}>
              Book nearby stays
            </p>
          </div>

          <div style={{
            textAlign: 'center',
            padding: '32px',
            background: 'rgba(255, 255, 255, 0.8)',
            borderRadius: '24px',
            transition: 'all 0.3s ease',
            cursor: 'pointer'
          }} onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-8px)';
            e.currentTarget.style.boxShadow = '0 12px 32px rgba(255, 93, 115, 0.15)';
          }} onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.boxShadow = 'none';
          }}>
            <div className="trip-icon" style={{
              width: '72px',
              height: '72px',
              background: 'linear-gradient(135deg, #FF5D73, #ff4560)',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 20px',
              boxShadow: '0 8px 24px rgba(255, 93, 115, 0.3)'
            }}>
              <Car size={32} color="#FFFFFF" />
            </div>
            <h3 style={{
              fontSize: '20px',
              fontWeight: '700',
              color: '#000000',
              marginBottom: '8px'
            }}>
              Rentals
            </h3>
            <p style={{
              fontSize: '14px',
              color: '#7C7A7A',
              fontWeight: '500'
            }}>
              Rent a car easily
            </p>
          </div>

          <div style={{
            textAlign: 'center',
            padding: '32px',
            background: 'rgba(255, 255, 255, 0.8)',
            borderRadius: '24px',
            transition: 'all 0.3s ease',
            cursor: 'pointer'
          }} onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-8px)';
            e.currentTarget.style.boxShadow = '0 12px 32px rgba(255, 93, 115, 0.15)';
          }} onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.boxShadow = 'none';
          }}>
            <div className="trip-icon" style={{
              width: '72px',
              height: '72px',
              background: 'linear-gradient(135deg, #FF5D73, #ff4560)',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 20px',
              boxShadow: '0 8px 24px rgba(255, 93, 115, 0.3)'
            }}>
              <Map size={32} color="#FFFFFF" />
            </div>
            <h3 style={{
              fontSize: '20px',
              fontWeight: '700',
              color: '#000000',
              marginBottom: '8px'
            }}>
              Guides
            </h3>
            <p style={{
              fontSize: '14px',
              color: '#7C7A7A',
              fontWeight: '500'
            }}>
              Explore city guides
            </p>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes tripIconFloat {
          0%, 100% {
            transform: translateY(0) rotate(0deg);
          }
          25% {
            transform: translateY(-8px) rotate(-5deg);
          }
          75% {
            transform: translateY(-8px) rotate(5deg);
          }
        }

        @keyframes tripIconScale {
          0%, 100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.15);
          }
        }

        .trip-icon:hover {
          animation: tripIconFloat 0.6s ease;
        }

        .trip-icon:hover svg {
          animation: tripIconScale 0.6s ease;
        }

        @media (max-width: 768px) {
          div[style*="grid-template-columns"] {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </section>
  );
}
