import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <section style={{
      paddingTop: '140px',
      paddingBottom: '60px',
      textAlign: 'center',
      position: 'relative',
      overflow: 'hidden',
      minHeight: '500px'
    }}>
      <div style={{
        maxWidth: '900px',
        margin: '0 auto',
        padding: '0 20px',
        position: 'relative',
        zIndex: 2
      }}>
        <h1 style={{
          fontSize: '64px',
          fontWeight: '900',
          color: '#000000',
          lineHeight: '1.2',
          marginBottom: '24px',
          letterSpacing: '-2px'
        }}>
          Connect with amazing events everywhere
        </h1>

        <p style={{
          fontSize: '20px',
          color: '#7C7A7A',
          lineHeight: '1.6',
          marginBottom: '40px',
          fontWeight: '500'
        }}>
          Discover and advertise events that matter. BookTrips connects event organizers with enthusiastic attendees.
        </p>

        <button style={{
          background: '#FF5D73',
          color: '#FFFFFF',
          border: 'none',
          borderRadius: '50px',
          padding: '18px 48px',
          fontSize: '17px',
          fontWeight: '700',
          cursor: 'pointer',
          display: 'inline-flex',
          alignItems: 'center',
          gap: '12px',
          transition: 'all 0.3s ease',
          boxShadow: '0 8px 24px rgba(255, 93, 115, 0.35)'
        }} onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'translateY(-3px)';
          e.currentTarget.style.boxShadow = '0 12px 32px rgba(255, 93, 115, 0.45)';
        }} onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'translateY(0)';
          e.currentTarget.style.boxShadow = '0 8px 24px rgba(255, 93, 115, 0.35)';
        }}>
          Start discovering events
          <ArrowRight size={20} />
        </button>
      </div>

      <div style={{
        position: 'absolute',
        top: '10%',
        left: '-5%',
        width: '300px',
        height: '300px',
        background: 'linear-gradient(135deg, rgba(255, 93, 115, 0.15), rgba(255, 93, 115, 0.05))',
        borderRadius: '50%',
        filter: 'blur(60px)',
        zIndex: 1,
        animation: 'float 6s ease-in-out infinite'
      }} />

      <div style={{
        position: 'absolute',
        top: '30%',
        right: '-10%',
        width: '400px',
        height: '400px',
        background: 'linear-gradient(135deg, rgba(255, 93, 115, 0.1), rgba(255, 93, 115, 0.03))',
        borderRadius: '50%',
        filter: 'blur(80px)',
        zIndex: 1,
        animation: 'float 8s ease-in-out infinite'
      }} />

      <div style={{
        position: 'absolute',
        bottom: '10%',
        left: '20%',
        width: '200px',
        height: '200px',
        background: 'linear-gradient(135deg, rgba(255, 93, 115, 0.12), rgba(255, 93, 115, 0.04))',
        borderRadius: '50%',
        filter: 'blur(70px)',
        zIndex: 1,
        animation: 'float 7s ease-in-out infinite'
      }} />

      <style>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0px) translateX(0px);
          }
          50% {
            transform: translateY(-20px) translateX(10px);
          }
        }

        @media (max-width: 768px) {
          h1 {
            font-size: 42px !important;
          }
          p {
            font-size: 18px !important;
          }
        }
      `}</style>
    </section>
  );
}
