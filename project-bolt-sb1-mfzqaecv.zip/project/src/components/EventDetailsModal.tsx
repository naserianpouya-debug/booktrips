import { X, Calendar, MapPin, Users, Clock, Tag, ExternalLink, Bookmark, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';
import { Event } from '../data/events';
import { useEffect } from 'react';

interface EventDetailsModalProps {
  event: Event | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function EventDetailsModal({ event, isOpen, onClose }: EventDetailsModalProps) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  if (!isOpen || !event) return null;

  return (
    <>
      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes slideUp {
          from {
            transform: translateY(30px);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }

        .modal-backdrop {
          animation: fadeIn 0.2s ease-out;
        }

        .modal-content {
          animation: slideUp 0.3s ease-out;
        }

        .modal-scroll::-webkit-scrollbar {
          width: 8px;
        }

        .modal-scroll::-webkit-scrollbar-track {
          background: rgba(0, 0, 0, 0.05);
          border-radius: 4px;
        }

        .modal-scroll::-webkit-scrollbar-thumb {
          background: rgba(255, 93, 115, 0.3);
          border-radius: 4px;
        }

        .modal-scroll::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 93, 115, 0.5);
        }

        @keyframes socialRotate {
          0% {
            transform: rotate(0deg) scale(1);
          }
          25% {
            transform: rotate(-10deg) scale(1.1);
          }
          75% {
            transform: rotate(10deg) scale(1.1);
          }
          100% {
            transform: rotate(0deg) scale(1);
          }
        }

        .modal-social-icon:hover svg {
          animation: socialRotate 0.5s ease;
        }
      `}</style>

      <div
        className="modal-backdrop"
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0, 0, 0, 0.7)',
          backdropFilter: 'blur(8px)',
          zIndex: 1000,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '20px'
        }}
        onClick={onClose}
      >
        <div
          className="modal-content"
          style={{
            background: '#FFFFFF',
            borderRadius: '24px',
            maxWidth: '900px',
            width: '100%',
            maxHeight: '90vh',
            overflow: 'hidden',
            position: 'relative',
            boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)'
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={onClose}
            style={{
              position: 'absolute',
              top: '20px',
              right: '20px',
              background: 'rgba(255, 255, 255, 0.95)',
              border: 'none',
              borderRadius: '50%',
              width: '44px',
              height: '44px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              zIndex: 10,
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
              transition: 'all 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = '#FF5D73';
              e.currentTarget.style.transform = 'scale(1.1)';
              const icon = e.currentTarget.querySelector('svg') as SVGElement;
              if (icon) icon.style.color = '#FFFFFF';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.95)';
              e.currentTarget.style.transform = 'scale(1)';
              const icon = e.currentTarget.querySelector('svg') as SVGElement;
              if (icon) icon.style.color = '#000000';
            }}
          >
            <X size={24} color="#000000" style={{ transition: 'color 0.2s ease' }} />
          </button>

          <div
            className="modal-scroll"
            style={{
              maxHeight: '90vh',
              overflowY: 'auto'
            }}
          >
            <div
              style={{
                height: '350px',
                background: `linear-gradient(180deg, rgba(0,0,0,0) 0%, rgba(0,0,0,0.4) 100%), url(${event.image}) center/cover`,
                position: 'relative',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'flex-end',
                padding: '40px'
              }}
            >
              {event.sponsored && (
                <div style={{
                  position: 'absolute',
                  top: '20px',
                  left: '20px',
                  background: '#FF5D73',
                  color: '#FFFFFF',
                  padding: '8px 20px',
                  borderRadius: '20px',
                  fontSize: '13px',
                  fontWeight: '700',
                  letterSpacing: '0.5px'
                }}>
                  SPONSORED
                </div>
              )}

              <div style={{
                background: '#FF5D73',
                color: '#FFFFFF',
                padding: '8px 20px',
                borderRadius: '20px',
                fontSize: '14px',
                fontWeight: '700',
                alignSelf: 'flex-start',
                marginBottom: '16px'
              }}>
                {event.category}
              </div>

              <h1 style={{
                fontSize: '36px',
                fontWeight: '900',
                color: '#FFFFFF',
                marginBottom: '0',
                textShadow: '0 2px 8px rgba(0,0,0,0.3)',
                lineHeight: '1.2'
              }}>
                {event.title}
              </h1>
            </div>

            <div style={{ padding: '40px' }}>
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                gap: '20px',
                marginBottom: '32px'
              }}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '16px',
                  background: 'rgba(255, 93, 115, 0.05)',
                  borderRadius: '12px'
                }}>
                  <Calendar size={24} color="#FF5D73" />
                  <div>
                    <div style={{ fontSize: '12px', color: '#7C7A7A', fontWeight: '600' }}>Date</div>
                    <div style={{ fontSize: '14px', color: '#000000', fontWeight: '700' }}>{event.date}</div>
                  </div>
                </div>

                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '16px',
                  background: 'rgba(255, 93, 115, 0.05)',
                  borderRadius: '12px'
                }}>
                  <MapPin size={24} color="#FF5D73" />
                  <div>
                    <div style={{ fontSize: '12px', color: '#7C7A7A', fontWeight: '600' }}>Location</div>
                    <div style={{ fontSize: '14px', color: '#000000', fontWeight: '700' }}>{event.location}</div>
                  </div>
                </div>
              </div>

              <div style={{
                marginBottom: '32px',
                paddingBottom: '32px',
                borderBottom: '1px solid rgba(0, 0, 0, 0.08)'
              }}>
                <h2 style={{
                  fontSize: '24px',
                  fontWeight: '800',
                  color: '#000000',
                  marginBottom: '16px'
                }}>
                  About This Event
                </h2>
                <p style={{
                  fontSize: '16px',
                  lineHeight: '1.8',
                  color: '#7C7A7A',
                  fontWeight: '500',
                  margin: '0'
                }}>
                  {event.description}
                </p>
                <p style={{
                  fontSize: '16px',
                  lineHeight: '1.8',
                  color: '#7C7A7A',
                  fontWeight: '500',
                  marginTop: '16px'
                }}>
                  This event brings together enthusiasts and professionals for an unforgettable experience.
                  Whether you're a first-timer or a seasoned attendee, there's something for everyone.
                  Come join us and be part of this amazing gathering!
                </p>
              </div>

              <div style={{
                marginBottom: '32px',
                paddingBottom: '32px',
                borderBottom: '1px solid rgba(0, 0, 0, 0.08)'
              }}>
                <h2 style={{
                  fontSize: '24px',
                  fontWeight: '800',
                  color: '#000000',
                  marginBottom: '16px'
                }}>
                  Event Details
                </h2>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <Clock size={20} color="#FF5D73" />
                    <div>
                      <span style={{ fontWeight: '700', color: '#000000' }}>Time: </span>
                      <span style={{ color: '#7C7A7A', fontWeight: '500' }}>6:00 PM - 11:00 PM</span>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <Users size={20} color="#FF5D73" />
                    <div>
                      <span style={{ fontWeight: '700', color: '#000000' }}>Expected Attendees: </span>
                      <span style={{ color: '#7C7A7A', fontWeight: '500' }}>500+ people</span>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <Tag size={20} color="#FF5D73" />
                    <div>
                      <span style={{ fontWeight: '700', color: '#000000' }}>Tags: </span>
                      <span style={{ color: '#7C7A7A', fontWeight: '500' }}>
                        {event.category}, Entertainment, Social, Weekend
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div style={{
                marginBottom: '32px',
                paddingBottom: '32px',
                borderBottom: '1px solid rgba(0, 0, 0, 0.08)'
              }}>
                <h2 style={{
                  fontSize: '24px',
                  fontWeight: '800',
                  color: '#000000',
                  marginBottom: '16px'
                }}>
                  Share This Event
                </h2>

                <div style={{
                  display: 'flex',
                  gap: '12px',
                  alignItems: 'center'
                }}>
                  <button className="modal-social-icon" style={{
                    background: 'rgba(255, 93, 115, 0.08)',
                    border: 'none',
                    cursor: 'pointer',
                    padding: '14px',
                    borderRadius: '50%',
                    transition: 'all 0.2s ease',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '52px',
                    height: '52px'
                  }} onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#FF5D73';
                    const icon = e.currentTarget.querySelector('svg') as SVGElement;
                    if (icon) icon.style.color = '#FFFFFF';
                  }} onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 93, 115, 0.08)';
                    const icon = e.currentTarget.querySelector('svg') as SVGElement;
                    if (icon) icon.style.color = '#7C7A7A';
                  }}>
                    <Facebook size={22} color="#7C7A7A" style={{ transition: 'color 0.2s ease' }} />
                  </button>
                  <button className="modal-social-icon" style={{
                    background: 'rgba(255, 93, 115, 0.08)',
                    border: 'none',
                    cursor: 'pointer',
                    padding: '14px',
                    borderRadius: '50%',
                    transition: 'all 0.2s ease',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '52px',
                    height: '52px'
                  }} onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#FF5D73';
                    const icon = e.currentTarget.querySelector('svg') as SVGElement;
                    if (icon) icon.style.color = '#FFFFFF';
                  }} onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 93, 115, 0.08)';
                    const icon = e.currentTarget.querySelector('svg') as SVGElement;
                    if (icon) icon.style.color = '#7C7A7A';
                  }}>
                    <Twitter size={22} color="#7C7A7A" style={{ transition: 'color 0.2s ease' }} />
                  </button>
                  <button className="modal-social-icon" style={{
                    background: 'rgba(255, 93, 115, 0.08)',
                    border: 'none',
                    cursor: 'pointer',
                    padding: '14px',
                    borderRadius: '50%',
                    transition: 'all 0.2s ease',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '52px',
                    height: '52px'
                  }} onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#FF5D73';
                    const icon = e.currentTarget.querySelector('svg') as SVGElement;
                    if (icon) icon.style.color = '#FFFFFF';
                  }} onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 93, 115, 0.08)';
                    const icon = e.currentTarget.querySelector('svg') as SVGElement;
                    if (icon) icon.style.color = '#7C7A7A';
                  }}>
                    <Instagram size={22} color="#7C7A7A" style={{ transition: 'color 0.2s ease' }} />
                  </button>
                  <button className="modal-social-icon" style={{
                    background: 'rgba(255, 93, 115, 0.08)',
                    border: 'none',
                    cursor: 'pointer',
                    padding: '14px',
                    borderRadius: '50%',
                    transition: 'all 0.2s ease',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '52px',
                    height: '52px'
                  }} onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#FF5D73';
                    const icon = e.currentTarget.querySelector('svg') as SVGElement;
                    if (icon) icon.style.color = '#FFFFFF';
                  }} onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 93, 115, 0.08)';
                    const icon = e.currentTarget.querySelector('svg') as SVGElement;
                    if (icon) icon.style.color = '#7C7A7A';
                  }}>
                    <Youtube size={22} color="#7C7A7A" style={{ transition: 'color 0.2s ease' }} />
                  </button>
                </div>
              </div>

              <div style={{
                display: 'flex',
                gap: '12px',
                flexWrap: 'wrap'
              }}>
                <button style={{
                  flex: '1',
                  minWidth: '200px',
                  background: '#FF5D73',
                  color: '#FFFFFF',
                  border: 'none',
                  borderRadius: '12px',
                  padding: '16px 24px',
                  fontSize: '16px',
                  fontWeight: '700',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px',
                  transition: 'all 0.2s ease'
                }} onMouseEnter={(e) => {
                  e.currentTarget.style.background = '#ff4560';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.boxShadow = '0 8px 20px rgba(255, 93, 115, 0.3)';
                }} onMouseLeave={(e) => {
                  e.currentTarget.style.background = '#FF5D73';
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}>
                  <ExternalLink size={20} />
                  View Event Details
                </button>

                <button style={{
                  flex: '1',
                  minWidth: '200px',
                  background: 'rgba(255, 93, 115, 0.1)',
                  color: '#FF5D73',
                  border: '2px solid #FF5D73',
                  borderRadius: '12px',
                  padding: '16px 24px',
                  fontSize: '16px',
                  fontWeight: '700',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px',
                  transition: 'all 0.2s ease'
                }} onMouseEnter={(e) => {
                  e.currentTarget.style.background = '#FF5D73';
                  e.currentTarget.style.color = '#FFFFFF';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.boxShadow = '0 8px 20px rgba(255, 93, 115, 0.3)';
                }} onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(255, 93, 115, 0.1)';
                  e.currentTarget.style.color = '#FF5D73';
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}>
                  <Bookmark size={20} />
                  Save Event
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
