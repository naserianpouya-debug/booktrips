import { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import { SearchProvider } from './context/SearchContext';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import FeaturedSlider from './components/FeaturedSlider';
import SearchBar from './components/SearchBar';
import EventsForYou from './components/EventsForYou';
import TrendingNow from './components/TrendingNow';
import PlanTrip from './components/PlanTrip';
import PopularLocations from './components/PopularLocations';
import Footer from './components/Footer';
import EventDetailsModal from './components/EventDetailsModal';
import AdminDashboard from './pages/AdminDashboard';
import ProfilePage from './pages/ProfilePage';
import AboutPage from './pages/AboutPage';
import HowItWorksPage from './pages/HowItWorksPage';
import HelpCenterPage from './pages/HelpCenterPage';
import TermsPage from './pages/TermsPage';
import PrivacyPage from './pages/PrivacyPage';
import ContactPage from './pages/ContactPage';
import FAQPage from './pages/FAQPage';
import CityPage from './pages/CityPage';
import { Event } from './types/event';
import { analytics } from './utils/analytics';

type PageType = 'home' | 'admin' | 'profile' | 'about' | 'how-it-works' | 'help-center' | 'terms' | 'privacy' | 'contact' | 'faq' | 'city';

function App() {
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [currentCityId, setCurrentCityId] = useState<string | null>(null);

  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname;
      if (path === '/admin') {
        setCurrentPage('admin');
      } else if (path === '/profile') {
        setCurrentPage('profile');
      } else if (path === '/about') {
        setCurrentPage('about');
      } else if (path === '/how-it-works') {
        setCurrentPage('how-it-works');
      } else if (path === '/help-center') {
        setCurrentPage('help-center');
      } else if (path === '/terms') {
        setCurrentPage('terms');
      } else if (path === '/privacy') {
        setCurrentPage('privacy');
      } else if (path === '/contact') {
        setCurrentPage('contact');
      } else if (path === '/faq') {
        setCurrentPage('faq');
      } else if (path.startsWith('/city/')) {
        setCurrentPage('city');
        setCurrentCityId(path.split('/city/')[1]);
      } else {
        setCurrentPage('home');
      }
    };

    handlePopState();
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  useEffect(() => {
    analytics.trackPageView();
  }, [currentPage]);

  const handleEventClick = (event: Event) => {
    setSelectedEvent(event);
    setIsModalOpen(true);
    analytics.trackEventView(event.id, event.title);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedEvent(null), 300);
  };

  const navigateTo = (page: PageType) => {
    const path = page === 'admin' ? '/admin'
      : page === 'profile' ? '/profile'
      : page === 'about' ? '/about'
      : page === 'how-it-works' ? '/how-it-works'
      : page === 'help-center' ? '/help-center'
      : page === 'terms' ? '/terms'
      : page === 'privacy' ? '/privacy'
      : page === 'contact' ? '/contact'
      : page === 'faq' ? '/faq'
      : '/';
    window.history.pushState({}, '', path);
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToCity = (cityId: string) => {
    const path = `/city/${cityId}`;
    window.history.pushState({}, '', path);
    setCurrentPage('city');
    setCurrentCityId(cityId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <AuthProvider>
      <SearchProvider>
        <div style={{ minHeight: '100vh', position: 'relative' }}>
          <Navbar onNavigate={navigateTo} currentPage={currentPage} />
          {currentPage === 'admin' ? (
            <AdminDashboard />
          ) : currentPage === 'profile' ? (
            <ProfilePage />
          ) : currentPage === 'about' ? (
            <>
              <AboutPage />
              <Footer onNavigate={navigateTo} />
            </>
          ) : currentPage === 'how-it-works' ? (
            <>
              <HowItWorksPage />
              <Footer onNavigate={navigateTo} />
            </>
          ) : currentPage === 'help-center' ? (
            <>
              <HelpCenterPage onNavigate={navigateTo} />
              <Footer onNavigate={navigateTo} />
            </>
          ) : currentPage === 'terms' ? (
            <>
              <TermsPage onNavigate={navigateTo} />
              <Footer onNavigate={navigateTo} />
            </>
          ) : currentPage === 'privacy' ? (
            <>
              <PrivacyPage onNavigate={navigateTo} />
              <Footer onNavigate={navigateTo} />
            </>
          ) : currentPage === 'contact' ? (
            <>
              <ContactPage onNavigate={navigateTo} />
              <Footer onNavigate={navigateTo} />
            </>
          ) : currentPage === 'faq' ? (
            <>
              <FAQPage onNavigate={navigateTo} />
              <Footer onNavigate={navigateTo} />
            </>
          ) : currentPage === 'city' && currentCityId ? (
            <>
              <CityPage
                cityId={currentCityId}
                onNavigate={navigateTo}
                onEventClick={handleEventClick}
              />
              <Footer onNavigate={navigateTo} />
            </>
          ) : (
            <>
              <Hero />
              <FeaturedSlider onEventClick={handleEventClick} />
              <SearchBar />
              <EventsForYou onEventClick={handleEventClick} />
              <TrendingNow onEventClick={handleEventClick} />
              <PlanTrip />
              <PopularLocations onCityClick={navigateToCity} />
              <Footer onNavigate={navigateTo} />
              <EventDetailsModal
                event={selectedEvent}
                isOpen={isModalOpen}
                onClose={handleCloseModal}
              />
            </>
          )}
        </div>
      </SearchProvider>
    </AuthProvider>
  );
}

export default App;
