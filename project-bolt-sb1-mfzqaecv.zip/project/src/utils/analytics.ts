import { supabase } from '../lib/supabase';
import { getOrCreateSessionId } from './cookies';

export type AnalyticsAction =
  | 'page_view'
  | 'event_view'
  | 'event_bookmark'
  | 'event_unbookmark'
  | 'event_share'
  | 'search'
  | 'filter_applied'
  | 'user_login'
  | 'user_signup'
  | 'user_logout';

interface AnalyticsEvent {
  action: AnalyticsAction;
  eventId?: string;
  metadata?: Record<string, any>;
}

export class Analytics {
  private sessionId: string;
  private userId: string | null = null;

  constructor() {
    this.sessionId = getOrCreateSessionId();
    this.initUser();
  }

  private async initUser() {
    const { data: { user } } = await supabase.auth.getUser();
    this.userId = user?.id || null;
  }

  async track(event: AnalyticsEvent): Promise<void> {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      this.userId = user?.id || null;

      await supabase.from('user_analytics').insert({
        user_id: this.userId,
        session_id: this.sessionId,
        event_id: event.eventId || null,
        action_type: event.action,
        page_url: window.location.href,
        user_agent: navigator.userAgent,
        metadata: event.metadata || {}
      });
    } catch (error) {
      console.error('Analytics tracking error:', error);
    }
  }

  trackPageView(): void {
    this.track({
      action: 'page_view',
      metadata: {
        pathname: window.location.pathname,
        referrer: document.referrer
      }
    });
  }

  trackEventView(eventId: string, eventTitle: string): void {
    this.track({
      action: 'event_view',
      eventId,
      metadata: { event_title: eventTitle }
    });
  }

  trackBookmark(eventId: string, eventTitle: string): void {
    this.track({
      action: 'event_bookmark',
      eventId,
      metadata: { event_title: eventTitle }
    });
  }

  trackUnbookmark(eventId: string, eventTitle: string): void {
    this.track({
      action: 'event_unbookmark',
      eventId,
      metadata: { event_title: eventTitle }
    });
  }

  trackShare(eventId: string, platform: string): void {
    this.track({
      action: 'event_share',
      eventId,
      metadata: { platform }
    });
  }

  trackSearch(searchTerm: string, resultsCount: number): void {
    this.track({
      action: 'search',
      metadata: {
        search_term: searchTerm,
        results_count: resultsCount
      }
    });
  }

  trackFilter(filters: Record<string, any>): void {
    this.track({
      action: 'filter_applied',
      metadata: { filters }
    });
  }

  trackUserLogin(method: string): void {
    this.track({
      action: 'user_login',
      metadata: { login_method: method }
    });
  }

  trackUserSignup(method: string): void {
    this.track({
      action: 'user_signup',
      metadata: { signup_method: method }
    });
  }

  trackUserLogout(): void {
    this.track({
      action: 'user_logout'
    });
  }
}

export const analytics = new Analytics();
