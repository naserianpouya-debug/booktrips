export interface CookieOptions {
  expires?: Date;
  maxAge?: number;
  path?: string;
  domain?: string;
  secure?: boolean;
  sameSite?: 'strict' | 'lax' | 'none';
}

export const cookies = {
  set(name: string, value: string, options: CookieOptions = {}): void {
    let cookieString = `${encodeURIComponent(name)}=${encodeURIComponent(value)}`;

    if (options.expires) {
      cookieString += `; expires=${options.expires.toUTCString()}`;
    }

    if (options.maxAge) {
      cookieString += `; max-age=${options.maxAge}`;
    }

    if (options.path) {
      cookieString += `; path=${options.path}`;
    } else {
      cookieString += '; path=/';
    }

    if (options.domain) {
      cookieString += `; domain=${options.domain}`;
    }

    if (options.secure) {
      cookieString += '; secure';
    }

    if (options.sameSite) {
      cookieString += `; samesite=${options.sameSite}`;
    }

    document.cookie = cookieString;
  },

  get(name: string): string | null {
    const nameEQ = encodeURIComponent(name) + '=';
    const cookies = document.cookie.split(';');

    for (let i = 0; i < cookies.length; i++) {
      let cookie = cookies[i].trim();
      if (cookie.indexOf(nameEQ) === 0) {
        return decodeURIComponent(cookie.substring(nameEQ.length));
      }
    }

    return null;
  },

  remove(name: string, options: Pick<CookieOptions, 'path' | 'domain'> = {}): void {
    this.set(name, '', {
      ...options,
      expires: new Date(0)
    });
  },

  getAll(): Record<string, string> {
    const cookies: Record<string, string> = {};
    const cookieArray = document.cookie.split(';');

    for (const cookie of cookieArray) {
      const [name, value] = cookie.trim().split('=');
      if (name && value) {
        cookies[decodeURIComponent(name)] = decodeURIComponent(value);
      }
    }

    return cookies;
  }
};

export function generateSessionId(): string {
  return `session_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
}

export function getOrCreateSessionId(): string {
  const existingSessionId = cookies.get('eventgo_session_id');

  if (existingSessionId) {
    return existingSessionId;
  }

  const newSessionId = generateSessionId();
  cookies.set('eventgo_session_id', newSessionId, {
    maxAge: 30 * 24 * 60 * 60,
    sameSite: 'lax',
    secure: window.location.protocol === 'https:'
  });

  return newSessionId;
}

export function setUserPreference(key: string, value: string): void {
  cookies.set(`eventgo_pref_${key}`, value, {
    maxAge: 365 * 24 * 60 * 60,
    sameSite: 'lax',
    secure: window.location.protocol === 'https:'
  });
}

export function getUserPreference(key: string): string | null {
  return cookies.get(`eventgo_pref_${key}`);
}

export function clearUserPreferences(): void {
  const allCookies = cookies.getAll();
  Object.keys(allCookies).forEach(name => {
    if (name.startsWith('eventgo_pref_')) {
      cookies.remove(name);
    }
  });
}
