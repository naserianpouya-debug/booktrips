import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Event } from '../types/event';
import { featuredEvents, trendingEvents, eventsForYou } from '../data/events';

export function useEvents(filter?: 'featured' | 'trending' | 'all') {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchEvents();
  }, [filter]);

  const fetchEvents = async () => {
    try {
      setLoading(true);

      let query = supabase
        .from('events')
        .select('*')
        .order('created_at', { ascending: false });

      if (filter === 'featured') {
        query = query.eq('featured', true);
      } else if (filter === 'trending') {
        query = query.eq('trending', true);
      }

      const { data, error: fetchError } = await query;

      if (fetchError) {
        console.error('Error fetching events:', fetchError);
        loadFallbackEvents();
      } else if (data && data.length > 0) {
        setEvents(data);
        setError(null);
      } else {
        loadFallbackEvents();
      }
    } catch (err) {
      console.error('Error:', err);
      loadFallbackEvents();
    } finally {
      setLoading(false);
    }
  };

  const loadFallbackEvents = () => {
    if (filter === 'featured') {
      setEvents(featuredEvents as any);
    } else if (filter === 'trending') {
      setEvents(trendingEvents as any);
    } else {
      setEvents(eventsForYou as any);
    }
    setError(null);
  };

  return { events, loading, error, refetch: fetchEvents };
}
