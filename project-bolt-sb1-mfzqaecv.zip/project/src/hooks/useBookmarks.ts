import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { analytics } from '../utils/analytics';

export function useBookmarks() {
  const { user } = useAuth();
  const [bookmarkedEventIds, setBookmarkedEventIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      fetchBookmarks();
    } else {
      setBookmarkedEventIds(new Set());
    }
  }, [user]);

  const fetchBookmarks = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('bookmarked_events')
        .select('event_id')
        .eq('user_id', user.id);

      if (!error && data) {
        setBookmarkedEventIds(new Set(data.map(b => b.event_id)));
      }
    } catch (err) {
      console.error('Error fetching bookmarks:', err);
    }
  };

  const toggleBookmark = async (eventId: string, eventTitle: string): Promise<boolean> => {
    if (!user) {
      return false;
    }

    setLoading(true);
    const isCurrentlyBookmarked = bookmarkedEventIds.has(eventId);

    try {
      if (isCurrentlyBookmarked) {
        const { error } = await supabase
          .from('bookmarked_events')
          .delete()
          .eq('user_id', user.id)
          .eq('event_id', eventId);

        if (!error) {
          setBookmarkedEventIds(prev => {
            const newSet = new Set(prev);
            newSet.delete(eventId);
            return newSet;
          });
          analytics.trackUnbookmark(eventId, eventTitle);
          return true;
        }
      } else {
        const { error } = await supabase
          .from('bookmarked_events')
          .insert({
            user_id: user.id,
            event_id: eventId
          });

        if (!error) {
          setBookmarkedEventIds(prev => new Set(prev).add(eventId));
          analytics.trackBookmark(eventId, eventTitle);
          return true;
        }
      }
    } catch (err) {
      console.error('Error toggling bookmark:', err);
    } finally {
      setLoading(false);
    }

    return false;
  };

  const isBookmarked = (eventId: string): boolean => {
    return bookmarkedEventIds.has(eventId);
  };

  return {
    bookmarkedEventIds,
    isBookmarked,
    toggleBookmark,
    loading,
    refetch: fetchBookmarks
  };
}
