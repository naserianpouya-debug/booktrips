export interface Event {
  id: number;
  title: string;
  date: string;
  location: string;
  category: string;
  image: string;
  description: string;
  sponsored?: boolean;
}

export const featuredEvents: Event[] = [
  {
    id: 1,
    title: "Summer Music Festival 2025",
    date: "Oct 15, 2025",
    location: "Central Park, NYC",
    category: "Music",
    image: "https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Join us for an unforgettable day of live music featuring top artists from around the world."
  },
  {
    id: 2,
    title: "Food & Wine Tasting Experience",
    date: "Oct 20, 2025",
    location: "Downtown, SF",
    category: "Food",
    image: "https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Discover exquisite flavors with renowned chefs and sommeliers in an elegant setting."
  },
  {
    id: 3,
    title: "Art Gallery Night",
    date: "Oct 25, 2025",
    location: "SoHo, NYC",
    category: "Art",
    image: "https://images.pexels.com/photos/1839919/pexels-photo-1839919.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Experience contemporary art from emerging and established artists in an exclusive showcase."
  },
  {
    id: 4,
    title: "Tech Conference 2025",
    date: "Nov 5, 2025",
    location: "Convention Center, LA",
    category: "Tech",
    image: "https://images.pexels.com/photos/2608517/pexels-photo-2608517.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Connect with industry leaders and explore the latest innovations shaping our digital future."
  }
];

export const eventsForYou: Event[] = [
  {
    id: 5,
    title: "Yoga in the Park",
    date: "Oct 10, 2025",
    location: "Riverside Park",
    category: "Wellness",
    image: "https://images.pexels.com/photos/3822621/pexels-photo-3822621.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Start your day with mindfulness and movement in a peaceful outdoor setting."
  },
  {
    id: 6,
    title: "Comedy Night Live",
    date: "Oct 12, 2025",
    location: "Comedy Club, Chicago",
    category: "Comedy",
    image: "https://images.pexels.com/photos/713149/pexels-photo-713149.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Laugh out loud with hilarious performances from the best stand-up comedians."
  },
  {
    id: 7,
    title: "Marathon Running Event",
    date: "Oct 18, 2025",
    location: "City Center",
    category: "Sports",
    image: "https://images.pexels.com/photos/2402777/pexels-photo-2402777.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Challenge yourself in this exciting marathon race through the city's most scenic routes."
  },
  {
    id: 8,
    title: "Jazz Night at Blue Note",
    date: "Oct 22, 2025",
    location: "Blue Note, NYC",
    category: "Music",
    image: "https://images.pexels.com/photos/1047442/pexels-photo-1047442.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Immerse yourself in smooth jazz melodies at the world's most iconic jazz club."
  },
  {
    id: 9,
    title: "Photography Workshop",
    date: "Oct 28, 2025",
    location: "Studio Downtown",
    category: "Workshop",
    image: "https://images.pexels.com/photos/1983032/pexels-photo-1983032.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Master the art of photography with hands-on training from professional photographers."
  },
  {
    id: 10,
    title: "Outdoor Movie Screening",
    date: "Nov 2, 2025",
    location: "Griffith Park, LA",
    category: "Entertainment",
    image: "https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Enjoy classic films under the stars with friends and family in a magical outdoor setting."
  }
];

export const trendingEvents: Event[] = [
  {
    id: 11,
    title: "Broadway Musical Night",
    date: "Oct 14, 2025",
    location: "Theater District, NYC",
    category: "Theater",
    image: "https://images.pexels.com/photos/713149/pexels-photo-713149.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Experience the magic of Broadway with an award-winning musical performance.",
    sponsored: true
  },
  {
    id: 12,
    title: "Fashion Week Opening",
    date: "Oct 16, 2025",
    location: "Fashion District, Milan",
    category: "Fashion",
    image: "https://images.pexels.com/photos/1536619/pexels-photo-1536619.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Witness the latest haute couture collections from top designers at fashion's biggest event.",
    sponsored: true
  },
  {
    id: 13,
    title: "Electric Music Fest",
    date: "Oct 30, 2025",
    location: "Miami Beach",
    category: "Music",
    image: "https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Dance to electrifying beats from world-class DJs at the ultimate beachside music festival.",
    sponsored: true
  },
  {
    id: 14,
    title: "Gourmet Food Festival",
    date: "Nov 8, 2025",
    location: "Paris, France",
    category: "Food",
    image: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Savor culinary masterpieces from Michelin-starred chefs in the heart of Paris.",
    sponsored: true
  }
];
