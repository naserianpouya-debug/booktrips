export interface City {
  id: string;
  name: string;
  country: string;
}

export interface Country {
  id: string;
  name: string;
  cities: City[];
}

export const locationData: Country[] = [
  {
    id: 'us',
    name: 'United States',
    cities: [
      { id: 'nyc', name: 'New York', country: 'us' },
      { id: 'la', name: 'Los Angeles', country: 'us' },
      { id: 'chicago', name: 'Chicago', country: 'us' },
      { id: 'sf', name: 'San Francisco', country: 'us' },
      { id: 'miami', name: 'Miami', country: 'us' }
    ]
  },
  {
    id: 'uk',
    name: 'United Kingdom',
    cities: [
      { id: 'london', name: 'London', country: 'uk' },
      { id: 'manchester', name: 'Manchester', country: 'uk' },
      { id: 'edinburgh', name: 'Edinburgh', country: 'uk' }
    ]
  },
  {
    id: 'france',
    name: 'France',
    cities: [
      { id: 'paris', name: 'Paris', country: 'france' },
      { id: 'lyon', name: 'Lyon', country: 'france' },
      { id: 'marseille', name: 'Marseille', country: 'france' }
    ]
  },
  {
    id: 'italy',
    name: 'Italy',
    cities: [
      { id: 'milan', name: 'Milan', country: 'italy' },
      { id: 'rome', name: 'Rome', country: 'italy' },
      { id: 'venice', name: 'Venice', country: 'italy' }
    ]
  },
  {
    id: 'canada',
    name: 'Canada',
    cities: [
      { id: 'toronto', name: 'Toronto', country: 'canada' },
      { id: 'vancouver', name: 'Vancouver', country: 'canada' },
      { id: 'montreal', name: 'Montreal', country: 'canada' }
    ]
  },
  {
    id: 'australia',
    name: 'Australia',
    cities: [
      { id: 'sydney', name: 'Sydney', country: 'australia' },
      { id: 'melbourne', name: 'Melbourne', country: 'australia' },
      { id: 'brisbane', name: 'Brisbane', country: 'australia' }
    ]
  },
  {
    id: 'germany',
    name: 'Germany',
    cities: [
      { id: 'berlin', name: 'Berlin', country: 'germany' },
      { id: 'munich', name: 'Munich', country: 'germany' },
      { id: 'hamburg', name: 'Hamburg', country: 'germany' }
    ]
  },
  {
    id: 'spain',
    name: 'Spain',
    cities: [
      { id: 'madrid', name: 'Madrid', country: 'spain' },
      { id: 'barcelona', name: 'Barcelona', country: 'spain' },
      { id: 'valencia', name: 'Valencia', country: 'spain' }
    ]
  }
];

export function getCitiesByCountry(countryId: string): City[] {
  const country = locationData.find(c => c.id === countryId);
  return country ? country.cities : [];
}

export function getAllCities(): City[] {
  return locationData.flatMap(country => country.cities);
}
