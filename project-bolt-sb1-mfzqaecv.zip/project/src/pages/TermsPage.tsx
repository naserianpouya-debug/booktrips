import { FileText, Scale, Shield } from 'lucide-react';

interface TermsPageProps {
  onNavigate: (page: 'home' | 'admin' | 'profile' | 'about' | 'how-it-works') => void;
}

export default function TermsPage({ onNavigate }: TermsPageProps) {
  const sections = [
    {
      title: '1. Acceptance of Terms',
      content: 'By accessing and using BookTrips, you accept and agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our service.'
    },
    {
      title: '2. Use of Service',
      content: 'You may use BookTrips to discover, book, and manage event tickets. You agree to use the service only for lawful purposes and in accordance with these terms.'
    },
    {
      title: '3. Account Registration',
      content: 'You must create an account to use certain features. You are responsible for maintaining the confidentiality of your account credentials and for all activities under your account.'
    },
    {
      title: '4. Ticket Purchases',
      content: 'All ticket sales are final unless otherwise specified by the event organizer. Prices are subject to change without notice. Payment must be made in full at the time of purchase.'
    },
    {
      title: '5. Refunds and Cancellations',
      content: 'Refund policies are determined by individual event organizers. BookTrips facilitates refunds but does not guarantee them. Cancellation requests must be submitted according to the event\'s specific policy.'
    },
    {
      title: '6. User Conduct',
      content: 'You agree not to misuse the service, engage in fraudulent activities, resell tickets for profit beyond face value, or interfere with other users\' access to the platform.'
    },
    {
      title: '7. Intellectual Property',
      content: 'All content on BookTrips, including logos, text, graphics, and software, is owned by BookTrips or its licensors and protected by intellectual property laws.'
    },
    {
      title: '8. Limitation of Liability',
      content: 'BookTrips is not liable for any indirect, incidental, or consequential damages arising from your use of the service. Our total liability shall not exceed the amount paid for the affected service.'
    },
    {
      title: '9. Changes to Terms',
      content: 'We reserve the right to modify these terms at any time. Continued use of the service after changes constitutes acceptance of the updated terms.'
    },
    {
      title: '10. Contact Information',
      content: 'For questions about these terms, please contact us at legal@booktrips.com or through our support channels.'
    }
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#FFFFFF' }}>
      <section style={{
        background: 'linear-gradient(135deg, #2D3748 0%, #1A202C 100%)',
        padding: '80px 20px 120px',
        position: 'relative',
        overflow: 'hidden'
      }}>
        <div style={{
          maxWidth: '900px',
          margin: '0 auto',
          position: 'relative',
          zIndex: 2
        }}>
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '16px',
            background: 'rgba(255, 255, 255, 0.1)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: '24px'
          }}>
            <Scale size={32} color="#FFFFFF" />
          </div>

          <h1 style={{
            fontSize: '56px',
            fontWeight: '800',
            color: '#FFFFFF',
            marginBottom: '24px',
            letterSpacing: '-2px'
          }}>
            Terms of Service
          </h1>
          <p style={{
            fontSize: '18px',
            color: 'rgba(255, 255, 255, 0.8)',
            marginBottom: '16px',
            fontWeight: '500'
          }}>
            Last updated: January 6, 2025
          </p>
          <p style={{
            fontSize: '16px',
            color: 'rgba(255, 255, 255, 0.7)',
            fontWeight: '500',
            lineHeight: '1.6'
          }}>
            Please read these terms carefully before using BookTrips. These terms govern your use of our platform and services.
          </p>
        </div>
      </section>

      <section style={{
        padding: '80px 20px',
        maxWidth: '900px',
        margin: '0 auto'
      }}>
        <div style={{
          background: 'rgba(255, 93, 115, 0.05)',
          border: '2px solid #FF5D73',
          borderRadius: '16px',
          padding: '32px',
          marginBottom: '48px'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: '700',
            color: '#000000',
            marginBottom: '16px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px'
          }}>
            <FileText size={24} color="#FF5D73" />
            Quick Summary
          </h2>
          <p style={{
            fontSize: '16px',
            color: '#7C7A7A',
            lineHeight: '1.8',
            fontWeight: '500'
          }}>
            By using BookTrips, you agree to follow our community guidelines, respect intellectual property, and use the platform responsibly. Ticket purchases are subject to event organizer policies. We strive to provide a safe and reliable service but cannot guarantee specific outcomes.
          </p>
        </div>

        {sections.map((section, index) => (
          <div
            key={index}
            style={{
              marginBottom: '40px',
              paddingBottom: '40px',
              borderBottom: index < sections.length - 1 ? '1px solid rgba(0, 0, 0, 0.08)' : 'none'
            }}
          >
            <h3 style={{
              fontSize: '24px',
              fontWeight: '700',
              color: '#000000',
              marginBottom: '16px'
            }}>
              {section.title}
            </h3>
            <p style={{
              fontSize: '16px',
              color: '#7C7A7A',
              lineHeight: '1.8',
              fontWeight: '500'
            }}>
              {section.content}
            </p>
          </div>
        ))}

        <div style={{
          background: 'rgba(45, 55, 72, 0.05)',
          borderRadius: '16px',
          padding: '32px',
          marginTop: '48px',
          textAlign: 'center'
        }}>
          <Shield size={40} color="#2D3748" style={{ marginBottom: '16px' }} />
          <h3 style={{
            fontSize: '22px',
            fontWeight: '700',
            color: '#000000',
            marginBottom: '12px'
          }}>
            Questions about our terms?
          </h3>
          <p style={{
            fontSize: '16px',
            color: '#7C7A7A',
            marginBottom: '24px',
            fontWeight: '500'
          }}>
            Our team is here to help clarify any points
          </p>
          <button
            onClick={() => onNavigate('home')}
            style={{
              padding: '14px 32px',
              background: '#2D3748',
              color: '#FFFFFF',
              border: 'none',
              borderRadius: '10px',
              fontSize: '16px',
              fontWeight: '700',
              cursor: 'pointer',
              transition: 'all 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = '#1A202C';
              e.currentTarget.style.transform = 'translateY(-2px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = '#2D3748';
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            Contact Us
          </button>
        </div>
      </section>
    </div>
  );
}
