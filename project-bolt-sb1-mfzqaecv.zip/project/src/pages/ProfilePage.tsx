import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { Bookmark, Settings, User as UserIcon, Loader as Loader2 } from 'lucide-react';
import EventCard from '../components/EventCard';
import { Event } from '../types/event';
import EventDetailsModal from '../components/EventDetailsModal';

export default function ProfilePage() {
  const { user } = useAuth();
  const [bookmarkedEvents, setBookmarkedEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    if (user) {
      fetchBookmarkedEvents();
    }
  }, [user]);

  const fetchBookmarkedEvents = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('bookmarked_events')
        .select(`
          event_id,
          events (*)
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (!error && data) {
        const events = data.map((item: any) => item.events).filter(Boolean);
        setBookmarkedEvents(events);
      }
    } catch (err) {
      console.error('Error fetching bookmarked events:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleEventClick = (event: Event) => {
    setSelectedEvent(event);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedEvent(null), 300);
  };

  if (!user) {
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#FAFAFA',
        padding: '20px'
      }}>
        <div style={{
          background: '#FFFFFF',
          padding: '48px',
          borderRadius: '16px',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          maxWidth: '500px'
        }}>
          <h1 style={{
            fontSize: '24px',
            fontWeight: '700',
            color: '#000000',
            marginBottom: '16px'
          }}>
            Login Required
          </h1>
          <p style={{
            fontSize: '16px',
            color: '#7C7A7A',
            marginBottom: '24px'
          }}>
            Please log in to view your profile and saved events.
          </p>
          <a href="/" style={{
            display: 'inline-block',
            background: '#FF5D73',
            color: '#FFFFFF',
            padding: '12px 32px',
            borderRadius: '50px',
            textDecoration: 'none',
            fontWeight: '700',
            fontSize: '15px'
          }}>
            Go to Home
          </a>
        </div>
      </div>
    );
  }

  return (
    <>
      <div style={{
        minHeight: '100vh',
        background: '#FAFAFA',
        paddingTop: '100px',
        paddingBottom: '80px'
      }}>
        <div style={{
          maxWidth: '1400px',
          margin: '0 auto',
          padding: '0 20px'
        }}>
          <div style={{
            background: '#FFFFFF',
            borderRadius: '24px',
            padding: '40px',
            marginBottom: '40px',
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.06)'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '24px',
              marginBottom: '24px'
            }}>
              <div style={{
                width: '80px',
                height: '80px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #FF5D73 0%, #ff8a9b 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <UserIcon size={40} color="#FFFFFF" />
              </div>
              <div style={{ flex: 1 }}>
                <h1 style={{
                  fontSize: '32px',
                  fontWeight: '800',
                  color: '#000000',
                  marginBottom: '8px'
                }}>
                  My Profile
                </h1>
                <p style={{
                  fontSize: '16px',
                  color: '#7C7A7A',
                  fontWeight: '500'
                }}>
                  {user.email}
                </p>
              </div>
              <button style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                background: 'rgba(255, 93, 115, 0.1)',
                color: '#FF5D73',
                border: 'none',
                borderRadius: '12px',
                padding: '12px 24px',
                fontSize: '15px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(255, 93, 115, 0.2)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'rgba(255, 93, 115, 0.1)';
              }}>
                <Settings size={18} />
                Settings
              </button>
            </div>

            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
              gap: '16px',
              marginTop: '32px'
            }}>
              <div style={{
                background: 'rgba(255, 93, 115, 0.05)',
                padding: '24px',
                borderRadius: '16px',
                border: '2px solid rgba(255, 93, 115, 0.1)'
              }}>
                <div style={{
                  fontSize: '32px',
                  fontWeight: '800',
                  color: '#FF5D73',
                  marginBottom: '8px'
                }}>
                  {bookmarkedEvents.length}
                </div>
                <div style={{
                  fontSize: '14px',
                  fontWeight: '600',
                  color: '#7C7A7A'
                }}>
                  Saved Events
                </div>
              </div>
            </div>
          </div>

          <div style={{ marginBottom: '32px' }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              marginBottom: '24px'
            }}>
              <Bookmark size={28} color="#FF5D73" fill="rgba(255, 93, 115, 0.2)" />
              <h2 style={{
                fontSize: '28px',
                fontWeight: '800',
                color: '#000000'
              }}>
                Saved Events
              </h2>
            </div>

            {loading ? (
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: '80px 20px'
              }}>
                <Loader2 size={48} className="animate-spin" color="#FF5D73" />
              </div>
            ) : bookmarkedEvents.length === 0 ? (
              <div style={{
                background: '#FFFFFF',
                borderRadius: '16px',
                padding: '80px 40px',
                textAlign: 'center',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.06)'
              }}>
                <Bookmark size={64} color="#E0E0E0" style={{ marginBottom: '24px' }} />
                <h3 style={{
                  fontSize: '20px',
                  fontWeight: '700',
                  color: '#000000',
                  marginBottom: '12px'
                }}>
                  No saved events yet
                </h3>
                <p style={{
                  fontSize: '16px',
                  color: '#7C7A7A',
                  marginBottom: '24px'
                }}>
                  Start exploring events and save your favorites!
                </p>
                <a href="/" style={{
                  display: 'inline-block',
                  background: '#FF5D73',
                  color: '#FFFFFF',
                  padding: '12px 32px',
                  borderRadius: '50px',
                  textDecoration: 'none',
                  fontWeight: '700',
                  fontSize: '15px'
                }}>
                  Browse Events
                </a>
              </div>
            ) : (
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
                gap: '24px'
              }}>
                {bookmarkedEvents.map((event) => (
                  <EventCard
                    key={event.id}
                    event={event}
                    onClick={() => handleEventClick(event)}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <EventDetailsModal
        event={selectedEvent}
        isOpen={isModalOpen}
        onClose={handleCloseModal}
      />
    </>
  );
}
