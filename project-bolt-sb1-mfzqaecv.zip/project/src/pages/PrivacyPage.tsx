import { Lock, Eye, Database, Shield } from 'lucide-react';

interface PrivacyPageProps {
  onNavigate: (page: 'home' | 'admin' | 'profile' | 'about' | 'how-it-works') => void;
}

export default function PrivacyPage({ onNavigate }: PrivacyPageProps) {
  const sections = [
    {
      title: '1. Information We Collect',
      content: 'We collect information you provide directly (name, email, payment details), automatically (device info, IP address, cookies), and from third parties (social media logins, payment processors).'
    },
    {
      title: '2. How We Use Your Information',
      content: 'We use your data to process bookings, send notifications, improve our service, prevent fraud, personalize your experience, and comply with legal obligations.'
    },
    {
      title: '3. Information Sharing',
      content: 'We share your information with event organizers, payment processors, service providers, and when required by law. We never sell your personal information to third parties.'
    },
    {
      title: '4. Data Security',
      content: 'We implement industry-standard security measures including encryption, secure servers, regular security audits, and access controls to protect your information.'
    },
    {
      title: '5. Your Rights',
      content: 'You have the right to access, correct, delete, or export your data. You can manage marketing preferences, opt out of cookies, and request data portability.'
    },
    {
      title: '6. Cookies and Tracking',
      content: 'We use cookies for authentication, preferences, analytics, and advertising. You can control cookies through your browser settings or our cookie management tool.'
    },
    {
      title: '7. Data Retention',
      content: 'We retain your information as long as necessary for service provision, legal compliance, and dispute resolution. Account data is deleted upon request unless legally required.'
    },
    {
      title: '8. Children\'s Privacy',
      content: 'Our service is not intended for users under 13. We do not knowingly collect information from children. Parents can contact us to request deletion of child data.'
    },
    {
      title: '9. International Data Transfers',
      content: 'Your information may be transferred to and processed in countries other than your own. We ensure appropriate safeguards are in place for international transfers.'
    },
    {
      title: '10. Changes to Privacy Policy',
      content: 'We may update this policy periodically. We will notify you of significant changes via email or platform notification. Continued use constitutes acceptance of updates.'
    }
  ];

  const highlights = [
    {
      icon: Lock,
      title: 'Secure Storage',
      description: 'Your data is encrypted and stored on secure servers'
    },
    {
      icon: Eye,
      title: 'Full Transparency',
      description: 'Clear information about what we collect and why'
    },
    {
      icon: Database,
      title: 'Your Data, Your Control',
      description: 'Access, download, or delete your data anytime'
    }
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#FFFFFF' }}>
      <section style={{
        background: 'linear-gradient(135deg, #667EEA 0%, #764BA2 100%)',
        padding: '80px 20px 120px',
        position: 'relative',
        overflow: 'hidden'
      }}>
        <div style={{
          maxWidth: '900px',
          margin: '0 auto',
          position: 'relative',
          zIndex: 2
        }}>
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '16px',
            background: 'rgba(255, 255, 255, 0.2)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: '24px'
          }}>
            <Shield size={32} color="#FFFFFF" />
          </div>

          <h1 style={{
            fontSize: '56px',
            fontWeight: '800',
            color: '#FFFFFF',
            marginBottom: '24px',
            letterSpacing: '-2px'
          }}>
            Privacy Policy
          </h1>
          <p style={{
            fontSize: '18px',
            color: 'rgba(255, 255, 255, 0.9)',
            marginBottom: '16px',
            fontWeight: '500'
          }}>
            Last updated: January 6, 2025
          </p>
          <p style={{
            fontSize: '16px',
            color: 'rgba(255, 255, 255, 0.8)',
            fontWeight: '500',
            lineHeight: '1.6'
          }}>
            Your privacy matters to us. This policy explains how we collect, use, and protect your personal information.
          </p>
        </div>
      </section>

      <section style={{
        padding: '80px 20px 0',
        maxWidth: '1200px',
        margin: '0 auto'
      }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: '32px',
          marginBottom: '80px'
        }}>
          {highlights.map((highlight, index) => (
            <div
              key={index}
              style={{
                background: '#FFFFFF',
                border: '2px solid rgba(102, 126, 234, 0.2)',
                borderRadius: '16px',
                padding: '32px',
                textAlign: 'center'
              }}
            >
              <div style={{
                width: '64px',
                height: '64px',
                borderRadius: '12px',
                background: 'linear-gradient(135deg, #667EEA 0%, #764BA2 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 20px'
              }}>
                <highlight.icon size={28} color="#FFFFFF" />
              </div>
              <h3 style={{
                fontSize: '20px',
                fontWeight: '700',
                color: '#000000',
                marginBottom: '12px'
              }}>
                {highlight.title}
              </h3>
              <p style={{
                fontSize: '15px',
                color: '#7C7A7A',
                fontWeight: '500',
                lineHeight: '1.6'
              }}>
                {highlight.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section style={{
        padding: '0 20px 80px',
        maxWidth: '900px',
        margin: '0 auto'
      }}>
        {sections.map((section, index) => (
          <div
            key={index}
            style={{
              marginBottom: '40px',
              paddingBottom: '40px',
              borderBottom: index < sections.length - 1 ? '1px solid rgba(0, 0, 0, 0.08)' : 'none'
            }}
          >
            <h3 style={{
              fontSize: '24px',
              fontWeight: '700',
              color: '#000000',
              marginBottom: '16px'
            }}>
              {section.title}
            </h3>
            <p style={{
              fontSize: '16px',
              color: '#7C7A7A',
              lineHeight: '1.8',
              fontWeight: '500'
            }}>
              {section.content}
            </p>
          </div>
        ))}

        <div style={{
          background: 'linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%)',
          border: '2px solid #667EEA',
          borderRadius: '16px',
          padding: '40px',
          marginTop: '48px',
          textAlign: 'center'
        }}>
          <h3 style={{
            fontSize: '28px',
            fontWeight: '700',
            color: '#000000',
            marginBottom: '16px'
          }}>
            Exercise Your Privacy Rights
          </h3>
          <p style={{
            fontSize: '16px',
            color: '#7C7A7A',
            marginBottom: '32px',
            fontWeight: '500',
            maxWidth: '600px',
            margin: '0 auto 32px'
          }}>
            Request access to your data, update your preferences, or delete your account at any time through your profile settings or by contacting our privacy team.
          </p>
          <div style={{ display: 'flex', gap: '16px', justifyContent: 'center', flexWrap: 'wrap' }}>
            <button
              onClick={() => onNavigate('profile')}
              style={{
                padding: '14px 32px',
                background: 'linear-gradient(135deg, #667EEA 0%, #764BA2 100%)',
                color: '#FFFFFF',
                border: 'none',
                borderRadius: '10px',
                fontSize: '16px',
                fontWeight: '700',
                cursor: 'pointer',
                transition: 'transform 0.2s ease'
              }}
              onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
              onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
            >
              Manage Privacy
            </button>
            <button
              onClick={() => onNavigate('home')}
              style={{
                padding: '14px 32px',
                background: '#FFFFFF',
                color: '#667EEA',
                border: '2px solid #667EEA',
                borderRadius: '10px',
                fontSize: '16px',
                fontWeight: '700',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#667EEA';
                e.currentTarget.style.color = '#FFFFFF';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = '#FFFFFF';
                e.currentTarget.style.color = '#667EEA';
              }}
            >
              Contact Us
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
