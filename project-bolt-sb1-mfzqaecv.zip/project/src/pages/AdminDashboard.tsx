import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { Plus, CreditCard as Edit2, Trash2, Loader as Loader2 } from 'lucide-react';
import EventFormModal from '../components/admin/EventFormModal';
import { Event } from '../types/event';

export default function AdminDashboard() {
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [events, setEvents] = useState<Event[]>([]);
  const [showEventModal, setShowEventModal] = useState(false);
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);

  useEffect(() => {
    checkAdminStatus();
    fetchEvents();
  }, [user]);

  const checkAdminStatus = async () => {
    if (!user) {
      setIsAdmin(false);
      setLoading(false);
      return;
    }

    const { data } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .maybeSingle();

    setIsAdmin(data?.role === 'admin');
    setLoading(false);
  };

  const fetchEvents = async () => {
    const { data, error } = await supabase
      .from('events')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
      setEvents(data);
    }
  };

  const handleDeleteEvent = async (id: string) => {
    if (!confirm('Are you sure you want to delete this event?')) return;

    const { error } = await supabase
      .from('events')
      .delete()
      .eq('id', id);

    if (!error) {
      setEvents(events.filter(e => e.id !== id));
    }
  };

  const handleEditEvent = (event: Event) => {
    setEditingEvent(event);
    setShowEventModal(true);
  };

  const handleEventSaved = () => {
    setShowEventModal(false);
    setEditingEvent(null);
    fetchEvents();
  };

  if (loading) {
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#FAFAFA'
      }}>
        <Loader2 size={48} className="animate-spin" color="#FF5D73" />
      </div>
    );
  }

  if (!user || !isAdmin) {
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#FAFAFA',
        padding: '20px'
      }}>
        <div style={{
          background: '#FFFFFF',
          padding: '48px',
          borderRadius: '16px',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          maxWidth: '500px'
        }}>
          <h1 style={{
            fontSize: '24px',
            fontWeight: '700',
            color: '#000000',
            marginBottom: '16px'
          }}>
            Access Denied
          </h1>
          <p style={{
            fontSize: '16px',
            color: '#7C7A7A',
            marginBottom: '24px'
          }}>
            You need administrator privileges to access this page.
          </p>
          <a href="/" style={{
            display: 'inline-block',
            background: '#FF5D73',
            color: '#FFFFFF',
            padding: '12px 32px',
            borderRadius: '50px',
            textDecoration: 'none',
            fontWeight: '700',
            fontSize: '15px'
          }}>
            Go to Home
          </a>
        </div>
      </div>
    );
  }

  return (
    <>
      <div style={{
        minHeight: '100vh',
        background: '#FAFAFA',
        paddingTop: '100px',
        paddingBottom: '80px'
      }}>
        <div style={{
          maxWidth: '1400px',
          margin: '0 auto',
          padding: '0 20px'
        }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '40px'
          }}>
            <div>
              <h1 style={{
                fontSize: '36px',
                fontWeight: '800',
                color: '#000000',
                marginBottom: '8px'
              }}>
                Event Management
              </h1>
              <p style={{
                fontSize: '16px',
                color: '#7C7A7A',
                fontWeight: '500'
              }}>
                Manage all events on your platform
              </p>
            </div>
            <button
              onClick={() => {
                setEditingEvent(null);
                setShowEventModal(true);
              }}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                background: '#FF5D73',
                color: '#FFFFFF',
                border: 'none',
                borderRadius: '50px',
                padding: '14px 28px',
                fontSize: '15px',
                fontWeight: '700',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                boxShadow: '0 4px 16px rgba(255, 93, 115, 0.3)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 6px 20px rgba(255, 93, 115, 0.4)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 4px 16px rgba(255, 93, 115, 0.3)';
              }}
            >
              <Plus size={20} />
              Create Event
            </button>
          </div>

          {events.length === 0 ? (
            <div style={{
              background: '#FFFFFF',
              borderRadius: '16px',
              padding: '80px 40px',
              textAlign: 'center',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.06)'
            }}>
              <p style={{
                fontSize: '18px',
                color: '#7C7A7A',
                fontWeight: '600',
                marginBottom: '24px'
              }}>
                No events yet. Create your first event to get started!
              </p>
              <button
                onClick={() => {
                  setEditingEvent(null);
                  setShowEventModal(true);
                }}
                style={{
                  background: '#FF5D73',
                  color: '#FFFFFF',
                  border: 'none',
                  borderRadius: '50px',
                  padding: '12px 32px',
                  fontSize: '15px',
                  fontWeight: '700',
                  cursor: 'pointer'
                }}
              >
                Create Your First Event
              </button>
            </div>
          ) : (
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
              gap: '24px'
            }}>
              {events.map((event) => (
                <div
                  key={event.id}
                  style={{
                    background: '#FFFFFF',
                    borderRadius: '16px',
                    overflow: 'hidden',
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.06)',
                    transition: 'all 0.3s ease'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-4px)';
                    e.currentTarget.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.12)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.06)';
                  }}
                >
                  <div style={{
                    width: '100%',
                    height: '200px',
                    overflow: 'hidden'
                  }}>
                    <img
                      src={event.image}
                      alt={event.title}
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover'
                      }}
                    />
                  </div>
                  <div style={{ padding: '20px' }}>
                    <div style={{
                      display: 'flex',
                      gap: '8px',
                      marginBottom: '12px',
                      flexWrap: 'wrap'
                    }}>
                      <span style={{
                        background: 'rgba(255, 93, 115, 0.1)',
                        color: '#FF5D73',
                        padding: '4px 12px',
                        borderRadius: '50px',
                        fontSize: '12px',
                        fontWeight: '700'
                      }}>
                        {event.category}
                      </span>
                      {event.featured && (
                        <span style={{
                          background: 'rgba(255, 193, 7, 0.1)',
                          color: '#FFC107',
                          padding: '4px 12px',
                          borderRadius: '50px',
                          fontSize: '12px',
                          fontWeight: '700'
                        }}>
                          Featured
                        </span>
                      )}
                      {event.trending && (
                        <span style={{
                          background: 'rgba(76, 175, 80, 0.1)',
                          color: '#4CAF50',
                          padding: '4px 12px',
                          borderRadius: '50px',
                          fontSize: '12px',
                          fontWeight: '700'
                        }}>
                          Trending
                        </span>
                      )}
                    </div>
                    <h3 style={{
                      fontSize: '18px',
                      fontWeight: '700',
                      color: '#000000',
                      marginBottom: '8px',
                      lineHeight: '1.4'
                    }}>
                      {event.title}
                    </h3>
                    <p style={{
                      fontSize: '14px',
                      color: '#7C7A7A',
                      marginBottom: '4px',
                      fontWeight: '600'
                    }}>
                      {event.date}
                    </p>
                    <p style={{
                      fontSize: '14px',
                      color: '#7C7A7A',
                      marginBottom: '16px',
                      fontWeight: '500'
                    }}>
                      {event.location}
                    </p>
                    <div style={{
                      display: 'flex',
                      gap: '8px',
                      paddingTop: '16px',
                      borderTop: '1px solid rgba(0, 0, 0, 0.06)'
                    }}>
                      <button
                        onClick={() => handleEditEvent(event)}
                        style={{
                          flex: 1,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '6px',
                          background: 'rgba(255, 93, 115, 0.1)',
                          color: '#FF5D73',
                          border: 'none',
                          borderRadius: '8px',
                          padding: '10px',
                          fontSize: '14px',
                          fontWeight: '600',
                          cursor: 'pointer',
                          transition: 'all 0.2s ease'
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.background = 'rgba(255, 93, 115, 0.2)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.background = 'rgba(255, 93, 115, 0.1)';
                        }}
                      >
                        <Edit2 size={16} />
                        Edit
                      </button>
                      <button
                        onClick={() => handleDeleteEvent(event.id)}
                        style={{
                          flex: 1,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '6px',
                          background: 'rgba(239, 68, 68, 0.1)',
                          color: '#EF4444',
                          border: 'none',
                          borderRadius: '8px',
                          padding: '10px',
                          fontSize: '14px',
                          fontWeight: '600',
                          cursor: 'pointer',
                          transition: 'all 0.2s ease'
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.background = 'rgba(239, 68, 68, 0.2)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.background = 'rgba(239, 68, 68, 0.1)';
                        }}
                      >
                        <Trash2 size={16} />
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {showEventModal && (
        <EventFormModal
          event={editingEvent}
          onClose={() => {
            setShowEventModal(false);
            setEditingEvent(null);
          }}
          onSave={handleEventSaved}
        />
      )}
    </>
  );
}
