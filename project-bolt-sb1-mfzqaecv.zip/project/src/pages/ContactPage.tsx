import { Mail, Phone, MapPin, Clock, Send, MessageCircle } from 'lucide-react';
import { useState } from 'react';

interface ContactPageProps {
  onNavigate: (page: 'home' | 'admin' | 'profile' | 'about' | 'how-it-works') => void;
}

export default function ContactPage({ onNavigate }: ContactPageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const contactMethods = [
    {
      icon: Mail,
      title: 'Email',
      detail: 'hello@booktrips.com',
      description: 'Send us an email anytime'
    },
    {
      icon: Phone,
      title: 'Phone',
      detail: '+1 (555) 123-4567',
      description: 'Mon-Fri from 9am to 6pm EST'
    },
    {
      icon: MapPin,
      title: 'Office',
      detail: '123 Event Street, New York, NY 10001',
      description: 'Visit us in person'
    },
    {
      icon: Clock,
      title: 'Response Time',
      detail: 'Within 24 hours',
      description: 'Average response time'
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('Thank you for contacting us! We will get back to you soon.');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  return (
    <div style={{ minHeight: '100vh', background: '#FFFFFF' }}>
      <section style={{
        background: 'linear-gradient(135deg, #FF5D73 0%, #FF8A9B 100%)',
        padding: '80px 20px 120px',
        position: 'relative',
        overflow: 'hidden'
      }}>
        <div style={{
          maxWidth: '900px',
          margin: '0 auto',
          position: 'relative',
          zIndex: 2,
          textAlign: 'center'
        }}>
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '16px',
            background: 'rgba(255, 255, 255, 0.2)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 24px'
          }}>
            <MessageCircle size={32} color="#FFFFFF" />
          </div>

          <h1 style={{
            fontSize: '56px',
            fontWeight: '800',
            color: '#FFFFFF',
            marginBottom: '24px',
            letterSpacing: '-2px'
          }}>
            Contact Us
          </h1>
          <p style={{
            fontSize: '18px',
            color: 'rgba(255, 255, 255, 0.95)',
            fontWeight: '500',
            maxWidth: '600px',
            margin: '0 auto'
          }}>
            Have questions? We're here to help. Reach out to our team and we'll get back to you as soon as possible.
          </p>
        </div>
      </section>

      <section style={{
        padding: '80px 20px',
        maxWidth: '1200px',
        margin: '0 auto'
      }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '24px',
          marginBottom: '80px'
        }}>
          {contactMethods.map((method, index) => (
            <div
              key={index}
              style={{
                background: '#FFFFFF',
                border: '1px solid rgba(0, 0, 0, 0.08)',
                borderRadius: '16px',
                padding: '32px',
                textAlign: 'center',
                transition: 'all 0.3s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-4px)';
                e.currentTarget.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.1)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              <div style={{
                width: '56px',
                height: '56px',
                borderRadius: '12px',
                background: 'linear-gradient(135deg, #FF5D73 0%, #FF8A9B 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 20px'
              }}>
                <method.icon size={24} color="#FFFFFF" />
              </div>
              <h3 style={{
                fontSize: '18px',
                fontWeight: '700',
                color: '#000000',
                marginBottom: '8px'
              }}>
                {method.title}
              </h3>
              <p style={{
                fontSize: '16px',
                color: '#FF5D73',
                fontWeight: '600',
                marginBottom: '8px'
              }}>
                {method.detail}
              </p>
              <p style={{
                fontSize: '14px',
                color: '#7C7A7A',
                fontWeight: '500'
              }}>
                {method.description}
              </p>
            </div>
          ))}
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr',
          gap: '48px',
          maxWidth: '800px',
          margin: '0 auto'
        }}>
          <div>
            <h2 style={{
              fontSize: '36px',
              fontWeight: '700',
              color: '#000000',
              marginBottom: '16px'
            }}>
              Send us a message
            </h2>
            <p style={{
              fontSize: '16px',
              color: '#7C7A7A',
              marginBottom: '32px',
              fontWeight: '500'
            }}>
              Fill out the form below and we'll get back to you within 24 hours
            </p>

            <form onSubmit={handleSubmit}>
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
                gap: '20px',
                marginBottom: '20px'
              }}>
                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#000000',
                    marginBottom: '8px'
                  }}>
                    Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    style={{
                      width: '100%',
                      padding: '14px 16px',
                      border: '1px solid rgba(0, 0, 0, 0.15)',
                      borderRadius: '10px',
                      fontSize: '15px',
                      fontWeight: '500',
                      transition: 'border-color 0.2s ease'
                    }}
                    onFocus={(e) => e.currentTarget.style.borderColor = '#FF5D73'}
                    onBlur={(e) => e.currentTarget.style.borderColor = 'rgba(0, 0, 0, 0.15)'}
                  />
                </div>
                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#000000',
                    marginBottom: '8px'
                  }}>
                    Email
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    style={{
                      width: '100%',
                      padding: '14px 16px',
                      border: '1px solid rgba(0, 0, 0, 0.15)',
                      borderRadius: '10px',
                      fontSize: '15px',
                      fontWeight: '500',
                      transition: 'border-color 0.2s ease'
                    }}
                    onFocus={(e) => e.currentTarget.style.borderColor = '#FF5D73'}
                    onBlur={(e) => e.currentTarget.style.borderColor = 'rgba(0, 0, 0, 0.15)'}
                  />
                </div>
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '600',
                  color: '#000000',
                  marginBottom: '8px'
                }}>
                  Subject
                </label>
                <input
                  type="text"
                  required
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  style={{
                    width: '100%',
                    padding: '14px 16px',
                    border: '1px solid rgba(0, 0, 0, 0.15)',
                    borderRadius: '10px',
                    fontSize: '15px',
                    fontWeight: '500',
                    transition: 'border-color 0.2s ease'
                  }}
                  onFocus={(e) => e.currentTarget.style.borderColor = '#FF5D73'}
                  onBlur={(e) => e.currentTarget.style.borderColor = 'rgba(0, 0, 0, 0.15)'}
                />
              </div>

              <div style={{ marginBottom: '24px' }}>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '600',
                  color: '#000000',
                  marginBottom: '8px'
                }}>
                  Message
                </label>
                <textarea
                  required
                  rows={6}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  style={{
                    width: '100%',
                    padding: '14px 16px',
                    border: '1px solid rgba(0, 0, 0, 0.15)',
                    borderRadius: '10px',
                    fontSize: '15px',
                    fontWeight: '500',
                    fontFamily: 'inherit',
                    resize: 'vertical',
                    transition: 'border-color 0.2s ease'
                  }}
                  onFocus={(e) => e.currentTarget.style.borderColor = '#FF5D73'}
                  onBlur={(e) => e.currentTarget.style.borderColor = 'rgba(0, 0, 0, 0.15)'}
                />
              </div>

              <button
                type="submit"
                style={{
                  width: '100%',
                  padding: '16px',
                  background: 'linear-gradient(135deg, #FF5D73 0%, #FF8A9B 100%)',
                  color: '#FFFFFF',
                  border: 'none',
                  borderRadius: '12px',
                  fontSize: '16px',
                  fontWeight: '700',
                  cursor: 'pointer',
                  transition: 'transform 0.2s ease',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px'
                }}
                onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
                onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
              >
                <Send size={20} />
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}
