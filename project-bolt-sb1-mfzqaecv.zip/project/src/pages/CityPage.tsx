import { useState, useEffect } from 'react';
import { MapPin, Calendar, ArrowLeft, Loader } from 'lucide-react';
import { supabase } from '../lib/supabase';
import CityPhotoGallery from '../components/CityPhotoGallery';
import EventCard from '../components/EventCard';
import { Event } from '../types/event';

/**
 * City Page Component
 *
 * A comprehensive city template featuring:
 * - Hero section with city image and key information
 * - Descriptive content about the city
 * - Photo gallery showcasing the destination
 * - Events section filtered by city
 * - Responsive design for all devices
 * - SEO-optimized structure
 *
 * URL Pattern: /city/:cityId
 * Example: /city/paris, /city/new-york
 */

interface CityData {
  id: string;
  name: string;
  country: string;
  description: string;
  hero_image: string;
  latitude: number;
  longitude: number;
  event_count: number;
}

interface CityPhoto {
  id: string;
  image_url: string;
  caption?: string;
  photographer?: string;
}

interface CityPageProps {
  cityId: string;
  onNavigate: (page: 'home') => void;
  onEventClick: (event: Event) => void;
}

export default function CityPage({ cityId, onNavigate, onEventClick }: CityPageProps) {
  const [city, setCity] = useState<CityData | null>(null);
  const [photos, setPhotos] = useState<CityPhoto[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [eventFilter, setEventFilter] = useState<'all' | 'upcoming' | 'this-week'>('all');

  useEffect(() => {
    loadCityData();
  }, [cityId]);

  const loadCityData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Fetch city information
      const { data: cityData, error: cityError } = await supabase
        .from('cities')
        .select('*')
        .eq('id', cityId)
        .maybeSingle();

      if (cityError) throw cityError;
      if (!cityData) {
        setError('City not found');
        setLoading(false);
        return;
      }

      setCity(cityData);

      // Fetch city photos
      const { data: photoData, error: photoError } = await supabase
        .from('city_photos')
        .select('*')
        .eq('city_id', cityId)
        .order('display_order', { ascending: true });

      if (photoError) throw photoError;
      setPhotos(photoData || []);

      // Fetch events for this city
      const { data: eventData, error: eventError } = await supabase
        .from('events')
        .select('*')
        .eq('location', cityData.name)
        .eq('status', 'published')
        .order('date', { ascending: true })
        .limit(12);

      if (eventError) throw eventError;
      setEvents(eventData || []);

    } catch (err) {
      console.error('Error loading city data:', err);
      setError('Failed to load city information');
    } finally {
      setLoading(false);
    }
  };

  const filterEvents = () => {
    const now = new Date();
    const oneWeekFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

    switch (eventFilter) {
      case 'upcoming':
        return events.filter(event => new Date(event.date) >= now);
      case 'this-week':
        return events.filter(event => {
          const eventDate = new Date(event.date);
          return eventDate >= now && eventDate <= oneWeekFromNow;
        });
      default:
        return events;
    }
  };

  if (loading) {
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#FFFFFF'
      }}>
        <div style={{ textAlign: 'center' }}>
          <Loader size={48} color="#FF5D73" style={{
            animation: 'spin 1s linear infinite'
          }} />
          <p style={{
            marginTop: '16px',
            fontSize: '18px',
            color: '#7C7A7A',
            fontWeight: '600'
          }}>
            Loading city information...
          </p>
        </div>
      </div>
    );
  }

  if (error || !city) {
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#FFFFFF',
        padding: '20px'
      }}>
        <div style={{ textAlign: 'center', maxWidth: '500px' }}>
          <h1 style={{
            fontSize: '48px',
            fontWeight: '800',
            color: '#000000',
            marginBottom: '16px'
          }}>
            City Not Found
          </h1>
          <p style={{
            fontSize: '18px',
            color: '#7C7A7A',
            marginBottom: '32px',
            fontWeight: '500'
          }}>
            {error || 'The city you\'re looking for doesn\'t exist.'}
          </p>
          <button
            onClick={() => onNavigate('home')}
            style={{
              padding: '14px 32px',
              background: '#FF5D73',
              color: '#FFFFFF',
              border: 'none',
              borderRadius: '12px',
              fontSize: '16px',
              fontWeight: '700',
              cursor: 'pointer',
              transition: 'transform 0.2s ease',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '8px'
            }}
            onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
            onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
          >
            <ArrowLeft size={20} />
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  const filteredEvents = filterEvents();
  const descriptionParagraphs = city.description.split('\n\n');

  return (
    <div style={{ minHeight: '100vh', background: '#FFFFFF' }}>
      {/* Hero Section */}
      <section style={{
        position: 'relative',
        height: '60vh',
        minHeight: '500px',
        background: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url(${city.hero_image})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}>
        {/* Back Button */}
        <button
          onClick={() => onNavigate('home')}
          style={{
            position: 'absolute',
            top: '100px',
            left: '20px',
            padding: '12px 20px',
            background: 'rgba(255, 255, 255, 0.2)',
            backdropFilter: 'blur(10px)',
            border: 'none',
            borderRadius: '12px',
            color: '#FFFFFF',
            fontSize: '16px',
            fontWeight: '700',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            transition: 'all 0.2s ease'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = 'rgba(255, 255, 255, 0.3)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'rgba(255, 255, 255, 0.2)';
          }}
        >
          <ArrowLeft size={20} />
          Back
        </button>

        {/* Hero Content */}
        <div style={{
          textAlign: 'center',
          color: '#FFFFFF',
          padding: '0 20px',
          maxWidth: '800px'
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px',
            marginBottom: '16px'
          }}>
            <MapPin size={24} color="#FFFFFF" />
            <span style={{
              fontSize: '18px',
              fontWeight: '600',
              opacity: 0.9
            }}>
              {city.country}
            </span>
          </div>

          <h1 style={{
            fontSize: 'clamp(48px, 8vw, 80px)',
            fontWeight: '900',
            marginBottom: '24px',
            letterSpacing: '-2px',
            textShadow: '0 4px 20px rgba(0, 0, 0, 0.3)'
          }}>
            {city.name}
          </h1>

          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px',
            background: 'rgba(255, 93, 115, 0.9)',
            padding: '12px 24px',
            borderRadius: '25px',
            fontSize: '18px',
            fontWeight: '700',
            backdropFilter: 'blur(10px)'
          }}>
            <Calendar size={20} />
            {city.event_count} Events Available
          </div>
        </div>
      </section>

      {/* City Description */}
      <section style={{
        padding: '80px 20px',
        maxWidth: '900px',
        margin: '0 auto'
      }}>
        <div style={{
          fontSize: '18px',
          lineHeight: '1.8',
          color: '#3A3A3A',
          fontWeight: '500'
        }}>
          {descriptionParagraphs.map((paragraph, index) => (
            <p key={index} style={{
              marginBottom: index < descriptionParagraphs.length - 1 ? '24px' : '0'
            }}>
              {paragraph}
            </p>
          ))}
        </div>
      </section>

      {/* Photo Gallery */}
      <CityPhotoGallery photos={photos} cityName={city.name} />

      {/* Events Section */}
      <section style={{
        padding: '60px 20px 80px',
        maxWidth: '1400px',
        margin: '0 auto',
        background: 'linear-gradient(to bottom, #FFFFFF, #F8F9FA)'
      }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '40px',
          flexWrap: 'wrap',
          gap: '20px'
        }}>
          <h2 style={{
            fontSize: '36px',
            fontWeight: '800',
            color: '#000000',
            letterSpacing: '-0.5px'
          }}>
            Events in {city.name}
          </h2>

          {/* Filter Buttons */}
          <div style={{
            display: 'flex',
            gap: '12px',
            flexWrap: 'wrap'
          }}>
            {(['all', 'upcoming', 'this-week'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setEventFilter(filter)}
                style={{
                  padding: '10px 20px',
                  background: eventFilter === filter ? '#FF5D73' : '#FFFFFF',
                  color: eventFilter === filter ? '#FFFFFF' : '#000000',
                  border: `2px solid ${eventFilter === filter ? '#FF5D73' : 'rgba(0, 0, 0, 0.1)'}`,
                  borderRadius: '25px',
                  fontSize: '14px',
                  fontWeight: '700',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                  textTransform: 'capitalize'
                }}
                onMouseEnter={(e) => {
                  if (eventFilter !== filter) {
                    e.currentTarget.style.borderColor = '#FF5D73';
                  }
                }}
                onMouseLeave={(e) => {
                  if (eventFilter !== filter) {
                    e.currentTarget.style.borderColor = 'rgba(0, 0, 0, 0.1)';
                  }
                }}
              >
                {filter.replace('-', ' ')}
              </button>
            ))}
          </div>
        </div>

        {/* Events Grid */}
        {filteredEvents.length > 0 ? (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
            gap: '24px'
          }}>
            {filteredEvents.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                onClick={() => onEventClick(event)}
              />
            ))}
          </div>
        ) : (
          <div style={{
            textAlign: 'center',
            padding: '60px 20px',
            background: '#FFFFFF',
            borderRadius: '16px',
            border: '2px dashed rgba(0, 0, 0, 0.1)'
          }}>
            <Calendar size={48} color="#CCC" style={{ marginBottom: '16px' }} />
            <h3 style={{
              fontSize: '24px',
              fontWeight: '700',
              color: '#000000',
              marginBottom: '8px'
            }}>
              No Events Found
            </h3>
            <p style={{
              fontSize: '16px',
              color: '#7C7A7A',
              fontWeight: '500'
            }}>
              There are no events matching your filter criteria.
            </p>
          </div>
        )}
      </section>

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        @media (max-width: 768px) {
          section[style*="gridTemplateColumns"] {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
}
