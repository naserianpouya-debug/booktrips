import { Users, Target, Heart, Award } from 'lucide-react';

export default function AboutPage() {
  return (
    <div style={{ minHeight: '100vh', paddingTop: '80px' }}>
      <section style={{
        padding: '80px 20px',
        maxWidth: '1200px',
        margin: '0 auto'
      }}>
        <h1 style={{
          fontSize: '56px',
          fontWeight: '800',
          color: '#000000',
          marginBottom: '24px',
          letterSpacing: '-1.5px',
          textAlign: 'center'
        }}>
          About BookTrips
        </h1>

        <p style={{
          fontSize: '20px',
          color: '#7C7A7A',
          marginBottom: '60px',
          textAlign: 'center',
          maxWidth: '800px',
          margin: '0 auto 60px',
          lineHeight: '1.8',
          fontWeight: '500'
        }}>
          We're on a mission to connect event organizers with enthusiastic attendees.
          From concerts to conferences, sports to festivals, we make promoting
          and discovering events effortless.
        </p>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: '32px',
          marginBottom: '80px'
        }}>
          {[
            {
              icon: Target,
              title: 'Our Mission',
              description: 'To make every event accessible to the right audience and every experience memorable for attendees worldwide.'
            },
            {
              icon: Heart,
              title: 'Our Passion',
              description: 'We believe in connecting passionate organizers with engaged audiences to create meaningful, lasting experiences.'
            },
            {
              icon: Award,
              title: 'Our Excellence',
              description: 'Committed to providing the best event advertising platform with powerful reach and targeted visibility.'
            },
            {
              icon: Users,
              title: 'Our Community',
              description: 'Join thousands of organizers and millions of attendees who trust us to connect and create amazing events.'
            }
          ].map((item, index) => (
            <div
              key={index}
              style={{
                background: 'rgba(255, 255, 255, 0.8)',
                backdropFilter: 'blur(20px)',
                borderRadius: '24px',
                padding: '40px',
                border: '1px solid rgba(0, 0, 0, 0.06)',
                boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08)',
                transition: 'all 0.3s ease',
                cursor: 'pointer'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-8px)';
                e.currentTarget.style.boxShadow = '0 16px 48px rgba(255, 93, 115, 0.15)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 8px 32px rgba(0, 0, 0, 0.08)';
              }}
            >
              <div style={{
                width: '64px',
                height: '64px',
                background: 'linear-gradient(135deg, #FF5D73, #ff4560)',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '24px',
                boxShadow: '0 8px 24px rgba(255, 93, 115, 0.3)'
              }}>
                <item.icon size={28} color="#FFFFFF" />
              </div>
              <h3 style={{
                fontSize: '22px',
                fontWeight: '700',
                color: '#000000',
                marginBottom: '12px'
              }}>
                {item.title}
              </h3>
              <p style={{
                fontSize: '15px',
                color: '#7C7A7A',
                lineHeight: '1.6',
                fontWeight: '500'
              }}>
                {item.description}
              </p>
            </div>
          ))}
        </div>

        <div style={{
          background: 'linear-gradient(135deg, rgba(255, 93, 115, 0.1), rgba(255, 93, 115, 0.05))',
          borderRadius: '32px',
          padding: '60px 40px',
          textAlign: 'center'
        }}>
          <h2 style={{
            fontSize: '36px',
            fontWeight: '800',
            color: '#000000',
            marginBottom: '24px',
            letterSpacing: '-0.5px'
          }}>
            Our Story
          </h2>
          <div style={{
            fontSize: '16px',
            color: '#5A5A5A',
            lineHeight: '1.8',
            maxWidth: '800px',
            margin: '0 auto',
            fontWeight: '500'
          }}>
            <p style={{ marginBottom: '20px' }}>
              Founded in 2020, BookTrips started with a simple idea: great events deserve great audiences.
              We set out to create a platform that connects event organizers with the perfect attendees,
              making event promotion effective and discovery effortless.
            </p>
            <p style={{ marginBottom: '20px' }}>
              Today, we're proud to connect thousands of event organizers with millions of attendees worldwide.
              Our platform helps promote concerts, sports games, festivals, conferences, and more. Our advanced
              matching system ensures the right events reach the right audience.
            </p>
            <p>
              Whether you're organizing a local workshop or a major festival, or searching for your next adventure,
              BookTrips makes it easy to connect, promote, and discover events that matter.
            </p>
          </div>
        </div>
      </section>

      <style>{`
        @media (max-width: 768px) {
          div[style*="grid-template-columns"] {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
}
