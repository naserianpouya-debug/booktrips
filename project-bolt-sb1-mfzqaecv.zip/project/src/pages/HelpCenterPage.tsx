import { Search, BookOpen, CreditCard, User, MessageCircle, Shield } from 'lucide-react';

interface HelpCenterPageProps {
  onNavigate: (page: 'home' | 'admin' | 'profile' | 'about' | 'how-it-works') => void;
}

export default function HelpCenterPage({ onNavigate }: HelpCenterPageProps) {
  const categories = [
    {
      icon: BookOpen,
      title: 'Getting Started',
      description: 'Learn the basics of using BookTrips',
      articles: ['Create an account', 'Find events near you', 'First time booking']
    },
    {
      icon: CreditCard,
      title: 'Payments & Billing',
      description: 'Information about payments and refunds',
      articles: ['Payment methods', 'Refund policy', 'Billing questions']
    },
    {
      icon: User,
      title: 'Account Management',
      description: 'Manage your profile and settings',
      articles: ['Update profile', 'Reset password', 'Privacy settings']
    },
    {
      icon: Shield,
      title: 'Safety & Security',
      description: 'Stay safe and protect your account',
      articles: ['Account security', 'Report an issue', 'Verify tickets']
    }
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#FFFFFF' }}>
      <section style={{
        background: 'linear-gradient(135deg, #FF5D73 0%, #FF8A9B 100%)',
        padding: '80px 20px 120px',
        position: 'relative',
        overflow: 'hidden'
      }}>
        <div style={{
          maxWidth: '1200px',
          margin: '0 auto',
          position: 'relative',
          zIndex: 2,
          textAlign: 'center'
        }}>
          <h1 style={{
            fontSize: '56px',
            fontWeight: '800',
            color: '#FFFFFF',
            marginBottom: '24px',
            letterSpacing: '-2px'
          }}>
            Help Center
          </h1>
          <p style={{
            fontSize: '20px',
            color: 'rgba(255, 255, 255, 0.95)',
            marginBottom: '40px',
            maxWidth: '600px',
            margin: '0 auto 40px',
            fontWeight: '500'
          }}>
            Find answers, get support, and learn how to make the most of BookTrips
          </p>

          <div style={{
            maxWidth: '600px',
            margin: '0 auto',
            position: 'relative'
          }}>
            <Search
              size={20}
              style={{
                position: 'absolute',
                left: '20px',
                top: '50%',
                transform: 'translateY(-50%)',
                color: '#7C7A7A'
              }}
            />
            <input
              type="text"
              placeholder="Search for help..."
              style={{
                width: '100%',
                padding: '18px 20px 18px 56px',
                border: 'none',
                borderRadius: '12px',
                fontSize: '16px',
                fontWeight: '500',
                boxShadow: '0 10px 40px rgba(0, 0, 0, 0.15)'
              }}
            />
          </div>
        </div>
      </section>

      <section style={{
        padding: '80px 20px',
        maxWidth: '1200px',
        margin: '0 auto'
      }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: '32px'
        }}>
          {categories.map((category) => (
            <div
              key={category.title}
              style={{
                background: '#FFFFFF',
                border: '1px solid rgba(0, 0, 0, 0.08)',
                borderRadius: '16px',
                padding: '32px',
                transition: 'all 0.3s ease',
                cursor: 'pointer'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-8px)';
                e.currentTarget.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.12)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              <div style={{
                width: '56px',
                height: '56px',
                borderRadius: '12px',
                background: 'linear-gradient(135deg, #FF5D73 0%, #FF8A9B 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '20px'
              }}>
                <category.icon size={28} color="#FFFFFF" />
              </div>

              <h3 style={{
                fontSize: '22px',
                fontWeight: '700',
                color: '#000000',
                marginBottom: '12px'
              }}>
                {category.title}
              </h3>

              <p style={{
                fontSize: '15px',
                color: '#7C7A7A',
                marginBottom: '20px',
                fontWeight: '500'
              }}>
                {category.description}
              </p>

              <ul style={{
                listStyle: 'none',
                padding: 0,
                margin: 0
              }}>
                {category.articles.map((article) => (
                  <li key={article} style={{
                    fontSize: '14px',
                    color: '#FF5D73',
                    marginBottom: '8px',
                    fontWeight: '600',
                    cursor: 'pointer'
                  }}>
                    {article}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section style={{
        background: 'rgba(255, 93, 115, 0.05)',
        padding: '60px 20px',
        textAlign: 'center'
      }}>
        <div style={{
          maxWidth: '600px',
          margin: '0 auto'
        }}>
          <MessageCircle size={48} color="#FF5D73" style={{ marginBottom: '20px' }} />
          <h2 style={{
            fontSize: '32px',
            fontWeight: '700',
            color: '#000000',
            marginBottom: '16px'
          }}>
            Still need help?
          </h2>
          <p style={{
            fontSize: '16px',
            color: '#7C7A7A',
            marginBottom: '24px',
            fontWeight: '500'
          }}>
            Our support team is here to assist you
          </p>
          <button
            onClick={() => onNavigate('home')}
            style={{
              padding: '16px 40px',
              background: 'linear-gradient(135deg, #FF5D73 0%, #FF8A9B 100%)',
              color: '#FFFFFF',
              border: 'none',
              borderRadius: '12px',
              fontSize: '16px',
              fontWeight: '700',
              cursor: 'pointer',
              transition: 'transform 0.2s ease',
              boxShadow: '0 10px 30px rgba(255, 93, 115, 0.3)'
            }}
            onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
            onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
          >
            Contact Support
          </button>
        </div>
      </section>
    </div>
  );
}
