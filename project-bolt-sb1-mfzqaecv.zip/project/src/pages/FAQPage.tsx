import { CircleHelp as HelpCircle, ChevronDown, Search } from 'lucide-react';
import { useState } from 'react';

interface FAQPageProps {
  onNavigate: (page: 'home' | 'admin' | 'profile' | 'about' | 'how-it-works') => void;
}

export default function FAQPage({ onNavigate }: FAQPageProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const faqs = [
    {
      category: 'Getting Started',
      questions: [
        {
          q: 'How do I create an account?',
          a: 'Click the "Sign In" button in the top right corner and select "Sign Up". Fill in your email and password, then verify your email address to complete registration.'
        },
        {
          q: 'Is BookTrips free to use?',
          a: 'Yes, creating an account and browsing events is completely free. You only pay when you purchase event tickets, and pricing varies by event organizer.'
        },
        {
          q: 'How do I find events near me?',
          a: 'Use the search bar on the homepage to enter your location, or enable location services to automatically see events in your area. You can filter by category, date, and distance.'
        }
      ]
    },
    {
      category: 'Tickets & Bookings',
      questions: [
        {
          q: 'How do I purchase tickets?',
          a: 'Find your desired event, click "Get Tickets", select the number of tickets, and complete the checkout process. You\'ll receive a confirmation email with your tickets.'
        },
        {
          q: 'What payment methods do you accept?',
          a: 'We accept all major credit cards (Visa, MasterCard, American Express), debit cards, and digital wallets like Apple Pay and Google Pay.'
        },
        {
          q: 'Can I get a refund on my tickets?',
          a: 'Refund policies are set by individual event organizers. Check the event details page for specific refund information, or contact the organizer directly through the platform.'
        },
        {
          q: 'Where can I find my tickets after purchase?',
          a: 'Your tickets are available in your profile under "My Tickets". You\'ll also receive them via email. You can view, download, or share them from either location.'
        }
      ]
    },
    {
      category: 'Account & Security',
      questions: [
        {
          q: 'How do I reset my password?',
          a: 'Click "Sign In", then "Forgot Password". Enter your email address and we\'ll send you a password reset link. Follow the instructions in the email to create a new password.'
        },
        {
          q: 'Is my payment information secure?',
          a: 'Yes, we use industry-standard encryption and never store your complete credit card information. All payments are processed through secure, PCI-compliant payment processors.'
        },
        {
          q: 'Can I delete my account?',
          a: 'Yes, you can delete your account at any time from your profile settings. Note that this action is permanent and will remove all your data, including ticket history.'
        }
      ]
    },
    {
      category: 'Events & Features',
      questions: [
        {
          q: 'How do I bookmark events?',
          a: 'Click the bookmark icon on any event card to save it to your favorites. Access your saved events anytime from your profile under "Bookmarked Events".'
        },
        {
          q: 'Can I share events with friends?',
          a: 'Absolutely! Each event has a share button that lets you send event details via email, social media, or copy the link to share anywhere.'
        },
        {
          q: 'How are event recommendations personalized?',
          a: 'We analyze your browsing history, bookmarked events, and ticket purchases to suggest events that match your interests. You can update preferences in your profile.'
        }
      ]
    },
    {
      category: 'Organizers',
      questions: [
        {
          q: 'How can I list my event on BookTrips?',
          a: 'Contact our team through the Contact Us page to learn about becoming an event organizer. We\'ll guide you through the setup process and help you list your events.'
        },
        {
          q: 'What are the fees for organizers?',
          a: 'Organizer fees vary based on event size and services required. Contact our sales team for detailed pricing information and to discuss your specific needs.'
        }
      ]
    }
  ];

  const filteredFaqs = faqs.map(category => ({
    ...category,
    questions: category.questions.filter(
      faq =>
        faq.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
        faq.a.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(category => category.questions.length > 0);

  return (
    <div style={{ minHeight: '100vh', background: '#FFFFFF' }}>
      <section style={{
        background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
        padding: '80px 20px 120px',
        position: 'relative',
        overflow: 'hidden'
      }}>
        <div style={{
          maxWidth: '900px',
          margin: '0 auto',
          position: 'relative',
          zIndex: 2,
          textAlign: 'center'
        }}>
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '16px',
            background: 'rgba(255, 255, 255, 0.2)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 24px'
          }}>
            <HelpCircle size={32} color="#FFFFFF" />
          </div>

          <h1 style={{
            fontSize: '56px',
            fontWeight: '800',
            color: '#FFFFFF',
            marginBottom: '24px',
            letterSpacing: '-2px'
          }}>
            Frequently Asked Questions
          </h1>
          <p style={{
            fontSize: '18px',
            color: 'rgba(255, 255, 255, 0.95)',
            marginBottom: '40px',
            fontWeight: '500',
            maxWidth: '600px',
            margin: '0 auto 40px'
          }}>
            Find quick answers to common questions about BookTrips
          </p>

          <div style={{
            maxWidth: '600px',
            margin: '0 auto',
            position: 'relative'
          }}>
            <Search
              size={20}
              style={{
                position: 'absolute',
                left: '20px',
                top: '50%',
                transform: 'translateY(-50%)',
                color: '#7C7A7A'
              }}
            />
            <input
              type="text"
              placeholder="Search FAQs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                width: '100%',
                padding: '18px 20px 18px 56px',
                border: 'none',
                borderRadius: '12px',
                fontSize: '16px',
                fontWeight: '500',
                boxShadow: '0 10px 40px rgba(0, 0, 0, 0.15)'
              }}
            />
          </div>
        </div>
      </section>

      <section style={{
        padding: '80px 20px',
        maxWidth: '900px',
        margin: '0 auto'
      }}>
        {filteredFaqs.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 20px' }}>
            <p style={{
              fontSize: '18px',
              color: '#7C7A7A',
              fontWeight: '500'
            }}>
              No FAQs found matching your search.
            </p>
          </div>
        ) : (
          filteredFaqs.map((category, categoryIndex) => (
            <div key={categoryIndex} style={{ marginBottom: '48px' }}>
              <h2 style={{
                fontSize: '28px',
                fontWeight: '700',
                color: '#000000',
                marginBottom: '24px',
                paddingBottom: '16px',
                borderBottom: '2px solid #4F46E5'
              }}>
                {category.category}
              </h2>

              <div style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '16px'
              }}>
                {category.questions.map((faq, index) => {
                  const globalIndex = categoryIndex * 100 + index;
                  const isOpen = openIndex === globalIndex;

                  return (
                    <div
                      key={index}
                      style={{
                        background: '#FFFFFF',
                        border: '1px solid rgba(0, 0, 0, 0.08)',
                        borderRadius: '12px',
                        overflow: 'hidden',
                        transition: 'all 0.3s ease'
                      }}
                    >
                      <button
                        onClick={() => setOpenIndex(isOpen ? null : globalIndex)}
                        style={{
                          width: '100%',
                          padding: '24px',
                          background: isOpen ? 'rgba(79, 70, 229, 0.05)' : 'transparent',
                          border: 'none',
                          textAlign: 'left',
                          cursor: 'pointer',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          gap: '16px',
                          transition: 'background 0.2s ease'
                        }}
                      >
                        <span style={{
                          fontSize: '18px',
                          fontWeight: '600',
                          color: '#000000',
                          flex: 1
                        }}>
                          {faq.q}
                        </span>
                        <ChevronDown
                          size={24}
                          color="#4F46E5"
                          style={{
                            transform: isOpen ? 'rotate(180deg)' : 'rotate(0)',
                            transition: 'transform 0.3s ease',
                            flexShrink: 0
                          }}
                        />
                      </button>

                      {isOpen && (
                        <div style={{
                          padding: '0 24px 24px',
                          fontSize: '16px',
                          color: '#7C7A7A',
                          lineHeight: '1.8',
                          fontWeight: '500',
                          animation: 'fadeIn 0.3s ease'
                        }}>
                          {faq.a}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))
        )}

        <div style={{
          background: 'linear-gradient(135deg, rgba(79, 70, 229, 0.1) 0%, rgba(124, 58, 237, 0.1) 100%)',
          border: '2px solid #4F46E5',
          borderRadius: '16px',
          padding: '40px',
          marginTop: '60px',
          textAlign: 'center'
        }}>
          <h3 style={{
            fontSize: '24px',
            fontWeight: '700',
            color: '#000000',
            marginBottom: '12px'
          }}>
            Still have questions?
          </h3>
          <p style={{
            fontSize: '16px',
            color: '#7C7A7A',
            marginBottom: '24px',
            fontWeight: '500'
          }}>
            Can't find the answer you're looking for? Our support team is ready to help.
          </p>
          <button
            onClick={() => onNavigate('home')}
            style={{
              padding: '14px 32px',
              background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
              color: '#FFFFFF',
              border: 'none',
              borderRadius: '10px',
              fontSize: '16px',
              fontWeight: '700',
              cursor: 'pointer',
              transition: 'transform 0.2s ease'
            }}
            onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
            onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
          >
            Contact Support
          </button>
        </div>
      </section>

      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
