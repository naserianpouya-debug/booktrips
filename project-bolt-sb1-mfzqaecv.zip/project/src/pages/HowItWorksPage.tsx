import { Search, Bell, Ticket, Share2 } from 'lucide-react';

export default function HowItWorksPage() {
  const steps = [
    {
      icon: Search,
      title: 'Discover Events',
      description: 'Browse through thousands of advertised events or use our smart search to find experiences that match your interests. Filter by category, location, date, and more.',
      details: [
        'Search by keywords, location, or date',
        'Filter by categories like music, sports, arts',
        'View personalized recommendations',
        'Explore trending and popular events'
      ]
    },
    {
      icon: Bell,
      title: 'Get Notified',
      description: 'Never miss an event again. Save your favorite events and get instant notifications about updates, changes, and similar experiences in your area.',
      details: [
        'Bookmark events to your profile',
        'Receive alerts for saved events',
        'Get updates on similar events',
        'Track event status changes'
      ]
    },
    {
      icon: Ticket,
      title: 'Connect with Organizers',
      description: 'Contact event organizers directly for attendance details. Get all the information you need and express your interest in upcoming experiences.',
      details: [
        'View complete event details',
        'Contact organizers directly',
        'Get location and timing info',
        'Express interest and RSVP'
      ]
    },
    {
      icon: Share2,
      title: 'Share & Enjoy',
      description: 'Spread the word about amazing events. Share discoveries with friends on social media and help organizers reach more potential attendees.',
      details: [
        'Share events on social platforms',
        'Invite friends to join',
        'Promote your favorite events',
        'Build event communities'
      ]
    }
  ];

  return (
    <div style={{ minHeight: '100vh', paddingTop: '80px' }}>
      <section style={{
        padding: '80px 20px',
        maxWidth: '1200px',
        margin: '0 auto'
      }}>
        <h1 style={{
          fontSize: '56px',
          fontWeight: '800',
          color: '#000000',
          marginBottom: '24px',
          letterSpacing: '-1.5px',
          textAlign: 'center'
        }}>
          How It Works
        </h1>

        <p style={{
          fontSize: '20px',
          color: '#7C7A7A',
          marginBottom: '60px',
          textAlign: 'center',
          maxWidth: '800px',
          margin: '0 auto 80px',
          lineHeight: '1.8',
          fontWeight: '500'
        }}>
          From discovery to connection, we've made finding and promoting events
          as simple as possible. Here's how BookTrips works.
        </p>

        <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '48px'
        }}>
          {steps.map((step, index) => (
            <div
              key={index}
              style={{
                display: 'grid',
                gridTemplateColumns: index % 2 === 0 ? '1fr 1fr' : '1fr 1fr',
                gap: '48px',
                alignItems: 'center'
              }}
            >
              <div style={{
                order: index % 2 === 0 ? 1 : 2,
                background: 'rgba(255, 255, 255, 0.8)',
                backdropFilter: 'blur(20px)',
                borderRadius: '24px',
                padding: '48px',
                border: '1px solid rgba(0, 0, 0, 0.06)',
                boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08)'
              }}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '20px',
                  marginBottom: '24px'
                }}>
                  <div style={{
                    width: '64px',
                    height: '64px',
                    background: 'linear-gradient(135deg, #FF5D73, #ff4560)',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                    boxShadow: '0 8px 24px rgba(255, 93, 115, 0.3)'
                  }}>
                    <step.icon size={28} color="#FFFFFF" />
                  </div>
                  <div>
                    <div style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      color: '#FF5D73',
                      marginBottom: '4px'
                    }}>
                      STEP {index + 1}
                    </div>
                    <h3 style={{
                      fontSize: '28px',
                      fontWeight: '800',
                      color: '#000000',
                      letterSpacing: '-0.5px'
                    }}>
                      {step.title}
                    </h3>
                  </div>
                </div>
                <p style={{
                  fontSize: '16px',
                  color: '#5A5A5A',
                  lineHeight: '1.8',
                  marginBottom: '24px',
                  fontWeight: '500'
                }}>
                  {step.description}
                </p>
                <ul style={{
                  listStyle: 'none',
                  padding: 0,
                  margin: 0
                }}>
                  {step.details.map((detail, idx) => (
                    <li
                      key={idx}
                      style={{
                        fontSize: '15px',
                        color: '#7C7A7A',
                        marginBottom: '12px',
                        paddingLeft: '24px',
                        position: 'relative',
                        fontWeight: '500'
                      }}
                    >
                      <span style={{
                        position: 'absolute',
                        left: 0,
                        top: '6px',
                        width: '8px',
                        height: '8px',
                        background: '#FF5D73',
                        borderRadius: '50%'
                      }} />
                      {detail}
                    </li>
                  ))}
                </ul>
              </div>

              <div style={{
                order: index % 2 === 0 ? 2 : 1,
                height: '400px',
                background: `linear-gradient(135deg, rgba(255, 93, 115, ${0.15 - index * 0.02}), rgba(255, 93, 115, ${0.05 - index * 0.01}))`,
                borderRadius: '24px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '80px',
                fontWeight: '900',
                color: 'rgba(0, 0, 0, 0.05)',
                border: '1px solid rgba(0, 0, 0, 0.03)'
              }}>
                {index + 1}
              </div>
            </div>
          ))}
        </div>

        <div style={{
          marginTop: '80px',
          background: 'linear-gradient(135deg, #FF5D73, #ff4560)',
          borderRadius: '32px',
          padding: '60px 40px',
          textAlign: 'center',
          boxShadow: '0 16px 48px rgba(255, 93, 115, 0.3)'
        }}>
          <h2 style={{
            fontSize: '36px',
            fontWeight: '800',
            color: '#FFFFFF',
            marginBottom: '16px',
            letterSpacing: '-0.5px'
          }}>
            Ready to Get Started?
          </h2>
          <p style={{
            fontSize: '18px',
            color: 'rgba(255, 255, 255, 0.9)',
            marginBottom: '32px',
            fontWeight: '500'
          }}>
            Join thousands of organizers and millions of attendees connecting through BookTrips today.
          </p>
          <button
            style={{
              background: '#FFFFFF',
              color: '#FF5D73',
              border: 'none',
              padding: '16px 40px',
              borderRadius: '16px',
              fontSize: '16px',
              fontWeight: '700',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              boxShadow: '0 8px 24px rgba(0, 0, 0, 0.15)'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 12px 32px rgba(0, 0, 0, 0.2)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.15)';
            }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            Start Exploring Events
          </button>
        </div>
      </section>

      <style>{`
        @media (max-width: 768px) {
          div[style*="grid-template-columns"] {
            grid-template-columns: 1fr !important;
          }
          div[style*="order"] {
            order: 1 !important;
          }
        }
      `}</style>
    </div>
  );
}
