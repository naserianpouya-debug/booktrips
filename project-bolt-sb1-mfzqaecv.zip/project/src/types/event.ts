export interface Event {
  id: string;
  title: string;
  date: string;
  location: string;
  category: string;
  image: string;
  description: string;
  sponsored?: boolean;
  featured?: boolean;
  trending?: boolean;
  created_by?: string;
  created_at?: string;
  updated_at?: string;
}
