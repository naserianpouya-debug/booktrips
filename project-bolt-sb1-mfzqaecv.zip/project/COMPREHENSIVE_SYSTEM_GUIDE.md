# EventGo - Comprehensive Event Management System

## Table of Contents
1. [System Overview](#system-overview)
2. [Database Schema](#database-schema)
3. [User Roles & Permissions](#user-roles--permissions)
4. [Authentication System](#authentication-system)
5. [Cookie Management](#cookie-management)
6. [Analytics & Tracking](#analytics--tracking)
7. [API Documentation](#api-documentation)
8. [Security Features](#security-features)
9. [Setup Instructions](#setup-instructions)
10. [User Guide](#user-guide)

---

## System Overview

EventGo is a comprehensive event management platform with a two-tier user system (Admin and Regular users), complete authentication, cookie-based analytics, and bookmark functionality.

### Core Features:
- **Admin Panel**: Full CRUD operations for events
- **User Profile**: Save and manage favorite events
- **Authentication**: Secure signup/login with session management
- **Analytics**: Cookie-based user behavior tracking
- **Bookmarks**: Save events to personal collection
- **Role-Based Access**: Different permissions for admins vs regular users

---

## Database Schema

### Tables

#### 1. `events`
Stores all event information.

```sql
CREATE TABLE events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  date text NOT NULL,
  location text NOT NULL,
  category text NOT NULL DEFAULT 'General',
  image text NOT NULL,
  description text NOT NULL,
  sponsored boolean DEFAULT false,
  featured boolean DEFAULT false,
  trending boolean DEFAULT false,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
```

**Fields:**
- `id`: Unique identifier
- `title`: Event name
- `date`: Event date (formatted string like "Oct 15, 2025")
- `location`: Event location
- `category`: Event category (Music, Food, Art, Tech, Sports, etc.)
- `image`: URL to event image
- `description`: Event details
- `sponsored`: Whether event is sponsored
- `featured`: Show in featured slider
- `trending`: Show in trending section
- `created_by`: Admin who created the event
- `created_at`, `updated_at`: Timestamps

#### 2. `user_roles`
Manages user permissions.

```sql
CREATE TABLE user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  role text NOT NULL DEFAULT 'user',
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_role CHECK (role IN ('admin', 'user'))
);
```

**Roles:**
- `admin`: Full CRUD on events, access to admin dashboard
- `user`: View events, bookmark events, view own profile

#### 3. `bookmarked_events`
Stores user's saved events.

```sql
CREATE TABLE bookmarked_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  event_id uuid REFERENCES events(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, event_id)
);
```

**Purpose:**
- Prevents duplicate bookmarks (unique constraint)
- Cascades delete when user or event is removed
- Tracks when bookmark was created

#### 4. `user_analytics`
Tracks user behavior and actions.

```sql
CREATE TABLE user_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  session_id text NOT NULL,
  event_id uuid REFERENCES events(id) ON DELETE SET NULL,
  action_type text NOT NULL,
  page_url text,
  user_agent text,
  ip_address inet,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);
```

**Action Types:**
- `page_view`: User visits a page
- `event_view`: User views event details
- `event_bookmark`: User bookmarks an event
- `event_unbookmark`: User removes bookmark
- `event_share`: User shares an event
- `search`: User performs search
- `filter_applied`: User applies filters
- `user_login`: User logs in
- `user_signup`: User creates account
- `user_logout`: User logs out

#### 5. `user_preferences`
Stores user preferences and settings.

```sql
CREATE TABLE user_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  preferred_categories text[] DEFAULT ARRAY[]::text[],
  preferred_locations text[] DEFAULT ARRAY[]::text[],
  email_notifications boolean DEFAULT true,
  theme text DEFAULT 'light',
  updated_at timestamptz DEFAULT now()
);
```

### Database Relationships

```
auth.users (Supabase Auth)
    ├── user_roles (one-to-one)
    ├── events (one-to-many, via created_by)
    ├── bookmarked_events (one-to-many)
    ├── user_analytics (one-to-many)
    └── user_preferences (one-to-one)

events
    ├── bookmarked_events (one-to-many)
    └── user_analytics (one-to-many, optional)
```

### Indexes

```sql
-- Events
CREATE INDEX events_created_by_idx ON events(created_by);
CREATE INDEX events_featured_idx ON events(featured);
CREATE INDEX events_trending_idx ON events(trending);
CREATE INDEX events_category_idx ON events(category);

-- Bookmarks
CREATE INDEX bookmarked_events_user_id_idx ON bookmarked_events(user_id, created_at DESC);
CREATE INDEX bookmarked_events_event_id_idx ON bookmarked_events(event_id);

-- Analytics
CREATE INDEX user_analytics_session_id_idx ON user_analytics(session_id, created_at DESC);
CREATE INDEX user_analytics_user_id_idx ON user_analytics(user_id, action_type);
CREATE INDEX user_analytics_event_id_idx ON user_analytics(event_id);
```

---

## User Roles & Permissions

### Admin Users

**Capabilities:**
- Create, edit, and delete ALL events
- Access admin dashboard (`/admin`)
- View all analytics (future feature)
- Manage events in real-time

**Restrictions:**
- Must be explicitly granted admin role in database

### Regular Users

**Capabilities:**
- Sign up and log in
- View all events
- Bookmark/unbookmark events
- View saved events in profile (`/profile`)
- Search and filter events
- Share events

**Restrictions:**
- Cannot create, edit, or delete events
- Cannot access admin dashboard
- Can only view own bookmarks and preferences

---

## Authentication System

### Email/Password Authentication

**Sign Up Flow:**
1. User provides email and password
2. Password must be at least 6 characters
3. Account created in Supabase Auth
4. Automatic role assignment (default: 'user')
5. Analytics tracked: `user_signup`

**Login Flow:**
1. User provides credentials
2. Optional "Remember Me" checkbox (30-day session)
3. Session created in Supabase
4. Cookie set: `eventgo_session_id`
5. Analytics tracked: `user_login`

**Logout Flow:**
1. User clicks logout
2. Analytics tracked: `user_logout`
3. Supabase session cleared
4. Redirect to home

### Session Management

**Persistent Sessions:**
```typescript
// 30-day session when "Remember Me" is checked
{
  persistSession: true,
  maxAge: 30 * 24 * 60 * 60 // 30 days
}
```

**Temporary Sessions:**
```typescript
// Session-only (cleared on browser close)
{
  persistSession: false
}
```

### Security Features

1. **Password Requirements:**
   - Minimum 6 characters
   - Validated on both client and server

2. **Session Security:**
   - HttpOnly cookies (when possible)
   - Secure flag in production (HTTPS)
   - SameSite: Lax

3. **CSRF Protection:**
   - Built into Supabase Auth
   - Token-based authentication

---

## Cookie Management

### Cookie Types

#### 1. Session Cookie
```typescript
Cookie: eventgo_session_id
Purpose: Track user sessions for analytics
Max Age: 30 days
Secure: true (in production)
SameSite: lax
```

#### 2. Preference Cookies
```typescript
Cookie: eventgo_pref_*
Purpose: Store user preferences (theme, etc.)
Max Age: 365 days
Secure: true (in production)
SameSite: lax
```

### Cookie Functions

```typescript
// Set cookie
cookies.set('name', 'value', {
  maxAge: 30 * 24 * 60 * 60,
  secure: true,
  sameSite: 'lax'
});

// Get cookie
const value = cookies.get('name');

// Remove cookie
cookies.remove('name');

// Get all cookies
const allCookies = cookies.getAll();
```

### Session ID Generation

```typescript
function generateSessionId(): string {
  return `session_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
}
```

**Format:** `session_1696800000000_abc123xyz`

---

## Analytics & Tracking

### Analytics Events

```typescript
// Page view
analytics.trackPageView();

// Event interactions
analytics.trackEventView(eventId, eventTitle);
analytics.trackBookmark(eventId, eventTitle);
analytics.trackUnbookmark(eventId, eventTitle);
analytics.trackShare(eventId, platform);

// Search and filters
analytics.trackSearch(searchTerm, resultsCount);
analytics.trackFilter(filters);

// Authentication
analytics.trackUserLogin(method);
analytics.trackUserSignup(method);
analytics.trackUserLogout();
```

### Analytics Data Structure

```typescript
{
  user_id: 'uuid | null',          // Null for anonymous users
  session_id: 'session_xxx',       // From cookie
  event_id: 'uuid | null',         // If action relates to event
  action_type: 'page_view',        // Type of action
  page_url: 'https://...',         // Current URL
  user_agent: 'Mozilla/5.0...',    // Browser info
  ip_address: '192.168.1.1',       // User IP
  metadata: {                      // Additional context
    event_title: 'Summer Fest',
    search_term: 'music',
    filters: {...}
  },
  created_at: '2025-10-06T...'
}
```

### Analytics Queries

**Most viewed events:**
```sql
SELECT event_id, COUNT(*) as views
FROM user_analytics
WHERE action_type = 'event_view'
GROUP BY event_id
ORDER BY views DESC
LIMIT 10;
```

**User engagement:**
```sql
SELECT user_id, COUNT(DISTINCT action_type) as action_types
FROM user_analytics
WHERE user_id IS NOT NULL
GROUP BY user_id;
```

**Popular search terms:**
```sql
SELECT metadata->>'search_term' as term, COUNT(*) as count
FROM user_analytics
WHERE action_type = 'search'
GROUP BY term
ORDER BY count DESC;
```

---

## API Documentation

### Events API

#### Get All Events
```typescript
const { data, error } = await supabase
  .from('events')
  .select('*')
  .order('created_at', { ascending: false });
```

#### Get Featured Events
```typescript
const { data, error } = await supabase
  .from('events')
  .select('*')
  .eq('featured', true);
```

#### Get Trending Events
```typescript
const { data, error } = await supabase
  .from('events')
  .select('*')
  .eq('trending', true);
```

#### Create Event (Admin Only)
```typescript
const { data, error } = await supabase
  .from('events')
  .insert({
    title: 'Event Title',
    date: 'Oct 15, 2025',
    location: 'City Name',
    category: 'Music',
    image: 'https://...',
    description: 'Event description',
    featured: false,
    trending: false,
    created_by: user.id
  });
```

#### Update Event (Admin Only)
```typescript
const { data, error } = await supabase
  .from('events')
  .update({ title: 'New Title' })
  .eq('id', eventId);
```

#### Delete Event (Admin Only)
```typescript
const { data, error } = await supabase
  .from('events')
  .delete()
  .eq('id', eventId);
```

### Bookmarks API

#### Get User's Bookmarks
```typescript
const { data, error } = await supabase
  .from('bookmarked_events')
  .select(`
    event_id,
    events (*)
  `)
  .eq('user_id', user.id);
```

#### Add Bookmark
```typescript
const { data, error } = await supabase
  .from('bookmarked_events')
  .insert({
    user_id: user.id,
    event_id: eventId
  });
```

#### Remove Bookmark
```typescript
const { data, error } = await supabase
  .from('bookmarked_events')
  .delete()
  .eq('user_id', user.id)
  .eq('event_id', eventId);
```

### Analytics API

#### Track Event
```typescript
const { data, error } = await supabase
  .from('user_analytics')
  .insert({
    user_id: user?.id || null,
    session_id: sessionId,
    event_id: eventId || null,
    action_type: 'page_view',
    page_url: window.location.href,
    user_agent: navigator.userAgent,
    metadata: {}
  });
```

---

## Security Features

### Row Level Security (RLS)

All tables have RLS enabled with specific policies:

#### Events Table
```sql
-- Anyone can view events
CREATE POLICY "Anyone can view events"
  ON events FOR SELECT
  TO authenticated, anon
  USING (true);

-- Only admins can create events
CREATE POLICY "Admins can insert events"
  ON events FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- Only admins can update events
CREATE POLICY "Admins can update events"
  ON events FOR UPDATE
  TO authenticated
  USING (...admin check...)
  WITH CHECK (...admin check...);

-- Only admins can delete events
CREATE POLICY "Admins can delete events"
  ON events FOR DELETE
  TO authenticated
  USING (...admin check...);
```

#### Bookmarks Table
```sql
-- Users can view own bookmarks
CREATE POLICY "Users can view own bookmarks"
  ON bookmarked_events FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Users can create own bookmarks
CREATE POLICY "Users can create own bookmarks"
  ON bookmarked_events FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Users can delete own bookmarks
CREATE POLICY "Users can delete own bookmarks"
  ON bookmarked_events FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);
```

#### Analytics Table
```sql
-- Anyone can insert analytics (for anonymous tracking)
CREATE POLICY "Anyone can insert analytics"
  ON user_analytics FOR INSERT
  TO authenticated, anon
  WITH CHECK (true);

-- Users can view own analytics
CREATE POLICY "Users can view own analytics"
  ON user_analytics FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Admins can view all analytics
CREATE POLICY "Admins can view all analytics"
  ON user_analytics FOR SELECT
  TO authenticated
  USING (...admin check...);
```

### Additional Security

1. **SQL Injection Prevention**: Parameterized queries via Supabase
2. **XSS Prevention**: React escapes all user input by default
3. **CSRF Protection**: Built into Supabase Auth
4. **Secure Cookies**: HttpOnly, Secure, SameSite flags
5. **Password Hashing**: Handled by Supabase Auth (bcrypt)

---

## Setup Instructions

### 1. Database Setup

The migrations will run automatically when Supabase is available:

- `supabase/migrations/20251006_create_events_system.sql`
- `supabase/migrations/20251007_add_bookmarks_and_analytics.sql`

### 2. Create Admin User

After database setup, grant admin access to a user:

```sql
-- First, sign up a user on the website

-- Then run this in Supabase SQL editor:
INSERT INTO user_roles (user_id, role)
SELECT id, 'admin'
FROM auth.users
WHERE email = 'your-email@example.com';
```

### 3. Environment Variables

Ensure these are set in `.env`:

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_anon_key
```

### 4. Install Dependencies

```bash
npm install
```

### 5. Run Development Server

```bash
npm run dev
```

### 6. Build for Production

```bash
npm run build
```

---

## User Guide

### For Regular Users

#### Creating an Account
1. Click "Sign In" in the navigation bar
2. Click "Sign Up"
3. Enter email and password (min 6 characters)
4. Click "Sign Up"
5. You can now log in

#### Bookmarking Events
1. Browse events on the home page
2. Click the "Save" button on any event card
3. Button turns green when bookmarked
4. Click again to remove bookmark

#### Viewing Saved Events
1. Log in to your account
2. Click your profile icon
3. Click "Saved Events"
4. View all your bookmarked events

### For Admin Users

#### Accessing Admin Dashboard
1. Log in with admin account
2. Click profile icon
3. Click "Admin Dashboard"

#### Creating Events
1. In admin dashboard, click "Create Event"
2. Fill in all required fields:
   - Title, Date, Location, Category
   - Image URL, Description
3. Optionally mark as Featured, Trending, or Sponsored
4. Click "Create Event"

#### Editing Events
1. Find the event in admin dashboard
2. Click "Edit" button
3. Make changes
4. Click "Update Event"

#### Deleting Events
1. Find the event in admin dashboard
2. Click "Delete" button
3. Confirm deletion

---

## Technical Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Inline styles with modern design
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth
- **State Management**: React Context API
- **Build Tool**: Vite
- **Analytics**: Custom cookie-based system

---

## File Structure

```
src/
├── components/
│   ├── AuthModal.tsx           # Login/Signup modal
│   ├── EventCard.tsx            # Event card with bookmark
│   ├── EventDetailsModal.tsx    # Event detail view
│   ├── FeaturedSlider.tsx       # Featured events slider
│   ├── TrendingNow.tsx          # Trending events
│   ├── EventsForYou.tsx         # All events list
│   ├── Navbar.tsx               # Navigation with auth
│   └── admin/
│       └── EventFormModal.tsx   # Event create/edit form
├── pages/
│   ├── AdminDashboard.tsx       # Admin event management
│   └── ProfilePage.tsx          # User profile & bookmarks
├── context/
│   ├── AuthContext.tsx          # Authentication state
│   └── SearchContext.tsx        # Search/filter state
├── hooks/
│   ├── useEvents.ts             # Fetch events from DB
│   └── useBookmarks.ts          # Bookmark management
├── utils/
│   ├── cookies.ts               # Cookie utilities
│   └── analytics.ts             # Analytics tracking
├── lib/
│   └── supabase.ts              # Supabase client
└── types/
    └── event.ts                 # TypeScript types

supabase/migrations/
├── 20251006_create_events_system.sql      # Initial schema
└── 20251007_add_bookmarks_and_analytics.sql  # Bookmarks & analytics
```

---

## Future Enhancements

Potential features to add:

1. **Image Upload**: Direct image upload vs URLs
2. **Event Calendar**: Calendar view of events
3. **Email Notifications**: Notify users of new events
4. **Event Recommendations**: AI-based suggestions
5. **Social Sharing**: Share to social media
6. **Event Reviews**: User reviews and ratings
7. **Analytics Dashboard**: Admin analytics view
8. **Multi-language Support**: Internationalization
9. **Mobile App**: React Native version
10. **Event Registration**: RSVP functionality

---

*Last Updated: October 2025*
