-- This script will help you set up admin access and create sample events
-- Run this in the Supabase SQL Editor once the service is available

-- Step 1: First, create a user account through your app's signup page
-- Note the user ID from the Authentication section in Supabase dashboard
-- Then replace 'YOUR_USER_ID_HERE' below with your actual user ID

-- Step 2: Grant admin privileges to your user
INSERT INTO user_roles (user_id, role)
VALUES ('YOUR_USER_ID_HERE', 'admin')
ON CONFLICT (user_id) DO UPDATE SET role = 'admin';

-- Step 3: Create sample events
INSERT INTO events (title, date, location, category, image, description, featured, trending, sponsored)
VALUES
(
  'Summer Jazz Festival',
  'Jul 20-22, 2025',
  'New York',
  'Music',
  'https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae',
  'Experience three days of incredible jazz performances featuring world-renowned artists and emerging talents. From smooth classics to contemporary fusion, this festival celebrates the rich history and vibrant future of jazz music. Enjoy outdoor stages, intimate indoor venues, and late-night jam sessions.',
  true,
  true,
  false
),
(
  'Tech Innovation Summit',
  'Aug 5, 2025',
  'San Francisco',
  'Technology',
  'https://images.unsplash.com/photo-1540575467063-178a50c2df87',
  'Join industry leaders, innovators, and entrepreneurs for a day of inspiring talks, hands-on workshops, and networking opportunities. Explore the latest trends in AI, blockchain, and sustainable technology. Connect with investors and discover groundbreaking startups shaping the future.',
  true,
  false,
  true
),
(
  'Art Gallery Opening: Modern Visions',
  'Jun 15, 2025',
  'London',
  'Arts & Culture',
  'https://images.unsplash.com/photo-1531243269054-5ebf6f34081e',
  'Celebrate the opening of a stunning new exhibition featuring contemporary artists from around the world. This curated collection explores themes of identity, technology, and human connection through painting, sculpture, and digital art. Meet the artists and enjoy complimentary wine and hors d''oeuvres.',
  false,
  true,
  false
),
(
  'Marathon for Health',
  'Sep 10, 2025',
  'Boston',
  'Sports & Fitness',
  'https://images.unsplash.com/photo-1452626038306-9aae5e071dd3',
  'Join thousands of runners in this annual charity marathon supporting local health initiatives. Choose from full marathon, half marathon, or 5K fun run options. All skill levels welcome! Registration includes a commemorative t-shirt, finisher medal, and post-race celebration.',
  false,
  false,
  false
),
(
  'Food & Wine Festival',
  'Oct 12-14, 2025',
  'Paris',
  'Food & Drink',
  'https://images.unsplash.com/photo-1555939594-58d7cb561ad1',
  'Indulge in a celebration of culinary excellence featuring renowned chefs, sommeliers, and food artisans. Sample exquisite dishes, attend cooking demonstrations, and discover perfect wine pairings. This three-day festival showcases the best of French and international cuisine in the heart of Paris.',
  true,
  false,
  true
),
(
  'Outdoor Film Festival',
  'Aug 18-20, 2025',
  'Los Angeles',
  'Entertainment',
  'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba',
  'Watch classic and contemporary films under the stars at this beloved annual event. Bring blankets and picnic baskets to enjoy movies on a giant outdoor screen. Each evening features a different genre, from romantic comedies to action thrillers, with special guest appearances by filmmakers.',
  false,
  true,
  false
),
(
  'Business Leadership Conference',
  'Nov 8-9, 2025',
  'Chicago',
  'Business',
  'https://images.unsplash.com/photo-1511578314322-379afb476865',
  'Learn from top executives and thought leaders at this intensive two-day conference focused on strategic leadership, innovation, and organizational excellence. Participate in breakout sessions, panel discussions, and networking events designed to elevate your leadership skills and business acumen.',
  false,
  false,
  true
),
(
  'Comedy Night Spectacular',
  'Jul 25, 2025',
  'New York',
  'Entertainment',
  'https://images.unsplash.com/photo-1585699324551-f6c309eedeca',
  'Get ready for an unforgettable evening of laughter featuring a stellar lineup of stand-up comedians. From rising stars to household names, this show promises non-stop entertainment. Perfect for date night or a fun outing with friends. Limited seating available.',
  true,
  true,
  false
),
(
  'Yoga & Wellness Retreat',
  'Sep 22-24, 2025',
  'Bali',
  'Sports & Fitness',
  'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b',
  'Escape to paradise for a transformative weekend of yoga, meditation, and holistic wellness practices. Expert instructors will guide you through daily sessions in a stunning tropical setting. Includes healthy gourmet meals, spa treatments, and mindfulness workshops. All levels welcome.',
  false,
  false,
  false
),
(
  'Classic Car Show',
  'Oct 5, 2025',
  'Detroit',
  'Automotive',
  'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7',
  'Admire hundreds of pristine vintage and classic automobiles at this annual showcase. From muscle cars to luxury classics, see meticulously restored vehicles and rare models. Meet collectors, participate in awards voting, and enjoy live music and food trucks throughout the day.',
  false,
  true,
  false
);

-- Step 4: Verify the data was inserted
SELECT COUNT(*) as total_events FROM events;
SELECT * FROM events ORDER BY created_at DESC LIMIT 5;
