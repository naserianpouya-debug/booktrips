# Loop Structure Guide for Event Cards

## Overview
This guide explains the improved loop structure for rendering event cards dynamically in the BookTrips application.

---

## **The Problem: Repetitive Code**

### Before Optimization
The original code had **250+ lines of inline JSX** inside a `.map()` loop, making it:
- ❌ Hard to maintain
- ❌ Difficult to debug
- ❌ Not reusable
- ❌ Poor performance
- ❌ Violates DRY (Don't Repeat Yourself) principle

```tsx
// BAD: Inline rendering in loop (250+ lines)
{events.map((event, index) => (
  <div key={index} style={{...}}>
    {/* 250+ lines of inline JSX */}
    <div>...</div>
    <button>...</button>
    {/* More complex JSX */}
  </div>
))}
```

---

## **The Solution: Component Extraction**

### After Optimization
Created a **reusable `EventCardCompact` component** with clean loop structure:

```tsx
// GOOD: Clean loop with component
{events.map((event, index) => (
  <EventCardCompact
    key={`${event.id}-${index}`}
    event={event}
    onClick={() => onEventClick(event)}
  />
))}
```

**Benefits:**
- ✅ 3 lines instead of 250+
- ✅ Easy to maintain
- ✅ Reusable across app
- ✅ Better performance
- ✅ Follows React best practices

---

## **Loop Structure Breakdown**

### **1. TypeScript/React .map() Loop**

**Language:** TypeScript/React
**Loop Type:** Array.map() (declarative loop)
**Iterates Over:** Array of Event objects
**Action:** Renders EventCardCompact component for each event

```tsx
{filteredEvents.map((event, index) => (
  <EventCardCompact
    key={`${event.id}-${index}`}
    event={event}
    onClick={() => onEventClick(event)}
  />
))}
```

### **Components:**

| Part | Purpose |
|------|---------|
| `filteredEvents` | Array of event objects to loop through |
| `.map()` | Transforms each event into a React component |
| `(event, index)` | Current event object and its array index |
| `key={...}` | Unique identifier for React reconciliation |
| `event={event}` | Passes event data to component |
| `onClick={...}` | Callback function for click handling |

---

## **Advanced Loop Pattern: Infinite Scroll**

### **Duplicating Array for Seamless Scrolling**

```tsx
{/* Create infinite scroll effect by duplicating events */}
{[...filteredEvents, ...filteredEvents].map((event, index) => (
  <EventCardCompact
    key={`${event.id}-${index}`}
    event={event}
    onClick={() => onEventClick(event)}
  />
))}
```

**How it works:**
1. `[...filteredEvents, ...filteredEvents]` - Spread operator duplicates array
2. Creates seamless infinite scroll effect
3. Each item gets unique key with index suffix

**Example:**
```javascript
// Original array: [event1, event2, event3]
// After spread: [event1, event2, event3, event1, event2, event3]
```

---

## **Loop Variations for Different Use Cases**

### **1. Simple Rendering Loop**
**When to use:** Static list without interactions

```tsx
{events.map(event => (
  <EventCardCompact key={event.id} event={event} />
))}
```

### **2. Loop with Index**
**When to use:** Need position information or alternating styles

```tsx
{events.map((event, index) => (
  <EventCardCompact
    key={event.id}
    event={event}
    isEven={index % 2 === 0}
  />
))}
```

### **3. Conditional Rendering in Loop**
**When to use:** Filter or show/hide based on conditions

```tsx
{events.map(event => (
  event.isActive && (
    <EventCardCompact key={event.id} event={event} />
  )
))}
```

### **4. Loop with Filtering**
**When to use:** Show only specific items

```tsx
{events
  .filter(event => event.sponsored)
  .map(event => (
    <EventCardCompact key={event.id} event={event} />
  ))}
```

### **5. Loop with Sorting**
**When to use:** Display items in specific order

```tsx
{events
  .sort((a, b) => new Date(a.date) - new Date(b.date))
  .map(event => (
    <EventCardCompact key={event.id} event={event} />
  ))}
```

---

## **Best Practices**

### **✅ Do's**

1. **Always use unique keys**
```tsx
// Good
key={event.id}
key={`${event.id}-${index}`}

// Bad
key={index} // Only use if no unique ID available
```

2. **Extract complex components**
```tsx
// Good: Separate component
<EventCardCompact event={event} />

// Bad: 200+ lines inline
<div>{/* massive inline JSX */}</div>
```

3. **Use meaningful variable names**
```tsx
// Good
events.map(event => ...)

// Bad
arr.map(x => ...)
```

4. **Handle empty arrays**
```tsx
{events.length > 0 ? (
  events.map(event => <EventCardCompact key={event.id} event={event} />)
) : (
  <p>No events found</p>
)}
```

### **❌ Don'ts**

1. **Don't mutate array while looping**
```tsx
// Bad: Causes bugs
events.map(event => {
  events.push(newEvent); // DON'T
  return <EventCardCompact event={event} />
})
```

2. **Don't use array index as key if order changes**
```tsx
// Bad: If items can be reordered/deleted
events.map((event, index) => (
  <EventCardCompact key={index} event={event} />
))
```

3. **Don't put heavy logic in loops**
```tsx
// Bad: Performance issue
events.map(event => {
  const result = expensiveCalculation(); // Don't
  return <EventCardCompact event={event} />
})

// Good: Calculate outside loop
const results = expensiveCalculation();
events.map(event => <EventCardCompact event={event} />)
```

---

## **Performance Optimization**

### **1. Use React.memo for Components**
```tsx
import { memo } from 'react';

const EventCardCompact = memo(({ event, onClick }) => {
  // Component code
});
```

### **2. Implement Virtual Scrolling**
For large lists (1000+ items), use virtualization:

```tsx
import { FixedSizeList } from 'react-window';

<FixedSizeList
  height={600}
  itemCount={events.length}
  itemSize={450}
  width="100%"
>
  {({ index, style }) => (
    <div style={style}>
      <EventCardCompact event={events[index]} />
    </div>
  )}
</FixedSizeList>
```

### **3. Lazy Loading**
Load more items as user scrolls:

```tsx
const [visibleEvents, setVisibleEvents] = useState(events.slice(0, 10));

useEffect(() => {
  // Load more on scroll
  const handleScroll = () => {
    if (nearBottom()) {
      setVisibleEvents(prev => [...prev, ...events.slice(prev.length, prev.length + 10)]);
    }
  };
  window.addEventListener('scroll', handleScroll);
  return () => window.removeEventListener('scroll', handleScroll);
}, []);
```

---

## **Common Loop Patterns**

### **Pattern 1: Grid Layout**
```tsx
<div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '24px' }}>
  {events.map(event => (
    <EventCard key={event.id} event={event} />
  ))}
</div>
```

### **Pattern 2: Horizontal Scroll**
```tsx
<div style={{ display: 'flex', gap: '24px', overflowX: 'auto' }}>
  {events.map(event => (
    <EventCardCompact key={event.id} event={event} />
  ))}
</div>
```

### **Pattern 3: Grouped by Category**
```tsx
{Object.entries(groupedEvents).map(([category, events]) => (
  <div key={category}>
    <h2>{category}</h2>
    {events.map(event => (
      <EventCard key={event.id} event={event} />
    ))}
  </div>
))}
```

### **Pattern 4: Alternating Layout**
```tsx
{events.map((event, index) => (
  <EventCard
    key={event.id}
    event={event}
    layout={index % 2 === 0 ? 'left' : 'right'}
  />
))}
```

---

## **TypeScript Types for Loops**

### **Event Interface**
```typescript
interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  location: string;
  category: string;
  image: string;
  sponsored?: boolean;
}
```

### **Loop with Typed Parameters**
```tsx
// Explicitly typed
events.map((event: Event, index: number) => (
  <EventCardCompact key={event.id} event={event} />
))

// Type inference (preferred)
events.map((event, index) => (
  <EventCardCompact key={event.id} event={event} />
))
```

---

## **Debugging Loop Issues**

### **Common Issues:**

**1. Missing Keys Warning**
```tsx
// Warning: Each child in a list should have a unique "key" prop
// Fix: Add unique key
<EventCard key={event.id} event={event} />
```

**2. Empty Renders**
```tsx
// Issue: Loop returns nothing
{events.map(event => {
  console.log(event); // This causes undefined return
})}

// Fix: Return JSX explicitly
{events.map(event => {
  console.log(event);
  return <EventCard key={event.id} event={event} />;
})}

// Or use implicit return
{events.map(event => (
  <EventCard key={event.id} event={event} />
))}
```

**3. Performance Issues**
```tsx
// Use React DevTools Profiler to identify slow renders
// Look for components re-rendering unnecessarily
```

---

## **File Structure**

```
src/
├── components/
│   ├── EventCardCompact.tsx      ← Reusable card component
│   ├── EventCard.tsx              ← Full-size card variant
│   ├── FeaturedSlider.tsx         ← Uses loop to render cards
│   ├── EventsForYou.tsx           ← Uses loop to render cards
│   └── TrendingNow.tsx            ← Uses loop to render cards
├── hooks/
│   └── useEvents.ts               ← Fetches event data
└── types/
    └── event.ts                   ← Event type definitions
```

---

## **Summary**

### **Before: Messy Inline Loop**
- 250+ lines of code in one loop
- Hard to maintain
- No reusability
- Poor performance

### **After: Clean Component Loop**
- 3 lines of loop code
- Easy to maintain
- Highly reusable
- Better performance
- Follows best practices

### **Key Takeaway**
**Always extract complex JSX into separate components when using loops. Your future self will thank you!**

---

## **Additional Resources**

- [React Lists and Keys Documentation](https://react.dev/learn/rendering-lists)
- [Array.prototype.map() - MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map)
- [React Performance Optimization](https://react.dev/learn/render-and-commit)
- [TypeScript with React](https://react.dev/learn/typescript)

---

## **Quick Reference**

```tsx
// Basic loop
{items.map(item => <Component key={item.id} data={item} />)}

// With index
{items.map((item, i) => <Component key={item.id} index={i} data={item} />)}

// With filter
{items.filter(item => item.active).map(item => <Component key={item.id} data={item} />)}

// With sort
{items.sort((a, b) => a.date - b.date).map(item => <Component key={item.id} data={item} />)}

// Conditional rendering
{items.map(item => item.visible && <Component key={item.id} data={item} />)}

// Empty state
{items.length > 0 ? items.map(item => <Component key={item.id} data={item} />) : <Empty />}
```
