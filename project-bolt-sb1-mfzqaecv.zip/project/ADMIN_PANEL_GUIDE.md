# EventGo Admin Panel Guide

## Overview
Your EventGo website now includes a powerful admin panel that allows you to manage events without touching any code. This guide explains how to use all the features.

---

## Getting Started

### 1. Setting Up Database (One-Time Setup)

The database migration file has been created at:
```
supabase/migrations/20251006_create_events_system.sql
```

Once the Supabase service is available, this migration will create:
- **events** table - stores all your event data
- **user_roles** table - manages admin permissions
- All necessary security policies

### 2. Creating Your Admin Account

After the database is set up, you need to grant yourself admin access:

1. Sign up for an account on your website
2. In your Supabase dashboard, run this SQL query (replace with your email):

```sql
INSERT INTO user_roles (user_id, role)
SELECT id, 'admin'
FROM auth.users
WHERE email = 'your-email@example.com';
```

---

## Accessing the Admin Panel

### For Admin Users:
1. Log in to your account
2. Click on your profile icon in the top right
3. In the dropdown menu, you'll see "Admin Dashboard"
4. Click it to access the admin panel

### Admin Menu Options:
- **Admin Dashboard** - Manage all events
- **Settings** - Account settings
- **Appearance** - Theme preferences
- **Support** - Help resources
- **Download the app** - Mobile app access
- **Log out** - Sign out of your account

---

## Managing Events

### Creating a New Event

1. Click the "Create Event" button in the top right
2. Fill in the event details:

   **Required Fields:**
   - **Event Title** - The name of your event
   - **Date** - Format: "Oct 15, 2025" or "15 Oct 2025"
   - **Category** - Select from: Music, Food, Art, Tech, Sports, Business, Entertainment, Health, Education, or General
   - **Location** - Where the event takes place
   - **Image URL** - Link to an event image (you'll see a preview)
   - **Description** - Details about the event

   **Optional Settings:**
   - **Featured** - Check to show on the featured slider
   - **Trending** - Check to show in trending section
   - **Sponsored** - Mark as a sponsored event

3. Click "Create Event" to save

### Editing an Event

1. Find the event you want to edit
2. Click the "Edit" button on the event card
3. Make your changes
4. Click "Update Event" to save

### Deleting an Event

1. Find the event you want to delete
2. Click the "Delete" button
3. Confirm the deletion

---

## Event Display Logic

### Where Events Appear:

1. **Featured Slider** (Hero Section)
   - Shows events marked as "Featured"
   - Auto-scrolls horizontally
   - Prominent display at the top

2. **Trending Now** (Middle Section)
   - Shows events marked as "Trending"
   - Horizontal scrollable list
   - Highlighted section

3. **Events For You** (Main Section)
   - Shows ALL events
   - Main browsable list
   - Respects search filters

### Event Display Priority:
- Events are sorted by creation date (newest first)
- Featured events appear in the hero slider
- Trending events appear in the trending section
- All events appear in the "Events For You" section

---

## Tips for Best Results

### Image URLs:
- Use high-quality images (1200x800px or similar)
- Free stock photo sources:
  - Pexels: https://www.pexels.com
  - Unsplash: https://unsplash.com
- Copy the image URL (right-click → Copy Image Address)

### Date Formatting:
- Keep dates consistent: "Oct 15, 2025"
- Use month abbreviations for a cleaner look
- Include the year for clarity

### Categories:
- Use consistent categories across events
- This helps users filter events
- Available: Music, Food, Art, Tech, Sports, Business, Entertainment, Health, Education, General

### Descriptions:
- Write clear, engaging descriptions
- Highlight what makes the event special
- Include important details (time, parking, etc.)

---

## User Experience Features

### For Visitors:
- Browse all events without logging in
- Search and filter events by category, location, and date
- View detailed event information
- Save favorite events

### For Admin Users:
- Full event management (create, edit, delete)
- Real-time updates to the website
- See all events in one dashboard
- Easy-to-use interface

---

## Security Features

Your admin panel includes enterprise-grade security:

1. **Row Level Security (RLS)**
   - Only admins can create, edit, or delete events
   - Regular users can only view events
   - Prevents unauthorized access

2. **Persistent Login**
   - "Keep me logged in" checkbox
   - 30-day session duration
   - Secure session management

3. **Role-Based Access**
   - Admin role required for dashboard access
   - Automatic permission checks
   - Secure database queries

---

## Troubleshooting

### Can't see Admin Dashboard option?
- Make sure you're logged in
- Verify you have admin role in the database
- Check the user_roles table

### Events not appearing on the site?
- Check that you marked them as Featured or Trending (if applicable)
- All events appear in "Events For You" section
- Clear browser cache and refresh

### Image not showing?
- Verify the URL is correct and accessible
- Try a different image URL
- Use HTTPS URLs when possible

### Need to remove admin access?
Run this SQL query in Supabase:
```sql
DELETE FROM user_roles
WHERE user_id = (SELECT id FROM auth.users WHERE email = 'user@example.com');
```

---

## Technical Details

### Technologies Used:
- **Frontend:** React + TypeScript
- **Database:** Supabase (PostgreSQL)
- **Authentication:** Supabase Auth
- **Styling:** Inline styles with modern design

### Database Tables:

**events**
- Stores all event information
- Auto-timestamps creation and updates
- Links to user who created it

**user_roles**
- Maps users to their roles (admin/user)
- Enforces access control
- Prevents role escalation

---

## Need Help?

If you encounter any issues:
1. Check the browser console for errors
2. Verify your Supabase connection is active
3. Ensure you're logged in with admin privileges
4. Double-check required fields are filled correctly

---

## Future Enhancements

Potential features you could add:
- Image upload functionality (vs. URLs)
- Event categories management
- Analytics dashboard
- Email notifications
- Calendar integration
- Multi-language support

---

*Last Updated: October 2025*
